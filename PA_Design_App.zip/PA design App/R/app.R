# ============================================================
# app.R — PA Design App entry point
#
# This file is the ONLY file Shiny needs to run the app.
# All logic lives in the sourced modules below.
#
# Architecture:
#   global.R           – libraries, config, DB, manager init
#   ui.R               – full dashboardPage() UI definition
#   server.R           – server function + sources all modules
#   modules/
#     calculations/    – pure (non-Shiny) calculation functions
#     server/          – serverXxx() module functions
# ============================================================

# ── Global setup (libraries, config, DB, managers) ───────────
source("global.R")

# ── Calculation modules (pure functions, no Shiny deps) ──────
source("modules/calculations/calc_freq_planning.R")
source("modules/calculations/calc_loss_curves.R")
source("modules/calculations/calc_link_budget.R")
source("modules/calculations/calc_pa_lineup.R")
source("modules/calculations/calc_rf_tools.R")
source("modules/calculations/calc_guardrails.R")

# ── UI definition ─────────────────────────────────────────────
source("ui.R")

# ── Server function + all server modules ─────────────────────
source("server.R")

# ── Launch ────────────────────────────────────────────────────
shinyApp(ui = ui, server = server)

# ╔══════════════════════════════════════════════════════════════╗
# ║  LEGACY MONOLITHIC CODE — kept below for reference only.    ║
# ║  The app no longer uses anything below this line.           ║
# ║  Once validated, remove everything below this block.        ║
# ╚══════════════════════════════════════════════════════════════╝
if (FALSE) {
library(shiny)
library(shinydashboard)
library(shinyjs)
library(plotly)
library(DT)
library(R6)
library(yaml)
library(DBI)
library(pool)

# Source core systems
source("../core/project_mgmt/project_manager.R")
source("../core/data_mgmt/data_manager.R")
source("../core/security/auth_manager.R")
source("../core/state_config/config_manager.R")
source("../core/tagging_metadata/tag_manager.R")
source("../core/ai_agents/base_agent.R")
source("../core/ai_agents/agent_manager.R")

# Source RF PA Design plugin
source("../plugins/rf_pa_design/plugin_init.R")

# Load configuration
config <- ConfigManager$new("../config/app_config.yaml")
app_config <- config$get_config()

# Initialize database connection pool (with fallback to demo mode)
db_pool <- NULL
demo_mode <- FALSE

tryCatch({
  db_pool <- dbPool(
    drv = RPostgres::Postgres(),
    host = Sys.getenv("DB_HOST", "localhost"),
    port = Sys.getenv("DB_PORT", "5432"),
    dbname = Sys.getenv("DB_NAME", "pa_design"),
    user = Sys.getenv("DB_USER", "admin"),
    password = Sys.getenv("DB_PASSWORD", "secret"),
    minSize = 1,
    maxSize = 2
  )
  # Test connection
  con <- poolCheckout(db_pool)
  poolReturn(con)
  cat("✓ Database connection established\n")
}, error = function(e) {
  cat("⚠ Database not available - running in DEMO MODE\n")
  cat("  (Theoretical calculations will work, but project data won't persist)\n\n")
  demo_mode <<- TRUE
})

# Initialize managers
if (!demo_mode) {
  project_mgr <- ProjectManager$new(db_pool)
  data_mgr <- DataManager$new(db_pool)
  tag_mgr <- TagManager$new(db_pool)
} else {
  # Demo mode: use NULL for database connections
  project_mgr <- NULL
  data_mgr <- NULL
  tag_mgr <- NULL
}
agent_mgr <- AgentManager$new(config = app_config$ai_agents)

# UI Definition
ui <- dashboardPage(
  skin = "black",
  
  # Header
  dashboardHeader(
    title = span(
      icon("microchip"),
      "PA Design Assistant"
    ),
    tags$li(class = "dropdown",
      tags$a(href = "#", icon("user"), "Profile")
    )
  ),
  
  # Sidebar
  dashboardSidebar(
    useShinyjs(),
    sidebarMenu(
      id = "sidebar_menu",
      menuItem("Dashboard", tabName = "dashboard", icon = icon("tachometer-alt")),
      menuItem("Projects", tabName = "projects", icon = icon("folder-open")),
      menuItem("Design Flow", tabName = "design", icon = icon("project-diagram"),
        menuSubItem("First Principles", tabName = "first_principles"),
        menuSubItem("Theoretical Calc", tabName = "theoretical_calc"),
        menuSubItem("Architecture", tabName = "architecture"),
        menuSubItem("Simulation", tabName = "simulation"),
        menuSubItem("Layout", tabName = "layout"),
        menuSubItem("Measurement", tabName = "measurement")
      ),
      menuItem("Data Manager", tabName = "data", icon = icon("database")),
      menuItem("RF Tools", tabName = "rf_tools", icon = icon("tools"),
        menuSubItem("Smith Chart", tabName = "smith_chart"),
        menuSubItem("RF Converters", tabName = "rf_converters"),
        menuSubItem("MTTF Calculator", tabName = "mttf_calc"),
        menuSubItem("Thermal Analysis", tabName = "thermal_calc")
      ),
      menuItem("AI Agents", tabName = "agents", icon = icon("robot")),
      menuItem("Knowledge Base", tabName = "knowledge", icon = icon("book")),
      menuItem("Settings", tabName = "settings", icon = icon("cog"))
    )
  ),
  
  # Body
  dashboardBody(
    # Custom CSS and JS
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"),
      tags$link(rel = "stylesheet", type = "text/css", href = "css/pa_lineup.css"),
      tags$script(src = "https://d3js.org/d3.v7.min.js"),
      tags$script(src = "js/pa_lineup_canvas.js"),
      tags$style(HTML("
        .skin-black .main-header .logo { background-color: #1b1b1b; }
        .skin-black .main-header .navbar { background-color: #1b1b1b; }
        .content-wrapper { background-color: #0b0b0b; }
        .box { background-color: #1b1b1b; border-top-color: #ff7f11; }
      "))
    ),
    
    tabItems(
      # Dashboard Tab
      tabItem(tabName = "dashboard",
        fluidRow(
          valueBoxOutput("total_projects", width = 3),
          valueBoxOutput("active_projects", width = 3),
          valueBoxOutput("success_rate", width = 3),
          valueBoxOutput("avg_cycle_time", width = 3)
        ),
        fluidRow(
          box(
            title = "Recent Projects",
            width = 8,
            status = "primary",
            solidHeader = TRUE,
            DTOutput("recent_projects_table")
          ),
          box(
            title = "Design Phase Distribution",
            width = 4,
            status = "info",
            solidHeader = TRUE,
            plotlyOutput("phase_distribution")
          )
        ),
        fluidRow(
          box(
            title = "AI Agent Activity",
            width = 12,
            status = "success",
            solidHeader = TRUE,
            plotlyOutput("agent_activity")
          )
        )
      ),
      
      # Projects Tab
      tabItem(tabName = "projects",
        fluidRow(
          box(
            title = "Create New Project",
            width = 4,
            status = "primary",
            solidHeader = TRUE,
            textInput("new_project_name", "Project Name"),
            selectInput("new_project_arch", "Architecture Type",
              choices = c("Class-A", "Class-B", "Class-AB", "Class-C", 
                         "Class-D", "Class-E", "Class-F", "Doherty")),
            numericInput("new_project_freq", "Frequency (GHz)", value = 2.4, min = 0.1, max = 100),
            numericInput("new_project_pout", "Target Pout (dBm)", value = 30, min = 0, max = 60),
            actionButton("create_project_btn", "Create Project", 
                        class = "btn-primary", icon = icon("plus"))
          ),
          box(
            title = "All Projects",
            width = 8,
            status = "info",
            solidHeader = TRUE,
            DTOutput("all_projects_table")
          )
        )
      ),
      
      # Theoretical Calculation Tab
      tabItem(tabName = "theoretical_calc",
        h2("Theoretical Calculation Module"),
        fluidRow(
          box(
            title = "Project Selection",
            width = 12,
            status = "primary",
            solidHeader = TRUE,
            collapsible = TRUE,
            selectInput("calc_project_select", "Select Project", choices = NULL),
            verbatimTextOutput("calc_project_specs")
          )
        ),
        fluidRow(
          tabBox(
            width = 12,
            id = "theoretical_calc_tabs",
            
            # ======================================
            # Tab 1: Frequency Planning Tool
            # ======================================
            tabPanel(
              title = tagList(icon("satellite-dish"), "Frequency Planning"),
              value = "freq_planning",
              
              fluidRow(
                column(3,
                  h4("View Mode:"),
                  radioButtons("freq_view_mode", NULL,
                    choices = c("Canvas" = "canvas", "Table" = "table", "Equations" = "equations"),
                    selected = "canvas", inline = TRUE)
                ),
                column(9,
                  fluidRow(
                    column(4,
                      numericInput("freq_target_freq", "Target Frequency (GHz)", value = 28, min = 0.1, max = 300),
                      numericInput("freq_target_power", "Target Power (W)", value = 20, min = 0.1, max = 1000)
                    ),
                    column(8,
                      checkboxInput("freq_show_eff", "PA Efficiency Curves", TRUE),
                      checkboxInput("freq_show_atm", "Atmospheric Attenuation", TRUE),
                      checkboxInput("freq_show_tech", "Technology Suitability", TRUE),
                      checkboxInput("freq_show_6g", "6G Candidate Band", TRUE)
                    )
                  )
                )
              ),
              hr(),
              
              # Canvas View
              conditionalPanel(
                condition = "input.freq_view_mode == 'canvas'",
                plotlyOutput("freq_planning_canvas", height = "600px")
              ),
              
              # Table View
              conditionalPanel(
                condition = "input.freq_view_mode == 'table'",
                DTOutput("freq_planning_table")
              ),
              
              # Equations View
              conditionalPanel(
                condition = "input.freq_view_mode == 'equations'",
                wellPanel(
                  h4("Frequency Planning Equations"),
                  HTML("
                    <h5>PA Efficiency Models:</h5>
                    <ul>
                      <li><b>LDMOS:</b> η<sub>LDMOS</sub>(f) = max(65 - 0.8f, 5%)</li>
                      <li><b>GaN:</b> η<sub>GaN</sub>(f) = max(70 - 0.3f, 20%)</li>
                      <li><b>SiGe:</b> η<sub>SiGe</sub>(f) = max(50 - 0.15f, 10%)</li>
                    </ul>
                    <h5>Atmospheric Attenuation:</h5>
                    <ul>
                      <li><b>O<sub>2</sub> Absorption:</b> L<sub>O2</sub>(f) = 15·exp(-((f-60)²)/(2·5²)) dB/km</li>
                      <li><b>H<sub>2</sub>O Absorption:</b> L<sub>H2O</sub>(f) = 8·exp(-((f-22)²)/(2·3²)) dB/km</li>
                      <li><b>Total:</b> L<sub>atm</sub>(f) = 0.01f + L<sub>O2</sub>(f) + L<sub>H2O</sub>(f)</li>
                    </ul>
                    <h5>Technology Selection:</h5>
                    <ul>
                      <li><b>LDMOS:</b> 0.01 - 4 GHz (High power, macro base stations)</li>
                      <li><b>GaN:</b> 1 - 100 GHz (Best efficiency/power density tradeoff)</li>
                      <li><b>SiGe:</b> 20 - 300 GHz (Sub-THz, 6G applications)</li>
                    </ul>
                  ")
                )
              ),
              
              hr(),
              
              # Tabset for Technology References
              tabsetPanel(
                id = "freq_tech_tabs",
                type = "tabs",
                
                # Tab 1: Technology Selection Guide
                tabPanel(
                  title = tagList(icon("microchip"), "Technology Selection"),
                  value = "tech_select",
                  
                  br(),
                  h4(icon("info-circle"), " Transition Frequency (fT) and Maximum Oscillation Frequency (fmax)"),
                  p("For selecting the appropriate transistor technology based on operating frequency:"),
                  
                  HTML("
                    <div style='background-color: #f8f9fa; padding: 15px; border-left: 4px solid #17a2b8; margin: 10px 0;'>
                      <h5><i class='fa fa-info-circle'></i> Selection Rule of Thumb</h5>
                      <p><strong>For operating frequency fop, select technology with: fT > 5 × fop</strong></p>
                      <p style='color: #666; font-size: 13px;'>This ensures sufficient gain and prevents instability at the design frequency.</p>
                    </div>
                    
                    <h5 style='margin-top: 20px;'>Technology Comparison</h5>
                    <table class='table table-striped table-sm'>
                      <thead>
                        <tr>
                          <th>Technology</th>
                          <th>fT Range</th>
                          <th>fmax Range</th>
                          <th>Recommended Frequency</th>
                          <th>Key Applications</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><strong>Si LDMOS</strong></td>
                          <td>20-40 GHz</td>
                          <td>30-60 GHz</td>
                          <td>< 4 GHz</td>
                          <td>Base stations, high power</td>
                        </tr>
                        <tr>
                          <td><strong>GaAs pHEMT</strong></td>
                          <td>30-60 GHz</td>
                          <td>80-150 GHz</td>
                          <td>2-12 GHz</td>
                          <td>Microwave, mmWave</td>
                        </tr>
                        <tr>
                          <td><strong>GaN HEMT</strong></td>
                          <td>50-100 GHz</td>
                          <td>150-300 GHz</td>
                          <td>2-40 GHz</td>
                          <td>5G, radar, satellite</td>
                        </tr>
                        <tr>
                          <td><strong>SiGe HBT</strong></td>
                          <td>200-300 GHz</td>
                          <td>400-500 GHz</td>
                          <td>20-100 GHz</td>
                          <td>mmWave, sub-THz</td>
                        </tr>
                        <tr>
                          <td><strong>InP HEMT</strong></td>
                          <td>300-600 GHz</td>
                          <td>600-1000 GHz</td>
                          <td>60-300 GHz</td>
                          <td>Sub-THz, 6G research</td>
                        </tr>
                      </tbody>
                    </table>
                  "),
                  
                  # Dynamic recommendation
                  uiOutput("technology_fT_recommendation")
                ),
                
                # Tab 2: fT/fmax Plots
                tabPanel(
                  title = tagList(icon("chart-line"), "fT/fmax Plots"),
                  value = "ft_fmax_plots",
                  
                  br(),
                  h4(icon("chart-area"), " Transistor Frequency Performance"),
                  
                  HTML("
                    <div style='background-color: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 10px 0;'>
                      <h5><i class='fa fa-exclamation-triangle'></i> Note</h5>
                      <p>Detailed fT and fmax plots with technology evolution trends are available in:</p>
                      <p><strong><a href='../PA_Design_Reference_Manual/Chapters/Chapter_01_Transistor_Fundamentals.html#section-2-2' target='_blank'>
                        <i class='fa fa-external-link'></i> Chapter 1: Transistor Fundamentals - Section 2.2 (High-Frequency Parameters)
                      </a></strong></p>
                      <p style='margin-bottom: 0; font-size: 13px;'>Includes detailed figures showing fT and fmax evolution over time for different technologies.</p>
                    </div>
                    
                    <h5 style='margin-top: 25px;'>Key Frequency Relationships:</h5>
                    <div class='row' style='margin-top: 15px;'>
                      <div class='col-md-6'>
                        <div style='background: #f8f9fa; padding: 15px; border-radius: 5px; height: 100%;'>
                          <h6><strong>Transition Frequency  (fT)</strong></h6>
                          <ul style='font-size: 14px;'>
                            <li>Frequency where current gain h<sub>21</sub> = 1 (0 dB)</li>
                            <li>Indicates amplification capability</li>
                            <li>Higher fT → Better high-frequency performance</li>
                            <li><strong>Formula:</strong> fT ≈ g<sub>m</sub> / (2πC<sub>gs</sub>)</li>
                          </ul>
                        </div>
                      </div>
                      <div class='col-md-6'>
                        <div style='background: #f8f9fa; padding: 15px; border-radius: 5px; height: 100%;'>
                          <h6><strong>Maximum Oscillation Frequency (fmax)</strong></h6>
                          <ul style='font-size: 14px;'>
                            <li>Frequency where power gain U = 1 (0 dB)</li>
                            <li>Practical upper limit for oscillators/amplifiers</li>
                            <li>Always: fmax ≥ fT</li>
                            <li><strong>Formula:</strong> fmax ≈ √(fT / (8πR<sub>g</sub>C<sub>gd</sub>))</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    
                    <h5 style='margin-top: 25px;'>Available Gain at Operating Frequency:</h5>
                    <div style='background: #e7f3ff; padding: 15px; border-left: 4px solid #007bff; margin: 10px 0;'>
                      <p style='margin: 0;'><strong>G<sub>available</sub>(f<sub>op</sub>) ≈ 20 × log<sub>10</sub>(fT / f<sub>op</sub>) dB</strong></p>
                      <p style='margin: 5px 0 0 0; font-size: 13px; color: #666;'>Example: With fT = 100 GHz at f<sub>op</sub> = 10 GHz → G ≈ 20 dB</p>
                    </div>
                    
                    <h5 style='margin-top: 25px;'>Technology Evolution Trends:</h5>
                    <table class='table table-bordered table-sm'>
                      <thead>
                        <tr>
                          <th>Year Range</th>
                          <th>Si LDMOS fT</th>
                          <th>GaN HEMT fT</th>
                          <th>SiGe HBT fT</th>
                          <th>InP HEMT fT</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>2000-2005</td>
                          <td>~20 GHz</td>
                          <td>~30 GHz</td>
                          <td>~120 GHz</td>
                          <td>~200 GHz</td>
                        </tr>
                        <tr>
                          <td>2005-2010</td>
                          <td>~30 GHz</td>
                          <td>~50 GHz</td>
                          <td>~200 GHz</td>
                          <td>~350 GHz</td>
                        </tr>
                        <tr>
                          <td>2010-2015</td>
                          <td>~35 GHz</td>
                          <td>~70 GHz</td>
                          <td>~250 GHz</td>
                          <td>~500 GHz</td>
                        </tr>
                        <tr>
                          <td>2015-2020</td>
                          <td>~40 GHz</td>
                          <td>~90 GHz</td>
                          <td>~300 GHz</td>
                          <td>~600 GHz</td>
                        </tr>
                        <tr>
                          <td><strong>2020+</strong></td>
                          <td><strong>~40 GHz</strong></td>
                          <td><strong>~100 GHz</strong></td>
                          <td><strong>~350 GHz</strong></td>
                          <td><strong>~700+ GHz</strong></td>
                        </tr>
                      </tbody>
                    </table>
                    
                    <p style='margin-top: 15px; font-size: 13px; color: #666;'>
                      <i class='fa fa-book'></i> <strong>References:</strong>
                    </p>
                    <ul style='font-size: 13px; color: #666;'>
                      <li>Figures 2.2.4, 2.2.5 in <a href='../PA_Design_Reference_Manual/Chapters/Chapter_01_Transistor_Fundamentals.html' target='_blank'>Chapter 1</a></li>
                      <li>ITRS Roadmap for RF and Analog/Mixed-Signal Technologies</li>
                      <li>IEEE Transactions on Electron Devices (various years)</li>
                    </ul>
                  ")
                ),
                
                # Tab 3: Design Guidelines
                tabPanel(
                  title = tagList(icon("lightbulb"), "Design Guidelines"),
                  value = "design_guide",
                  
                  br(),
                  h4(icon("tools"), " Practical Design Rules"),
                  
                  HTML("
                    <h5>Frequency Selection Criteria:</h5>
                    <div class='row' style='margin-top: 15px;'>
                      <div class='col-md-4'>
                        <div style='background: #d4edda; padding: 15px; border-radius: 5px; border-left: 4px solid #28a745;'>
                          <h6><strong><i class='fa fa-check-circle'></i> Safe Range</strong></h6>
                          <p style='font-size: 14px; margin: 0;'>f<sub>op</sub> < fT / 10</p>
                          <p style='font-size: 12px; color: #666; margin: 5px 0 0 0;'>High gain, excellent stability, easy matching</p>
                        </div>
                      </div>
                      <div class='col-md-4'>
                        <div style='background: #fff3cd; padding: 15px; border-radius: 5px; border-left: 4px solid #ffc107;'>
                          <h6><strong><i class='fa fa-exclamation-triangle'></i> Acceptable Range</strong></h6>
                          <p style='font-size: 14px; margin: 0;'>fT / 10 < f<sub>op</sub> < fT / 5</p>
                          <p style='font-size: 12px; color: #666; margin: 5px 0 0 0;'>Moderate gain, requires attention to stability</p>
                        </div>
                      </div>
                      <div class='col-md-4'>
                        <div style='background: #f8d7da; padding: 15px; border-radius: 5px; border-left: 4px solid #dc3545;'>
                          <h6><strong><i class='fa fa-times-circle'></i> Avoid</strong></h6>
                          <p style='font-size: 14px; margin: 0;'>f<sub>op</sub> > fT / 5</p>
                          <p style='font-size: 12px; color: #666; margin: 5px 0 0 0;'>Low gain, stability issues, difficult matching</p>
                        </div>
                      </div>
                    </div>
                    
                    <h5 style='margin-top: 25px;'>Design Examples:</h5>
                    <table class='table table-bordered'>
                      <thead>
                        <tr>
                          <th>Application</th>
                          <th>Frequency</th>
                          <th>Required fT</th>
                          <th>Technology Choice</th>
                          <th>Expected Gain</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><strong>LTE Base Station</strong></td>
                          <td>1.8 GHz</td>
                          <td>> 9 GHz</td>
                          <td>Si LDMOS (fT ~40 GHz)</td>
                          <td>~25 dB per stage</td>
                        </tr>
                        <tr>
                          <td><strong>5G Sub-6GHz</strong></td>
                          <td>3.5 GHz</td>
                          <td>> 17.5 GHz</td>
                          <td>GaN HEMT (fT ~100 GHz)</td>
                          <td>~28 dB per stage</td>
                        </tr>
                        <tr>
                          <td><strong>5G mmWave</strong></td>
                          <td>28 GHz</td>
                          <td>> 140 GHz</td>
                          <td>SiGe HBT (fT ~300 GHz) or GaN</td>
                          <td>~10-12 dB per stage</td>
                        </tr>
                        <tr>
                          <td><strong>6G Research (Sub-THz)</strong></td>
                          <td>140 GHz</td>
                          <td>> 700 GHz</td>
                          <td>InP HEMT (fT ~700+ GHz)</td>
                          <td>~6-8 dB per stage</td>
                        </tr>
                      </tbody>
                    </table>
                    
                    <div style='background-color: #e7f3ff; padding: 15px; border-left: 4px solid #007bff; margin: 20px 0;'>
                      <h5><i class='fa fa-calculator'></i> Quick Calculator:</h5>
                      <p><strong>For your current global frequency: </strong><span id='calc_freq'></span></p>
                      <p><strong>Minimum Required fT: </strong><span id='calc_ft_min'></span></p>
                      <p><strong>Recommended fT: </strong><span id='calc_ft_rec'></span></p>
                      <p><strong>Suggested Technologies: </strong><span id='calc_tech'></span></p>
                      <script>
                        // Update calculator when frequency changes
                        $(document).ready(function() {
                          function updateCalc() {
                            if (typeof Shiny !== 'undefined' && Shiny.shinyapp && Shiny.shinyapp.$inputValues) {
                              var freq = Shiny.shinyapp.$inputValues.global_frequency || 2.6;
                              var ft_min = freq * 5;
                              var ft_rec = freq * 10;
                              
                              $('#calc_freq').text(freq.toFixed(2) + ' GHz');
                              $('#calc_ft_min').text(ft_min.toFixed(1) + ' GHz');
                              $('#calc_ft_rec').text(ft_rec.toFixed(1) + ' GHz');
                              
                              var tech = [];
                              if (ft_rec < 40) tech.push('Si LDMOS');
                              if (ft_rec < 100) tech.push('GaN HEMT');
                              if (ft_rec < 300) tech.push('SiGe HBT');
                              if (ft_rec >= 200) tech.push('InP HEMT');
                              
                              $('#calc_tech').text(tech.join(', ') || 'Advanced research technologies required');
                            }
                          }
                          
                          // Update on load and when frequency changes
                          updateCalc();
                          setInterval(updateCalc, 1000);
                        });
                      </script>
                    </div>
                    
                    <h5 style='margin-top: 25px;'>Key Takeaways:</h5>
                    <ul>
                      <li><strong>Always check fT before selecting a technology</strong> - It's the single most important parameter for frequency selection</li>
                      <li><strong>Use the 5× rule as minimum</strong> - fT should be at least 5× your operating frequency</li>
                      <li><strong>Higher fT = More margin</strong> - Provides better gain, easier matching, and improved stability</li>
                      <li><strong>Consider fmax for oscillators</strong> - For VCOs and oscillators, use fmax instead of fT as the limit</li>
                      <li><strong>Technology roadmaps matter</strong> - fT has improved steadily, enabling higher frequency designs each year</li>
                    </ul>
                  ")
                )
              ),
              
              htmlOutput("freq_recommendation")
            ),
            
            # ======================================
            # Tab 2: Link Budget Calculator
            # ======================================
            tabPanel(
              title = tagList(icon("link"), "Link Budget"),
              value = "link_budget",
              
              fluidRow(
                column(3,
                  h4("View Mode:"),
                  radioButtons("link_view_mode", NULL,
                    choices = c("Canvas" = "canvas", "Table" = "table", "Equations" = "equations"),
                    selected = "canvas", inline = TRUE)
                ),
                column(9,
                  h4("Link Budget Parameters:"),
                  fluidRow(
                    column(6,
                      numericInput("link_tx_power", "Tx Power (dBm)", value = 43, min = -20, max = 80),
                      numericInput("link_tx_gain", "Tx Antenna Gain (dBi)", value = 15, min = -10, max = 50),
                      numericInput("link_freq", "Frequency (GHz)", value = 28, min = 0.1, max = 100),
                      numericInput("link_distance", "Distance (km)", value = 1, min = 0.001, max = 100)
                    ),
                    column(6,
                      numericInput("link_rx_gain", "Rx Antenna Gain (dBi)", value = 15, min = -10, max = 50),
                      numericInput("link_noise_figure", "Rx Noise Figure (dB)", value = 5, min = 0, max = 20),
                      numericInput("link_bandwidth", "Bandwidth (MHz)", value = 100, min = 0.001, max = 10000),
                      numericInput("link_snr_req", "Required SNR (dB)", value = 20, min = 0, max = 50)
                    )
                  ),
                  actionButton("link_calculate", "Calculate Link Budget", class = "btn-success", icon = icon("calculator"))
                )
              ),
              hr(),
              
              # Canvas View
              conditionalPanel(
                condition = "input.link_view_mode == 'canvas'",
                plotlyOutput("link_budget_canvas", height = "600px")
              ),
              
              # Table View
              conditionalPanel(
                condition = "input.link_view_mode == 'table'",
                DTOutput("link_budget_table")
              ),
              
              # Equations View
              conditionalPanel(
                condition = "input.link_view_mode == 'equations'",
                wellPanel(
                  h4("Link Budget Equations"),
                  HTML("
                    <h5>Free Space Path Loss:</h5>
                    <p><b>FSPL (dB)</b> = 20·log<sub>10</sub>(d) + 20·log<sub>10</sub>(f) + 92.45</p>
                    <p>where: d = distance (km), f = frequency (GHz)</p>
                    
                    <h5>Received Power:</h5>
                    <p><b>P<sub>rx</sub> (dBm)</b> = P<sub>tx</sub> + G<sub>tx</sub> - FSPL + G<sub>rx</sub></p>
                    
                    <h5>Thermal Noise Power:</h5>
                    <p><b>N (dBm)</b> = -174 + 10·log<sub>10</sub>(BW) + NF</p>
                    <p>where: BW = bandwidth (Hz), NF = noise figure (dB)</p>
                    
                    <h5>Signal-to-Noise Ratio:</h5>
                    <p><b>SNR (dB)</b> = P<sub>rx</sub> - N</p>
                    
                    <h5>Link Margin:</h5>
                    <p><b>Margin (dB)</b> = SNR - SNR<sub>required</sub></p>
                    
                    <h5>Additional Losses (typical):</h5>
                    <ul>
                      <li><b>Atmospheric:</b> 0.1 - 2 dB/km (frequency dependent)</li>
                      <li><b>Rain:</b> 0.5 - 20 dB (rain rate dependent)</li>
                      <li><b>Polarization mismatch:</b> 0.5 - 3 dB</li>
                      <li><b>Implementation loss:</b> 1 - 3 dB</li>
                    </ul>
                  ")
                )
              ),
              
              hr(),
              htmlOutput("link_budget_summary")
            ),
            
            # ======================================
            # Tab 3: Passive Component Loss Curves
            # ======================================
            tabPanel(
              title = tagList(icon("chart-line"), "Loss Curves"),
              value = "loss_curves",
              
              fluidRow(
                column(12,
                  box(
                    title = tagList(icon("chart-area"), "Passive Component Loss vs Frequency"),
                    width = 12,
                    status = "warning",
                    solidHeader = TRUE,
                    
                    fluidRow(
                      column(8,
                        plotlyOutput("loss_curves_plot", height = "550px")
                      ),
                      column(4,
                        wellPanel(
                          h4(icon("wrench"), " Component Selection"),
                          
                          checkboxGroupInput("loss_curve_components",
                            "Display Components:",
                            choices = c(
                              "Wilkinson Splitter (2-way)" = "wilkinson_splitter",
                              "Wilkinson Combiner (2-way)" = "wilkinson_combiner",
                              "Quadrature Hybrid (90°)" = "quadrature_hybrid",
                              "T-Junction Splitter" = "t_junction",
                              "Transmission Line (10cm)" = "transmission_line",
                              "Doherty Combiner" = "doherty_combiner",
                              "Transformer (1:1)" = "transformer"
                            ),
                            selected = c("wilkinson_splitter", "wilkinson_combiner", "doherty_combiner", "transmission_line")
                          ),
                          
                          hr(),
                          
                          h5(icon("calculator"), " Quick Calculator"),
                          numericInput("loss_calc_freq", "Frequency (GHz)", value = 2.6, min = 0.1, max = 30, step = 0.1),
                          selectInput("loss_calc_type", "Component Type",
                            choices = c(
                              "Wilkinson Splitter" = "wilkinson_splitter",
                              "Wilkinson Combiner" = "wilkinson_combiner",
                              "Quadrature Hybrid" = "quadrature_hybrid",
                              "T-Junction" = "t_junction",
                              "Transmission Line (10cm)" = "transmission_line",
                              "Doherty Combiner" = "doherty_combiner",
                              "Transformer" = "transformer"
                            )
                          ),
                          div(style = "background-color: #f8f9fa; padding: 15px; border-left: 4px solid #ff851b; margin-top: 10px;",
                            h4(icon("arrow-right"), " Estimated Loss:"),
                            h3(textOutput("loss_calc_result", inline = TRUE), style = "color: #ff851b; margin: 5px 0;"),
                            p("dB", style = "color: #666; margin: 0;")
                          )
                        )
                      )
                    ),
                    
                    hr(),
                    
                    h4(icon("book"), " Loss Estimation Models & Academic References"),
                    
                    tabsetPanel(
                      tabPanel("Formulas",
                        br(),
                        HTML("
                          <h5>1. Wilkinson Splitter/Combiner</h5>
                          <p><strong>Model:</strong> L<sub>wilk</sub>(f) = 3.0 + 0.1 + 0.05·f [dB]</p>
                          <ul>
                            <li>3.0 dB: Ideal power split (2-way)</li>
                            <li>0.1 dB: Quarter-wave transformer insertion loss (baseline)</li>
                            <li>0.05·f: Frequency-dependent losses (skin effect, dielectric)</li>
                          </ul>
                          <p><strong>Reference:</strong> Wilkinson, E.J. 'An N-Way Hybrid Power Divider' (IEEE Trans. MTT, 1960)</p>
                          
                          <h5>2. Quadrature Hybrid (90° Coupler)</h5>
                          <p><strong>Model:</strong> L<sub>quad</sub>(f) = 0.3 + 0.08·f + 0.02·f<sup>1.5</sup> [dB]</p>
                          <ul>
                            <li>Coupled-line structure with directivity limitations</li>
                            <li>Higher frequency → Reduced directivity → Increased loss</li>
                          </ul>
                          <p><strong>Reference:</strong> Mongia et al. 'RF and Microwave Coupled-Line Circuits' (Artech House, 2007)</p>
                          
                          <h5>3. Transmission Line (Microstrip on FR4)</h5>
                          <p><strong>Model:</strong> L<sub>line</sub>(f) = (0.05 + 0.15·√f + 0.02·f) × L/10 [dB]</p>
                          <ul>
                            <li>Skin effect losses: ∝ √f</li>
                            <li>Dielectric losses: ∝ f (tanδ = 0.02 for FR4)</li>
                            <li>L: Length in cm</li>
                          </ul>
                          <p><strong>Reference:</strong> Wadell, B.C. 'Transmission Line Design Handbook' (Artech House, 1991), Section 3.4</p>
                          
                          <h5>4. Doherty Combiner</h5>
                          <p><strong>Model:</strong> L<sub>doh</sub>(f) = 0.2 + 0.02·f + 0.01·f<sup>1.3</sup> [dB]</p>
                          <ul>
                            <li>Lower loss than Wilkinson (impedance transformation, no resistor)</li>
                            <li>Quarter-wave impedance inverter</li>
                          </ul>
                          <p><strong>Reference:</strong> Cripps, S.C. 'RF Power Amplifiers for Wireless Communications' Ch.9 (Artech House, 2006)</p>
                          
                          <h5>5. Transformer (1:1 ratio)</h5>
                          <p><strong>Model:</strong></p>
                          <ul>
                            <li>f < 0.5 GHz: L = 0.3 + 0.05·f (core loss dominant)</li>
                            <li>0.5 - 3 GHz: L = 0.2 + 0.03·(f - 0.5) (optimal range)</li>
                            <li>f > 3 GHz: L = 0.4 + 0.1·(f - 3) (winding/stray capacitance)</li>
                          </ul>
                          <p><strong>Reference:</strong> Sevick, J. 'Transmission Line Transformers' (Noble Publishing, 2001)</p>
                          
                          <h5>6. T-Junction Splitter</h5>
                          <p><strong>Model:</strong> L<sub>tjunc</sub>(f) = 0.05 + 0.03·f [dB]</p>
                          <ul>
                            <li>Very low loss but poor isolation</li>
                            <li>Simple transmission line junction</li>
                          </ul>
                        ")
                      ),
                      
                      tabPanel("Usage in Lineup",
                        br(),
                        HTML("
                          <div style='background-color: #d1ecf1; padding: 15px; border-left: 4px solid #0c5460; margin-bottom: 15px;'>
                            <h5><i class='fa fa-info-circle'></i> Automatic Loss Application</h5>
                            <p>When you apply specifications to a lineup, these loss curves are <strong>automatically</strong> consulted to populate passive component parameters at the appropriate frequency.</p>
                          </div>
                          
                          <h5>How Loss Curves Impact Lineup Design</h5>
                          
                          <h6>1. Power Budget Calculations</h6>
                          <p>Each passive component reduces available power:</p>
                          <ul>
                            <li><strong>Splitters:</strong> P<sub>out</sub> = P<sub>in</sub> - 10·log<sub>10</sub>(N) - L<sub>insertion</sub></li>
                            <li><strong>Transmission Lines:</strong> Cumulative loss through cascade</li>
                            <li><strong>Combiners:</strong> Slightly reduce combined output power</li>
                          </ul>
                          
                          <h6>2. Gain Reduction</h6>
                          <p>Total lineup gain is reduced by passive losses:</p>
                          <p style='background-color: #f8f9fa; padding: 10px; font-family: monospace;'>
                            G<sub>total</sub> = Σ(G<sub>transistor</sub>) - Σ(L<sub>passive</sub>)
                          </p>
                          
                          <h6>3. Frequency-Dependent Behavior</h6>
                          <table class='table table-sm table-striped'>
                            <thead>
                              <tr>
                                <th>Frequency</th>
                                <th>Wilkinson Loss</th>
                                <th>Transmission Line (10cm)</th>
                                <th>Impact</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1 GHz</td>
                                <td>~3.2 dB</td>
                                <td>~0.37 dB</td>
                                <td>Manageable</td>
                              </tr>
                              <tr>
                                <td>5 GHz</td>
                                <td>~3.35 dB</td>
                                <td>~0.89 dB</td>
                                <td>Moderate</td>
                              </tr>
                              <tr>
                                <td>10 GHz</td>
                                <td>~3.60 dB</td>
                                <td>~1.45 dB</td>
                                <td>Significant</td>
                              </tr>
                              <tr>
                                <td>28 GHz</td>
                                <td>~3.80 dB</td>
                                <td>~3.50 dB</td>
                                <td>Critical (mmWave)</td>
                              </tr>
                            </tbody>
                          </table>
                          
                          <h6>4. Design Strategies</h6>
                          <ul>
                            <li><strong>Minimize Interconnect Length:</strong> Each cm matters at mmWave</li>
                            <li><strong>Choose Low-Loss Substrate:</strong> Rogers/Alumina vs FR4 at high freq</li>
                            <li><strong>Prefer Doherty Combiner:</strong> ~0.5 dB vs 3.2 dB for Wilkinson</li>
                            <li><strong>Use T-Junction When Isolation Not Critical:</strong> Lowest loss option</li>
                          </ul>
                          
                          <div style='background-color: #fff3cd; padding: 15px; border-left: 4px solid #856404; margin-top: 15px;'>
                            <h5><i class='fa fa-lightbulb'></i> Pro Tip</h5>
                            <p><strong>At mmWave (>20 GHz):</strong> Passive losses can exceed active device gains! Consider integrated approaches or waveguide structures to minimize interconnect.</p>
                          </div>
                        ")
                      )
                    )
                  )
                )
              )
            ),
            
            # ======================================
            # Tab 4: PA Lineup Calculator (Enhanced Interactive)
            # ======================================
            tabPanel(
              title = tagList(icon("project-diagram"), "PA Lineup"),
              value = "pa_lineup",
              
              fluidRow(
                # Left: Interactive Canvas
                column(8,
                  box(
                    title = tagList(
                      icon("paint-brush"), 
                      "Interactive PA Lineup Canvas",
                      div(style = "float: right;",
                        tags$button(
                          id = "canvas_fullscreen_btn",
                          class = "btn btn-sm btn-default",
                          style = "margin-top: -5px;",
                          onclick = "toggleCanvasFullscreen();",
                          icon("expand"),
                          title = "Toggle Fullscreen"
                        )
                      )
                    ),
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    id = "sticky_canvas_box",
                    div(
                      id = "pa_lineup_canvas_container", 
                      style = "position: relative;",
                      
                      # Floating top sidebar for architecture templates
                      div(
                        id = "canvas_top_sidebar",
                        class = "canvas-top-sidebar collapsed",
                        
                        # Toggle button
                        tags$button(
                          id = "top_sidebar_toggle",
                          class = "top-sidebar-toggle",
                          onclick = "toggleCanvasTopSidebar()",
                          icon("chevron-down"),
                          " Templates"
                        ),
                        
                        # Top sidebar content
                        div(
                          class = "top-sidebar-content",
                          div(class = "top-sidebar-title", icon("layer-group"), " Architecture Templates"),
                          div(class = "top-sidebar-templates",
                            div(class = "preset-template", `data-preset` = "triple_stage",
                              h5("3-Stage Cascade"),
                              p("Pre-driver → Driver → Final PA")
                            ),
                            div(class = "preset-template", `data-preset` = "single_doherty",
                              h5("Single Driver Doherty"),
                              p("Driver → Splitter → Main/Aux PA")
                            ),
                            div(class = "preset-template", `data-preset` = "dual_doherty",
                              h5("Dual Driver Doherty"),
                              p("Dual drivers → Main/Aux paths")
                            ),
                            div(class = "preset-template", `data-preset` = "conventional_doherty",
                              h5("Conventional Doherty"),
                              p("Standard λ/4 impedance transformation")
                            ),
                            div(class = "preset-template", `data-preset` = "inverted_doherty",
                              h5("Inverted Doherty"),
                              p("Inverted phase configuration")
                            ),
                            div(class = "preset-template", `data-preset` = "symmetric_doherty",
                              h5("Symmetric Doherty"),
                              p("Equal power Main & Aux PAs")
                            ),
                            div(class = "preset-template", `data-preset` = "asymmetric_doherty",
                              h5("Asymmetric Doherty"),
                              p("2:1 power ratio for extended efficiency")
                            ),
                            div(class = "preset-template", `data-preset` = "envelope_tracking_doherty",
                              h5("Envelope Tracking Doherty"),
                              p("Main/Aux with VDD modulation")
                            ),
                            div(class = "preset-template", `data-preset` = "3way_symmetric_doherty",
                              h5("3-Way Symmetric Doherty"),
                              p("1 main + 2 equal peaking PAs")
                            ),
                            div(class = "preset-template", `data-preset` = "3way_asymmetric_doherty",
                              h5("3-Way Asymmetric Doherty"),
                              p("1 main (50%) + 2 peaking (25% each)")
                            ),
                            div(class = "preset-template", `data-preset` = "blank",
                              h5("Blank Canvas"),
                              p("Start from scratch")
                            ),
                            # User Saved Templates Section
                            tags$div(class = "sidebar-section-label", style = "font-size: 10px; color: #999; margin: 15px 10px 5px 10px; text-transform: uppercase; letter-spacing: 0.5px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;", "USER SAVED TEMPLATES"),
                            tags$div(id = "user_templates_top_sidebar",
                              uiOutput("user_templates_top_display")
                            )
                          )
                        )
                      ),
                      
                      # Floating right sidebar for canvas actions
                      div(
                        id = "canvas_sidebar",
                        class = "canvas-sidebar collapsed",
                        
                        # Toggle button
                        tags$button(
                          id = "sidebar_toggle",
                          class = "sidebar-toggle",
                          onclick = "toggleCanvasSidebar()",
                          icon("chevron-left"),
                          title = "Canvas Actions"
                        ),
                        
                        # Sidebar content
                        div(
                          class = "sidebar-content",
                          
                          # Zoom Controls Section
                          div(
                            class = "sidebar-section",
                            div(class = "sidebar-section-title", icon("search"), " Zoom"),
                            div(class = "icon-button-group",
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.zoomIn();",
                                class = "btn btn-default btn-icon",
                                icon("search-plus"),
                                title = "Zoom In"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.zoomOut();",
                                class = "btn btn-default btn-icon",
                                icon("search-minus"),
                                title = "Zoom Out"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.resetZoom();",
                                class = "btn btn-default btn-icon",
                                icon("home"),
                                title = "Reset View"
                              )
                            )
                          ),
                          
                          # Component Actions Section
                          div(
                            class = "sidebar-section",
                            div(class = "sidebar-section-title", icon("cogs"), " Actions"),
                            div(class = "icon-button-group",
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.toggleBoxSelect();",
                                id = "box_select_btn",
                                class = "btn btn-default btn-icon",
                                icon("object-group"),
                                title = "Box Select (Ctrl+B)"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.deleteSelected();",
                                class = "btn btn-danger btn-icon",
                                icon("trash"),
                                title = "Delete (Del)"
                              )
                            ),
                            div(class = "icon-button-group",
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.copy();",
                                id = "copy_btn",
                                class = "btn btn-default btn-icon",
                                icon("copy"),
                                title = "Copy (Ctrl+C)"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.cut();",
                                id = "cut_btn",
                                class = "btn btn-default btn-icon",
                                icon("cut"),
                                title = "Cut (Ctrl+X)"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.paste();",
                                id = "paste_btn",
                                class = "btn btn-default btn-icon",
                                icon("paste"),
                                title = "Paste (Ctrl+V)"
                              )
                            ),
                            div(class = "icon-button-group",
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.undo();",
                                id = "lineup_undo",
                                class = "btn btn-default btn-icon",
                                icon("undo"),
                                title = "Undo (Ctrl+Z)"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.redo();",
                                id = "lineup_redo",
                                class = "btn btn-default btn-icon",
                                icon("redo"),
                                title = "Redo (Ctrl+Y)"
                              )
                            ),
                            # Guide Lines Section
                            div(class = "sidebar-section-title", icon("grip-lines"), " Guide Lines"),
                            div(class = "icon-button-group",
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.toggleHorizontalLine();",
                                id = "toggle_horizontal_line",
                                class = "btn btn-success btn-icon",
                                style = "background-color: #28a745; color: #fff;",
                                icon("minus"),
                                title = "Horizontal Line"
                              ),
                              tags$button(
                                onclick = "if(window.paCanvas) paCanvas.toggleVerticalLine();",
                                id = "toggle_vertical_line",
                                class = "btn btn-success btn-icon",
                                style = "background-color: #28a745; color: #fff;",
                                HTML("|"),
                                title = "Vertical Line"
                              )
                            ),
                            tags$button(
                              onclick = "if(window.paCanvas) paCanvas.clear();",
                              class = "btn btn-warning btn-block btn-sm",
                              icon("eraser"),
                              " Clear All"
                            )
                          ),
                          
                          # File Actions Section
                          div(
                            class = "sidebar-section",
                            div(class = "sidebar-section-title", icon("file"), " File"),
                            actionButton("lineup_save_config", "Save", icon = icon("save"), class = "btn-success btn-block btn-sm"),
                            actionButton("lineup_load_config", "Load", icon = icon("folder-open"), class = "btn-default btn-block btn-sm"),
                            actionButton("lineup_export_diagram", "Export", icon = icon("image"), class = "btn-default btn-block btn-sm"),
                            actionButton("lineup_generate_report", "Report", icon = icon("file-pdf"), class = "btn-default btn-block btn-sm")
                          ),
                          
                          # Canvas Naming (only shown in multi-canvas mode)
                          conditionalPanel(
                            condition = "input.canvas_layout != '1x1'",
                            div(
                              class = "sidebar-section",
                              div(class = "sidebar-section-title", icon("tag"), " Canvas Names"),
                              actionButton("edit_canvas_names", 
                                "Edit Names", 
                                icon = icon("edit"), 
                                class = "btn-default btn-block btn-sm")
                            )
                          ),
                          
                          # Template Actions Section (only shown in single canvas mode)
                          conditionalPanel(
                            condition = "input.canvas_layout == '1x1'",
                            div(
                              class = "sidebar-section",
                              div(class = "sidebar-section-title", icon("bookmark"), " Save as Template"),
                              textInput("template_name", 
                                label = NULL, 
                                placeholder = "Template name...",
                                width = "100%"),
                              actionButton("save_as_template", 
                                "Save Template", 
                                icon = icon("bookmark"), 
                                class = "btn-info btn-block btn-sm",
                                onclick = "saveCurrentAsTemplate();")
                            ),
                            div(
                              class = "sidebar-section",
                              style = "margin-top: 10px;",
                              div(class = "sidebar-section-title", icon("list"), " Manage Templates"),
                              uiOutput("user_templates_manager")
                            )
                          )
                        )
                      ),
                      
                      # Floating lower sidebar for display options
                      div(
                        id = "canvas_lower_sidebar",
                        class = "canvas-lower-sidebar",
                        
                        tags$button(
                          onclick = "if(window.paCanvas) paCanvas.togglePowerDisplay();",
                          id = "power_display_toggle",
                          class = "btn btn-default btn-sm",
                          style = "min-width: 140px;",
                          icon("bolt"),
                          " Power Display"
                        ),
                        
                        tags$button(
                          onclick = "if(window.paCanvas) paCanvas.togglePowerUnit();",
                          id = "power_unit_toggle",
                          class = "btn btn-default btn-sm",
                          style = "min-width: 120px;",
                          icon("ruler"),
                          " Unit: dBm"
                        ),
                        
                        tags$button(
                          onclick = "if(window.paCanvas) paCanvas.toggleImpedanceDisplay();",
                          id = "impedance_display_toggle",
                          class = "btn btn-default btn-sm",
                          style = "min-width: 160px;",
                          icon("infinity"),
                          " Impedance Display"
                        ),
                        
                        tags$button(
                          onclick = "if(window.paCanvas) paCanvas.toggleCalculationRationale();",
                          id = "calculation_rationale_toggle",
                          class = "btn btn-default btn-sm",
                          style = "min-width: 180px;",
                          icon("calculator"),
                          " Calculation Details"
                        ),
                        
                        tags$button(
                          onclick = "if(window.paCanvases && window.paCanvases.length > 1) window.toggleCanvasComparison(); else alert('Comparison requires multiple canvases');",
                          id = "canvas_comparison_toggle",
                          class = "btn btn-default btn-sm",
                          style = "min-width: 180px;",
                          icon("table"),
                          " Canvas Comparison"
                        )
                      )
                    )
                  )
                ),
                
                # Right: Component Properties & Results
                column(4,
                  # Specifications Box (NEW)
                  box(
                    title = tagList(icon("clipboard-list"), "Specifications"),
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    collapsible = TRUE,
                    collapsed = TRUE,
                    
                    # PRIMARY LINEUP DRIVING PARAMETERS (highlighted)
                    div(style = "background-color: #fff3cd; padding: 10px; border-left: 4px solid #ff851b; margin-bottom: 15px;",
                      h5(icon("star"), " PRIMARY LINEUP DRIVERS", style = "color: #ff851b; margin-top: 0;"),
                      fluidRow(
                        column(6,
                          div(style = "border: 2px solid #ff851b; border-radius: 4px; padding: 5px; background-color: #fffbf5;",
                            numericInput("spec_frequency", 
                              tags$strong("⚡ Frequency (MHz)", style = "color: #ff851b;"), 
                              value = 1805, min = 100, max = 10000, step = 1)
                          )
                        ),
                        column(6,
                          div(style = "border: 2px solid #ff851b; border-radius: 4px; padding: 5px; background-color: #fffbf5;",
                            numericInput("spec_p3db", 
                              tags$strong("⚡ P3dB Output (dBm)", style = "color: #ff851b;"), 
                              value = 55.3, min = 0, max = 80, step = 0.1)
                          )
                        ),
                        column(6,
                          div(style = "border: 2px solid #ff851b; border-radius: 4px; padding: 5px; background-color: #fffbf5;",
                            numericInput("spec_par", 
                              tags$strong("⚡ PAR / BO (dB)", style = "color: #ff851b;"), 
                              value = 8.0, min = 0, max = 20, step = 0.1),
                            tags$small("Pavg = P3dB - PAR", style = "color: #999;")
                          )
                        )
                      ),
                      fluidRow(
                        column(6,
                          div(style = "border: 2px solid #ff851b; border-radius: 4px; padding: 5px; background-color: #fffbf5;",
                            numericInput("spec_gain", 
                              tags$strong("⚡ Total Gain (dB)", style = "color: #ff851b;"), 
                              value = 41.5, min = 0, max = 80, step = 0.1)
                          )
                        ),
                        column(6,
                          numericInput("spec_supply_voltage", "Supply Voltage (V)", 
                            value = 30, min = 5, max = 50, step = 1)
                        )
                      ),
                      fluidRow(
                        column(4,
                          numericInput("spec_bw_lower", "BW Lower Margin (%)", 
                            value = 10, min = 0, max = 50, step = 1)
                        ),
                        column(4,
                          numericInput("spec_bw_upper", "BW Upper Margin (%)", 
                            value = 10, min = 0, max = 50, step = 1)
                        ),
                        column(4,
                          div(style = "margin-top: 25px;",
                            strong("Bandwidth:"),
                            textOutput("spec_bandwidth_display", inline = TRUE),
                            tags$span(" MHz", style = "color: #666;")
                          )
                        )
                      )
                    ),
                    
                    # SECONDARY SPECIFICATIONS
                    h5(icon("sliders-h"), " Secondary Specifications", style = "margin-top: 5px;"),
                    fluidRow(
                      column(6,
                        numericInput("spec_efficiency", "Efficiency (%)", value = 47, min = 0, max = 100, step = 1)
                      ),
                      column(6,
                        numericInput("spec_vbw", "VBW (MHz)", value = 225, min = 1, max = 1000, step = 1)
                      )
                    ),
                    fluidRow(
                      column(6,
                        numericInput("spec_am_pm_p3db", "AM-PM @ P3dB (deg)", value = -25, min = -50, max = 50, step = 0.1)
                      ),
                      column(6,
                        numericInput("spec_am_pm_dispersion", "AM-PM Dispersion (deg)", value = 8, min = 0, max = 50, step = 0.1)
                      )
                    ),
                    fluidRow(
                      column(6,
                        numericInput("spec_group_delay", "Group Delay Flatness (ns)", value = 1, min = 0, max = 100, step = 0.1)
                      ),
                      column(6,
                        numericInput("spec_efficiency", "Efficiency (%)", value = 47, min = 0, max = 100, step = 1)
                      )
                    ),
                    fluidRow(
                      column(6,
                        numericInput("spec_acp", "ACP (dBc)", value = -30, min = -80, max = 0, step = 0.1)
                      ),
                      column(6,
                        numericInput("spec_gain_ripple_inband", "Gain Ripple In-band (dB)", value = 1.0, min = 0, max = 10, step = 0.1)
                      )
                    ),
                    fluidRow(
                      column(6,
                        numericInput("spec_gain_ripple_3xband", "Gain Ripple 3x Band (dB)", value = 3.0, min = 0, max = 10, step = 0.1)
                      ),
                      column(6,
                        numericInput("spec_input_return_loss", "Input Return Loss (dB)", value = -15, min = -50, max = 0, step = 0.1)
                      )
                    ),
                    fluidRow(
                      column(6,
                        numericInput("spec_vbw", "VBW (MHz)", value = 225, min = 1, max = 1000, step = 1)
                      ),
                      column(6,
                        selectInput("spec_test_conditions", "Test Conditions",
                          choices = c(
                            "DC" = "dc",
                            "CW" = "cw",
                            "NVA Sweep 25ms" = "nva_25ms",
                            "Nokia LTE 1c 10MHz" = "nokia_lte",
                            "Low Freq Resonance" = "low_freq_res"
                          ),
                          selected = "cw"
                        )
                      )
                    ),
                    helpText(icon("info-circle"), " Target specifications for the PA lineup design."),
                    hr(),
                    div(style = "display: flex; gap: 10px; margin-top: 10px;",
                      actionButton("apply_specs_to_lineup", 
                                   "Apply Specs to Lineup ↓", 
                                   class = "btn-primary btn-block", 
                                   icon = icon("arrow-down"),
                                   style = "flex: 1;"),
                      actionButton("apply_specs_to_global", 
                                   "Update Global Params ↓", 
                                   class = "btn-info", 
                                   icon = icon("sync"),
                                   style = "flex: 1;")
                    ),
                    helpText(icon("lightbulb"), " 'Apply to Lineup' adapts current template. 'Update Global' only updates frequency/power.")
                  ),
                  
                  # Global Lineup Parameters
                  box(
                    title = tagList(icon("globe"), "Global Lineup Parameters"),
                    width = 12,
                    status = "primary",
                    solidHeader = TRUE,
                    collapsible = TRUE,
                    fluidRow(
                      column(6,
                        numericInput("global_frequency", "Frequency (GHz)", 
                          value = 2.6, min = 0.1, max = 100, step = 0.1)
                      ),
                      column(6,
                        numericInput("global_pout_p3db", tags$strong("Pout (P3dB) (dBm)"), 
                          value = 55.3, min = 0, max = 80, step = 0.1)
                      )
                    ),
                    fluidRow(
                      column(6,
                        numericInput("global_backoff", "Back-off (dB)", 
                          value = 6, min = 0, max = 20, step = 0.5)
                      ),
                      column(6,
                        numericInput("global_PAR", "PAR (dB)", 
                          value = 8, min = 0, max = 15, step = 0.5)
                      )
                    ),
                    fluidRow(
                      column(6,
                        div(style = "margin-top: 25px;",
                          strong("Pavg (dBm):"),
                          textOutput("calculated_Pavg", inline = TRUE)
                        )
                      ),
                      column(6,
                        div(style = "margin-top: 25px;",
                          strong("Pin (dBm):"),
                          textOutput("calculated_Pin_global", inline = TRUE),
                          tags$span(" (from specs)", style = "color: #999; font-size: 12px;")
                        )
                      )
                    ),
                    helpText(icon("info-circle"), " These parameters apply to the entire lineup. Pout(P3dB) typically derived from Specifications.")
                  ),
                  
                  # Canvas Layout Selector
                  box(
                    title = tagList(icon("th"), "Canvas Layout"),
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    collapsible = TRUE,
                    collapsed = TRUE,
                    
                    p("Compare multiple architectures side-by-side:"),
                    
                    selectInput("canvas_layout", "Layout Configuration",
                      choices = c(
                        "Single Canvas (1x1)" = "1x1",
                        "Horizontal Split (1x2)" = "1x2",
                        "Vertical Split (2x1)" = "2x1",
                        "Quad Split (2x2)" = "2x2",
                        "2x3 Grid" = "2x3",
                        "3x2 Grid" = "3x2",
                        "Horizontal Triple (1x3)" = "1x3",
                        "Horizontal Quad (1x4)" = "1x4",
                        "Vertical Quad (4x1)" = "4x1",
                        "3x3 Grid" = "3x3",
                        "4x2 Grid" = "4x2",
                        "2x4 Grid" = "2x4",
                        "2+1 Layout (1 large + 2 small)" = "2+1",
                        "1+2 Layout (2 small + 1 large)" = "1+2"
                      ),
                      selected = "1x1"
                    ),
                    
                    helpText(icon("info-circle"), " Active canvas follows cursor. Each canvas has independent components but shares global parameters."),
                    
                    div(id = "canvas_labels", style = "margin-top: 10px;")
                  ),
                  
                  # Component Property Editor
                  box(
                    title = "Component Properties",
                    width = 12,
                    collapsible = TRUE,
                    status = "warning",
                    solidHeader = TRUE,
                    uiOutput("lineup_property_editor")
                  ),
                  
                  # Calculation Results
                  box(
                    title = "Calculation Results",
                    width = 12,
                    status = "success",
                    solidHeader = TRUE,
                    div(style = "display: flex; gap: 10px; align-items: center; margin-bottom: 10px;",
                      div(style = "flex: 1;",
                        actionButton("lineup_calculate", "Calculate Lineup", class = "btn-success btn-block", icon = icon("calculator"))
                      ),
                      div(style = "flex: 0 0 180px;",
                        numericInput("backoff_db", "Backoff (dB):", value = 6, min = 0, max = 20, step = 0.5, width = "100%")
                      )
                    ),
                    # Multi-canvas comparison button (only show in multi-canvas mode)
                    conditionalPanel(
                      condition = "input.canvas_layout != '1x1'",
                      actionButton("lineup_calculate_all", "Calculate All Canvases", 
                                   class = "btn-info btn-block", 
                                   icon = icon("layer-group"),
                                   style = "margin-bottom: 10px;")
                    ),
                    hr(),
                    tabsetPanel(
                      id = "calc_results_tabs",
                      tabPanel(
                        title = "Current Canvas",
                        value = "current_results",
                        icon = icon("chart-line"),
                        br(),
                        uiOutput("lineup_calc_results")
                      ),
                      tabPanel(
                        title = "Comparison",
                        value = "comparison_results",
                        icon = icon("table"),
                        br(),
                        uiOutput("lineup_comparison_results")
                      )
                    )
                  ),
                  
                  # Version Control
                  box(
                    title = "Version Control",
                    width = 12,
                    status = "primary",
                    solidHeader = TRUE,
                    collapsible = TRUE,
                    collapsed = TRUE,
                    textInput("lineup_version_name", "Version Name", placeholder = "v1.0"),
                    textAreaInput("lineup_version_notes", "Notes", placeholder = "Description of changes...", rows = 3),
                    actionButton("lineup_save_version", "Save as New Version", class = "btn-primary btn-block", icon = icon("code-branch")),
                    hr(),
                    uiOutput("lineup_version_list")
                  )
                )
              ),
              
              # View Tabs Below Canvas
              fluidRow(
                tabBox(
                  width = 12,
                  
                  # Table View
                  tabPanel(
                    title = tagList(icon("table"), "Table View"),
                    uiOutput("pa_lineup_tables_dynamic")
                  ),
                  
                  # Equations View
                  tabPanel(
                    title = tagList(icon("calculator"), "Equations & Rationale"),
                    uiOutput("pa_lineup_equations_dynamic")
                  )
                )
              )
            )
          )
        )
      ),
      
      # Placeholder tabs (to be implemented)
      tabItem(tabName = "first_principles",
        h2("First Principles Module"),
        p("Module under construction - validates design feasibility based on fundamental RF theory.")
      ),
      
      tabItem(tabName = "architecture",
        h2("Architecture Selection Module"),
        p("Module under construction - recommends PA architecture and topology.")
      ),
      
      tabItem(tabName = "simulation",
        h2("Simulation Module"),
        p("Module under construction - integrates with ADS/AWR via MCP.")
      ),
      
      tabItem(tabName = "layout",
        h2("Layout Module"),
        p("Module under construction - reviews layout for RF best practices.")
      ),
      
      tabItem(tabName = "measurement",
        h2("Measurement Module"),
        p("Module under construction - controls lab equipment and analyzes data.")
      ),
      
      # RF Tools: Smith Chart
      tabItem(tabName = "smith_chart",
        h2("📊 Smith Chart Visualization"),
        fluidRow(
          box(
            title = "Impedance/Admittance Entry",
            width = 4,
            status = "primary",
            solidHeader = TRUE,
            selectInput("smith_mode", "Chart Mode",
              choices = c("Impedance", "Admittance", "Combined")),
            numericInput("smith_z_real", "Z Real (Ω)", value = 50, min = -500, max = 500),
            numericInput("smith_z_imag", "Z Imaginary (Ω)", value = 0, min = -500, max = 500),
            numericInput("smith_freq", "Frequency (GHz)", value = 2.4, min = 0.1, max = 100),
            hr(),
            actionButton("smith_add_point", "Add Point", class = "btn-primary", icon = icon("plus")),
            actionButton("smith_clear", "Clear All", class = "btn-warning", icon = icon("trash")),
            hr(),
            h4("Matching Network Design:"),
            selectInput("smith_match_type", "Network Type",
              choices = c("Single Stub", "Double Stub", "L-Section", "Pi-Network", "T-Network")),
            actionButton("smith_design_match", "Design Network", class = "btn-success", icon = icon("calculator"))
          ),
          box(
            title = "Smith Chart",
            width = 8,
            status = "info",
            solidHeader = TRUE,
            p("Interactive Smith Chart with matching network visualization"),
            plotlyOutput("smith_chart_plot", height = "600px"),
            hr(),
            h4("Component Values:"),
            verbatimTextOutput("smith_components")
          )
        )
      ),
      
      # RF Tools: Converters
      tabItem(tabName = "rf_converters",
        h2("🔄 RF Unit Converters"),
        fluidRow(
          box(
            title = "Power Conversions",
            width = 6,
            status = "primary",
            solidHeader = TRUE,
            numericInput("conv_power_watt", "Power (Watt)", value = 1, min = 0),
            verbatimTextOutput("conv_power_results"),
            hr(),
            numericInput("conv_power_dbm", "Power (dBm)", value = 30, min = -100, max = 100),
            verbatimTextOutput("conv_dbm_results")
          ),
          box(
            title = "Voltage/Field Conversions",
            width = 6,
            status = "info",
            solidHeader = TRUE,
            numericInput("conv_voltage", "Voltage (V)", value = 1, min = 0),
            numericInput("conv_impedance", "Impedance (Ω)", value = 50, min = 0.1),
            verbatimTextOutput("conv_voltage_results")
          )
        ),
        fluidRow(
          box(
            title = "Frequency/Wavelength Conversions",
            width = 6,
            status = "warning",
            solidHeader = TRUE,
            numericInput("conv_freq", "Frequency (GHz)", value = 2.4, min = 0.001),
            selectInput("conv_medium", "Medium",
              choices = c("Free Space" = 1, "FR4 (εr=4.4)" = 4.4, "Rogers RO4003 (εr=3.55)" = 3.55, "Custom" = 0)),
            conditionalPanel(
              condition = "input.conv_medium == 0",
              numericInput("conv_er_custom", "Custom εr", value = 1, min = 1, max = 20)
            ),
            verbatimTextOutput("conv_freq_results")
          ),
          box(
            title = "S-Parameters & Reflection Coefficient",
            width = 6,
            status = "success",
            solidHeader = TRUE,
            numericInput("conv_s11_mag", "S11 Magnitude", value = 0.1, min = 0, max = 1, step = 0.01),
            numericInput("conv_s11_phase", "S11 Phase (degrees)", value = 0, min = -180, max = 180),
            verbatimTextOutput("conv_sparams_results")
          )
        )
      ),
      
      # RF Tools: MTTF Calculator
      tabItem(tabName = "mttf_calc",
        h2("⏱️ MTTF (Mean Time To Failure) Calculator"),
        fluidRow(
          box(
            title = "Device Parameters",
            width = 4,
            status = "primary",
            solidHeader = TRUE,
            selectInput("mttf_device_type", "Device Type",
              choices = c("LDMOS", "GaN HEMT", "SiGe HBT", "GaAs MESFET", "Custom")),
            numericInput("mttf_tj", "Junction Temperature (°C)", value = 125, min = -55, max = 300),
            numericInput("mttf_ta", "Ambient Temperature (°C)", value = 25, min = -55, max = 150),
            numericInput("mttf_power_diss", "Power Dissipation (W)", value = 10, min = 0.1, max = 1000),
            numericInput("mttf_rth", "Thermal Resistance Rθjc (°C/W)", value = 5, min = 0.1, max = 100),
            hr(),
            h4("Stress Factors:"),
            numericInput("mttf_voltage_stress", "Voltage Stress Factor", value = 1.0, min = 0.5, max = 2, step = 0.1),
            numericInput("mttf_current_stress", "Current Stress Factor", value = 1.0, min = 0.5, max = 2, step = 0.1),
            hr(),
            actionButton("mttf_calculate", "Calculate MTTF", class = "btn-success", icon = icon("calculator"))
          ),
          box(
            title = "Reliability Results",
            width = 8,
            status = "info",
            solidHeader = TRUE,
            h4("MTTF Analysis:"),
            verbatimTextOutput("mttf_results"),
            hr(),
            plotlyOutput("mttf_plot", height = "400px"),
            hr(),
            h4("Reliability Recommendations:"),
            htmlOutput("mttf_recommendations")
          )
        )
      ),
      
      # RF Tools: Thermal Analysis
      tabItem(tabName = "thermal_calc",
        h2("🌡️ Thermal Analysis"),
        fluidRow(
          box(
            title = "Thermal Network Parameters",
            width = 4,
            status = "primary",
            solidHeader = TRUE,
            h4("Power Dissipation:"),
            numericInput("therm_pout", "Output Power (W)", value = 20, min = 0.1, max = 1000),
            numericInput("therm_efficiency", "PAE (%)", value = 50, min = 1, max = 90),
            verbatimTextOutput("therm_pdiss"),
            hr(),
            h4("Thermal Resistances:"),
            numericInput("therm_rth_jc", "Rθjc (Junction-to-Case) (°C/W)", value = 2, min = 0.1, max = 50),
            numericInput("therm_rth_cs", "Rθcs (Case-to-Sink) (°C/W)", value = 0.5, min = 0.01, max = 10),
            numericInput("therm_rth_sa", "Rθsa (Sink-to-Ambient) (°C/W)", value = 3, min = 0.1, max = 50),
            hr(),
            numericInput("therm_ta", "Ambient Temperature (°C)", value = 25, min = -55, max = 150),
            numericInput("therm_tj_max", "Max Junction Temp (°C)", value = 150, min = 50, max = 300),
            hr(),
            actionButton("therm_calculate", "Calculate Thermal Profile", class = "btn-success", icon = icon("fire"))
          ),
          box(
            title = "Thermal Analysis Results",
            width = 8,
            status = "danger",
            solidHeader = TRUE,
            h4("Temperature Profile:"),
            verbatimTextOutput("therm_results"),
            hr(),
            plotlyOutput("therm_plot", height = "400px"),
            hr(),
            h4("Heatsink Recommendations:"),
            htmlOutput("therm_recommendations")
          )
        )
      ),
      
      # Settings Tab
      tabItem(tabName = "settings",
        h2("Application Settings"),
        fluidRow(
          box(
            title = "Theme Settings",
            width = 6,
            selectInput("theme_select", "Theme",
              choices = c("Dark Mode" = "dark", "Light Mode" = "light", "Colorblind Mode" = "colorblind")),
            selectInput("accent_color", "Accent Color",
              choices = c("Orange" = "#ff7f11", "Blue" = "#1f77b4", "Green" = "#2ca02c"))
          ),
          box(
            title = "AI Agent Configuration",
            width = 6,
            checkboxInput("agents_enabled", "Enable AI Agents", value = TRUE),
            selectInput("llm_model", "LLM Model",
              choices = c("GPT-4", "GPT-3.5-turbo", "Claude-3-Opus")),
            sliderInput("agent_confidence_threshold", "Confidence Threshold", 
                       min = 0, max = 1, value = 0.7, step = 0.05)
          )
        )
      )
    )
  )
)

# Server Logic
server <- function(input, output, session) {
  
  # Reactive values
  rv <- reactiveValues(
    current_project = NULL,
    projects = data.frame(),
    canvas_names = c("Canvas 1", "Canvas 2", "Canvas 3", "Canvas 4", 
                     "Canvas 5", "Canvas 6", "Canvas 7", "Canvas 8", "Canvas 9")
  )
  
  # Helper function: Get user templates
  getUserTemplates <- function() {
    templates_dir <- file.path("R", "user_templates")
    
    if(!dir.exists(templates_dir)) {
      return(list())
    }
    
    template_files <- list.files(templates_dir, pattern = "\\.json$", full.names = TRUE)
    
    templates <- lapply(template_files, function(filepath) {
      tryCatch({
        template_data <- jsonlite::read_json(filepath, simplifyVector = TRUE)
        list(
          id = paste0("user_", tools::file_path_sans_ext(basename(filepath))),
          name = template_data$name,
          components_count = length(template_data$components),
          filepath = filepath
        )
      }, error = function(e) {
        cat(sprintf("[Template Error] Failed to read %s: %s\n", filepath, e$message))
        NULL
      })
    })
    
    # Remove NULL entries (failed reads)
    Filter(Negate(is.null), templates)
  }
  
  # Helper function: Get canvas count from layout string
  getCanvasCount <- function(layout) {
    if(is.null(layout) || layout == "1x1") {
      return(1)
    }
    
    # Handle special layouts
    if(layout %in% c("2+1", "1+2")) {
      return(3)
    }
    
    # Parse NxM format (e.g., "2x2", "1x3", "4x1", etc.)
    parts <- strsplit(layout, "x")[[1]]
    if(length(parts) == 2) {
      rows <- as.numeric(parts[1])
      cols <- as.numeric(parts[2])
      if(!is.na(rows) && !is.na(cols)) {
        return(rows * cols)
      }
    }
    
    # Fallback to 1 if parsing fails
    return(1)
  }
  
  # Reactive expression for user templates
  userTemplates <- reactive({
    getUserTemplates()
  })
  
  # Send user templates to JavaScript on startup
  observe({
    templates <- userTemplates()
    if(length(templates) > 0) {
      template_info <- lapply(templates, function(t) {
        list(id = t$id, name = t$name, components_count = t$components_count)
      })
      session$sendCustomMessage("updateUserTemplates", template_info)
    }
  })
  
  # Load projects on startup
  observe({
    if (!demo_mode && !is.null(project_mgr)) {
      rv$projects <- project_mgr$get_all_projects()
    } else {
      # Demo mode: use sample data
      rv$projects <- data.frame(
        id = c("demo-1", "demo-2", "demo-3"),
        name = c("5G PA 3.5GHz", "WiFi 6E 6GHz", "Sub-6 GaN"),
        architecture_type = c("Doherty", "Class-AB", "Class-E"),
        frequency = c(3500, 6000, 2600),
        target_pout = c(43, 30, 40),
        status = c("active", "active", "completed"),
        created_at = Sys.time(),
        stringsAsFactors = FALSE
      )
    }
    
    # Update project selection dropdowns
    project_choices <- setNames(rv$projects$id, rv$projects$name)
    updateSelectInput(session, "calc_project_select", choices = project_choices)
  })
  
  # Dashboard: Value Boxes
  output$total_projects <- renderValueBox({
    valueBox(
      nrow(rv$projects),
      "Total Projects",
      icon = icon("folder"),
      color = "blue"
    )
  })
  
  output$active_projects <- renderValueBox({
    active_count <- sum(rv$projects$status == "active", na.rm = TRUE)
    valueBox(
      active_count,
      "Active Projects",
      icon = icon("play-circle"),
      color = "green"
    )
  })
  
  output$success_rate <- renderValueBox({
    valueBox(
      "85%",
      "Success Rate",
      icon = icon("check-circle"),
      color = "yellow"
    )
  })
  
  output$avg_cycle_time <- renderValueBox({
    valueBox(
      "42 days",
      "Avg Cycle Time",
      icon = icon("clock"),
      color = "purple"
    )
  })
  
  # Dashboard: Recent Projects Table
  output$recent_projects_table <- renderDT({
    datatable(
      head(rv$projects, 10),
      options = list(pageLength = 5, dom = 't'),
      selection = 'single'
    )
  })
  
  # Dashboard: Phase Distribution Plot
  output$phase_distribution <- renderPlotly({
    phases <- c("Concept", "Calculation", "Simulation", "Layout", "Measurement")
    counts <- c(3, 5, 8, 2, 1)
    
    plot_ly(labels = phases, values = counts, type = 'pie',
            marker = list(colors = c('#ff7f11', '#ff9f3f', '#ffbf6b', '#ffd89b', '#fff0cc'))) %>%
      layout(showlegend = TRUE, paper_bgcolor = '#0b0b0b', plot_bgcolor = '#0b0b0b',
             font = list(color = '#cfcfcf'))
  })
  
  # Dashboard: Agent Activity
  output$agent_activity <- renderPlotly({
    agents <- c("Theory", "Architecture", "Simulation", "Layout", "Measurement")
    activity <- c(45, 32, 67, 23, 15)
    
    plot_ly(x = agents, y = activity, type = 'bar',
            marker = list(color = '#ff7f11')) %>%
      layout(
        title = "Agent Calls (Last 7 Days)",
        paper_bgcolor = '#0b0b0b',
        plot_bgcolor = '#1b1b1b',
        font = list(color = '#cfcfcf'),
        xaxis = list(title = "Agent", color = '#cfcfcf'),
        yaxis = list(title = "Number of Calls", color = '#cfcfcf')
      )
  })
  
  # Projects: All Projects Table
  output$all_projects_table <- renderDT({
    datatable(
      rv$projects,
      options = list(pageLength = 10),
      selection = 'single'
    )
  })
  
  # Projects: Create New Project
  observeEvent(input$create_project_btn, {
    req(input$new_project_name)
    
    if (!demo_mode && !is.null(project_mgr)) {
      new_project <- project_mgr$create_project(
        name = input$new_project_name,
        architecture_type = input$new_project_arch,
        frequency = input$new_project_freq,
        target_pout = input$new_project_pout
      )
      
      rv$projects <- project_mgr$get_all_projects()
      
      showNotification(
        paste("Project", input$new_project_name, "created successfully!"),
        type = "message",
        duration = 3
      )
    } else {
      # Demo mode: show info message
      showNotification(
        "Demo Mode: Project creation requires database connection. Use theoretical calculations to test features.",
        type = "warning",
        duration = 5
      )
    }
    
    # Clear inputs
    updateTextInput(session, "new_project_name", value = "")
  })
  
  # Theoretical Calc: Display Project Specs
  output$calc_project_specs <- renderText({
    req(input$calc_project_select)
    
    project <- rv$projects[rv$projects$id == input$calc_project_select, ]
    
    if (nrow(project) > 0) {
      paste0(
        "Project: ", project$name, "\n",
        "Architecture: ", project$architecture_type, "\n",
        "Frequency: ", project$frequency, " GHz\n",
        "Target Pout: ", project$target_pout, " dBm\n"
      )
    } else ""
  })
  
  # Theoretical Calc: Load-Pull Calculation
  observeEvent(input$calc_loadpull_btn, {
    req(input$calc_vdd, input$calc_imax)
    
    # Simple load-pull calculation (Class-A approximation)
    pout_watts <- (input$calc_vdd * input$calc_imax) / 2
    pout_dbm <- 10 * log10(pout_watts * 1000)
    z_load <- (input$calc_vdd^2) / (2 * pout_watts)
    
    output$calc_loadpull_results <- renderPrint({
      cat("Optimal Load Impedance (Class-A):\n")
      cat("  Zload =", round(z_load, 2), "Ω\n")
      cat("  Pout (max) =", round(pout_watts, 2), "W (", round(pout_dbm, 1), "dBm)\n")
      cat("  PAE (theoretical max) ≈ 50%\n")
    })
    
    showNotification("Load-pull calculation completed", type = "message")
  })
  
  # Theoretical Calc: Matching Network Synthesis
  observeEvent(input$calc_match_btn, {
    req(input$calc_z_source, input$calc_z_load, input$calc_freq)
    
    z_s <- input$calc_z_source
    z_l <- input$calc_z_load
    freq <- input$calc_freq * 1e9  # Convert to Hz
    
    # Simple L-section matching calculation
    if (z_s > z_l) {
      # Step-down network
      q <- sqrt(z_s / z_l - 1)
      x_series <- q * z_l
      b_parallel <- q / z_s
      
      l_series <- x_series / (2 * pi * freq) * 1e9  # nH
      c_parallel <- b_parallel / (2 * pi * freq) * 1e12  # pF
      
      output$calc_match_results <- renderPrint({
        cat("L-Section Step-Down Network:\n")
        cat("  Series Inductor:", round(l_series, 2), "nH\n")
        cat("  Parallel Capacitor:", round(c_parallel, 2), "pF\n")
        cat("  Q-factor:", round(q, 2), "\n")
      })
    } else {
      # Step-up network
      q <- sqrt(z_l / z_s - 1)
      b_series <- q / z_l
      x_parallel <- q * z_s
      
      c_series <- b_series / (2 * pi * freq) * 1e12  # pF
      l_parallel <- x_parallel / (2 * pi * freq) * 1e9  # nH
      
      output$calc_match_results <- renderPrint({
        cat("L-Section Step-Up Network:\n")
        cat("  Series Capacitor:", round(c_series, 2), "pF\n")
        cat("  Parallel Inductor:", round(l_parallel, 2), "nH\n")
        cat("  Q-factor:", round(q, 2), "\n")
      })
    }
    
    showNotification("Matching network synthesized", type = "message")
  })
  
  # Theoretical Calc: Ask Theory Agent
  observeEvent(input$calc_ask_theory_btn, {
    req(input$calc_theory_query)
    
    showNotification("Theory Agent is processing your query...", type = "message", duration = NULL, id = "theory_notif")
    
    # Call Theory Agent
    tryCatch({
      response <- agent_mgr$call_agent(
        agent_name = "TheoryAgent",
        task = list(
          query = input$calc_theory_query,
          context = list(
            project_id = input$calc_project_select,
            frequency = input$calc_freq
          )
        )
      )
      
      output$calc_theory_response <- renderPrint({
        cat("Theory Agent Response:\n\n")
        cat(response$answer, "\n\n")
        cat("Confidence:", response$confidence, "\n")
        if (!is.null(response$references)) {
          cat("\nReferences:\n")
          cat(paste(response$references, collapse = "\n"))
        }
      })
      
      removeNotification("theory_notif")
      showNotification("Theory Agent response received", type = "message", duration = 3)
      
    }, error = function(e) {
      removeNotification("theory_notif")
      showNotification(paste("Error:", e$message), type = "error", duration = 5)
      
      output$calc_theory_response <- renderPrint({
        cat("Theory Agent is not yet fully implemented.\n")
        cat("Mock response for demo purposes:\n\n")
        cat("Based on your specifications, the fundamental limits are:\n")
        cat("- Bode-Fano limit constrains matching bandwidth\n")
        cat("- Maximum theoretical PAE for Class-A: 50%\n")
        cat("- For higher efficiency, consider Class-E or Class-F\n")
      })
    })
  })
  
  # ============================================================
  # RF Frequency Planning Tool (Integrated)
  # ============================================================
  
  # Physical Models
  atm_loss_model <- function(fGHz) {
    o2_peak <- 15 * exp(-((fGHz - 60)^2) / (2*5^2))
    h2o_peak <- 8 * exp(-((fGHz - 22)^2) / (2*3^2))
    baseline <- 0.01 * fGHz
    baseline + o2_peak + h2o_peak
  }
  
  eff_ldmos <- function(f) pmax(65 - 0.8*f, 5)
  eff_gan   <- function(f) pmax(70 - 0.3*f, 20)
  eff_sige  <- function(f) pmax(50 - 0.15*f, 10)
  
  # Frequency Planning Canvas
  output$freq_planning_canvas <- renderPlotly({
    
    f <- seq(0.1, 300, length.out = 800)
    
    fig <- plot_ly()
    
    # Technology Suitability Map
    if(input$freq_show_tech){
      tech_map <- data.frame(
        tech = c("LDMOS","GaN","SiGe"),
        fmin = c(0.01, 1, 20),
        fmax = c(4, 100, 300),
        color = c("rgba(0,0,255,0.15)",
                  "rgba(0,255,0,0.15)",
                  "rgba(255,0,0,0.15)")
      )
      
      for(i in 1:nrow(tech_map)){
        fig <- fig %>%
          add_trace(
            x = c(tech_map$fmin[i], tech_map$fmax[i],
                  tech_map$fmax[i], tech_map$fmin[i], tech_map$fmin[i]),
            y = c(0, 0, 100, 100, 0),
            type = "scatter",
            mode = "lines",
            fill = "toself",
            fillcolor = tech_map$color[i],
            line = list(width = 0),
            name = tech_map$tech[i],
            hoverinfo = "text",
            text = paste("Technology:", tech_map$tech[i])
          )
      }
    }
    
    # Efficiency curves
    if(input$freq_show_eff){
      fig <- fig %>%
        add_lines(x = f, y = eff_ldmos(f), name = "LDMOS Efficiency (%)") %>%
        add_lines(x = f, y = eff_gan(f), name = "GaN Efficiency (%)") %>%
        add_lines(x = f, y = eff_sige(f), name = "SiGe Efficiency (%)")
    }
    
    # Atmospheric attenuation
    if(input$freq_show_atm){
      fig <- fig %>%
        add_lines(x = f, y = atm_loss_model(f),
                  name = "Atmospheric Loss (dB/km)",
                  yaxis = "y2")
    }
    
    # 6G band
    if(input$freq_show_6g){
      fig <- fig %>%
        add_trace(
          x = c(100, 300, 300, 100, 100),
          y = c(0, 0, 100, 100, 0),
          type = "scatter",
          fill = "toself",
          fillcolor = "rgba(200,0,200,0.2)",
          line = list(width = 0),
          name = "6G Sub-THz",
          hoverinfo = "text",
          text = "6G Candidate Band"
        )
    }
    
    # Target marker
    fig <- fig %>%
      add_markers(x = input$freq_target_freq,
                  y = 60,
                  marker = list(size = 12, color = "red"),
                  name = "Target Frequency")
    
    fig %>%
      layout(
        title = "Interactive Frequency Planning Canvas",
        xaxis = list(title = "Frequency (GHz)", type = "log",
                     range = c(log10(0.1), log10(300))),
        yaxis = list(title = "Efficiency (%)"),
        yaxis2 = list(title = "Atmospheric Loss (dB/km)",
                      overlaying = "y",
                      side = "right"),
        legend = list(orientation = "h"),
        hovermode = "closest"
      )
  })
  
  # Frequency Planning Table
  output$freq_planning_table <- renderDT({
    f_target <- input$freq_target_freq
    
    data <- data.frame(
      Parameter = c("Target Frequency", "LDMOS Efficiency", "GaN Efficiency", "SiGe Efficiency",
                    "Atmospheric Loss", "Wavelength (free space)", "Recommended Technology"),
      Value = c(
        sprintf("%.2f GHz", f_target),
        sprintf("%.1f%%", eff_ldmos(f_target)),
        sprintf("%.1f%%", eff_gan(f_target)),
        sprintf("%.1f%%", eff_sige(f_target)),
        sprintf("%.2f dB/km", atm_loss_model(f_target)),
        sprintf("%.2f mm", 3e8 / (f_target * 1e9) * 1000),
        if(f_target < 4) "LDMOS" else if(f_target < 100) "GaN" else "SiGe"
      )
    )
    
    datatable(data, options = list(pageLength = 10, dom = 't'), rownames = FALSE)
  })
  
  # Technology Recommendation
  output$freq_recommendation <- renderUI({
    
    f <- input$freq_target_freq
    
    tech <- if(f < 4) {
      "LDMOS (High power, macro base stations)"
    } else if(f < 100) {
      "GaN (Best tradeoff efficiency & power density)"
    } else {
      "SiGe / Advanced GaN MMIC (Sub-THz)"
    }
    
    HTML(paste0(
      "<h4>Recommended Technology</h4>",
      "<b>Frequency:</b> ", f, " GHz<br>",
      "<b>Output Power:</b> ", input$freq_target_power, " W<br><br>",
      "<b>Suggested Device:</b> ", tech
    ))
  })
  
  # Technology Selection based on fT and global frequency
  output$technology_fT_recommendation <- renderUI({
    # Use global frequency if available, otherwise use freq_target_freq
    freq <- input$global_frequency
    if(is.null(freq)) freq <- input$freq_target_freq
    if(is.null(freq)) return(NULL)
    
    required_fT <- freq * 5
    
    # Determine recommended technology based on fT requirement
    if(freq < 4) {
      tech <- "Si LDMOS"
      fT_range <- "20-40 GHz"
      expected_gain <- "15-18 dB"
      color <- "primary"
    } else if(freq < 12) {
      tech <- "GaAs pHEMT or GaN HEMT"
      fT_range <- "30-100 GHz"
      expected_gain <- "12-15 dB"
      color <- "success"
    } else if(freq < 40) {
      tech <- "GaN HEMT"
      fT_range <- "50-100 GHz"
      expected_gain <- "10-12 dB"
      color <- "success"
    } else if(freq < 100) {
      tech <- "SiGe HBT or GaN MMIC"
      fT_range <- "200-300 GHz"
      expected_gain <- "8-10 dB"
      color <- "warning"
    } else {
      tech <- "InP HEMT or Advanced SiGe"
      fT_range <- "300-600 GHz"
      expected_gain <- "6-8 dB"
      color <- "danger"
    }
    
    div(
      class = paste0("alert alert-", color),
      style = "margin-top: 15px;",
      HTML(sprintf("
        <h5><i class='fa fa-calculator'></i> Technology Recommendation for %.1f GHz</h5>
        <ul style='margin-bottom: 0;'>
          <li><strong>Minimum required fT:</strong> %.1f GHz (5 × %.1f GHz)</li>
          <li><strong>Recommended Technology:</strong> %s</li>
          <li><strong>Typical fT Range:</strong> %s</li>
          <li><strong>Expected Stage Gain:</strong> %s</li>
        </ul>
      ", freq, required_fT, freq, tech, fT_range, expected_gain))
    )
  })
  
  # ============================================================
  # Global Lineup Parameters - Pavg Calculation
  # ============================================================
  
  output$calculated_Pavg <- renderText({
    # CRITICAL FIX: Calculate Pavg from SPECIFICATIONS (P3dB - PAR), not from components!
    # The specification defines the system operating points, not the component calculations.
    
    # Get specification values
    p3db <- input$spec_p3db
    par <- input$spec_par
    
    # Validate inputs
    if(is.null(p3db) || is.null(par)) {
      # Fallback: try to get from components if specs not available
      components <- lineup_components()
      if(is.null(components) || length(components) == 0) {
        return("N/A")
      }
      
      # Find final output power (last transistor in chain)
      final_pout <- 43  # default
      for(comp in components) {
        if(!is.null(comp$type) && comp$type == "transistor") {
          if(!is.null(comp$properties) && !is.null(comp$properties$pout)) {
            final_pout <- comp$properties$pout
          }
        }
      }
      
      backoff <- input$global_backoff
      if(is.null(backoff)) backoff <- 6
      pavg <- final_pout - backoff
    } else {
      # ✓ CORRECT: Pavg = P3dB - PAR (from specifications)
      pavg <- p3db - par
    }
    
    return(sprintf("%.1f dBm", pavg))
  })
  
  # Calculated Pin from Global Parameters (based on specs)
  output$calculated_Pin_global <- renderText({
    req(input$global_pout_p3db, input$spec_gain)
    
    pin_calc <- input$global_pout_p3db - input$spec_gain
    
    return(sprintf("%.1f dBm", pin_calc))
  })
  
  # Derived spec outputs: Pavg and Pin (back-calculated, read-only in UI)
  output$spec_pavg_display <- renderText({
    req(input$spec_p3db, input$spec_par)
    pavg <- input$spec_p3db - input$spec_par
    sprintf("%.1f", pavg)
  })

  output$spec_pin_display <- renderText({
    req(input$spec_p3db, input$spec_gain)
    pin_calc <- input$spec_p3db - input$spec_gain
    sprintf("%.1f", pin_calc)
  })

  # Bandwidth Display in Specifications
  output$spec_bandwidth_display <- renderText({
    req(input$spec_frequency, input$spec_bw_lower, input$spec_bw_upper)
    
    freq_mhz <- input$spec_frequency
    bw_lower_pct <- input$spec_bw_lower / 100
    bw_upper_pct <- input$spec_bw_upper / 100
    
    bw_total <- freq_mhz * (bw_lower_pct + bw_upper_pct)
    
    return(sprintf("%.0f", bw_total))
  })
  
  # ============================================================
  # Loss Curves Tab - Plotting and Calculations
  # ============================================================
  
  # Loss estimation function (matching JavaScript implementation)
  estimatePassiveLoss_R <- function(type, freq_ghz) {
    loss_db <- 0
    
    if (type == "transmission_line") {
      # Microstrip on FR4, 10cm length
      loss_db <- (0.05 + 0.15 * sqrt(freq_ghz) + 0.02 * freq_ghz) * 1.0  # per 10cm
    } else if (type == "wilkinson_splitter") {
      # 2-way Wilkinson with quarter-wave transformer
      loss_db <- 3.0 + 0.1 + 0.05 * freq_ghz
    } else if (type == "wilkinson_combiner") {
      loss_db <- 3.0 + 0.1 + 0.05 * freq_ghz
    } else if (type == "quadrature_hybrid") {
      # 90-degree coupler
      loss_db <- 0.3 + 0.08 * freq_ghz + 0.02 * freq_ghz^1.5
    } else if (type == "t_junction") {
      loss_db <- 0.05 + 0.03 * freq_ghz
    } else if (type == "doherty_combiner") {
      # Lower loss than Wilkinson
      loss_db <- 0.2 + 0.02 * freq_ghz + 0.01 * freq_ghz^1.3
    } else if (type == "transformer") {
      # 1:1 transformer
      if (freq_ghz < 0.5) {
        loss_db <- 0.3 + 0.05 * freq_ghz
      } else if (freq_ghz < 3) {
        loss_db <- 0.2 + 0.03 * (freq_ghz - 0.5)
      } else {
        loss_db <- 0.4 + 0.1 * (freq_ghz - 3)
      }
    }
    
    return(loss_db)
  }
  
  # Loss Curves Plot
  output$loss_curves_plot <- renderPlotly({
    req(input$loss_curve_components)
    
    # Generate frequency range
    freq_range <- seq(0.5, 30, by = 0.1)
    
    # Component names for legend
    component_names <- list(
      "wilkinson_splitter" = "Wilkinson Splitter (2-way)",
      "wilkinson_combiner" = "Wilkinson Combiner (2-way)",
      "quadrature_hybrid" = "Quadrature Hybrid (90°)",
      "t_junction" = "T-Junction Splitter",
      "transmission_line" = "Transmission Line (10cm)",
      "doherty_combiner" = "Doherty Combiner",
      "transformer" = "Transformer (1:1)"
    )
    
    # Component colors
    component_colors <- list(
      "wilkinson_splitter" = "#e74c3c",
      "wilkinson_combiner" = "#3498db",
      "quadrature_hybrid" = "#2ecc71",
      "t_junction" = "#f39c12",
      "transmission_line" = "#9b59b6",
      "doherty_combiner" = "#1abc9c",
      "transformer" = "#e67e22"
    )
    
    # Create empty plot
    p <- plot_ly()
    
    # Add trace for each selected component
    for (comp_type in input$loss_curve_components) {
      loss_values <- sapply(freq_range, function(f) estimatePassiveLoss_R(comp_type, f))
      
      p <- p %>% add_trace(
        x = freq_range,
        y = loss_values,
        type = 'scatter',
        mode = 'lines',
        name = component_names[[comp_type]],
        line = list(color = component_colors[[comp_type]], width = 2.5),
        hovertemplate = paste0(
          '<b>', component_names[[comp_type]], '</b><br>',
          'Frequency: %{x:.2f} GHz<br>',
          'Loss: %{y:.2f} dB<br>',
          '<extra></extra>'
        )
      )
    }
    
    # Layout
    p <- p %>% layout(
      title = list(
        text = "<b>Passive Component Loss vs Frequency</b>",
        font = list(size = 16)
      ),
      xaxis = list(
        title = "Frequency (GHz)",
        gridcolor = '#e0e0e0',
        zeroline = FALSE
      ),
      yaxis = list(
        title = "Insertion Loss (dB)",
        gridcolor = '#e0e0e0',
        zeroline = FALSE
      ),
      hovermode = 'closest',
      legend = list(
        x = 0.02,
        y = 0.98,
        bgcolor = 'rgba(255, 255, 255, 0.9)',
        bordercolor = '#999',
        borderwidth = 1
      ),
      plot_bgcolor = '#f8f9fa',
      paper_bgcolor = 'white'
    )
    
    return(p)
  })
  
  # Loss Calculator Result
  output$loss_calc_result <- renderText({
    req(input$loss_calc_freq, input$loss_calc_type)
    
    loss_db <- estimatePassiveLoss_R(input$loss_calc_type, input$loss_calc_freq)
    
    return(sprintf("%.2f", loss_db))
  })
  
  # ============================================================
  # Link Budget Calculator
  # ============================================================
  
  # Reactive values for link budget
  link_budget_data <- reactive({
    input$link_calculate
    
    # Calculate FSPL (Free Space Path Loss)
    fspl <- 20 * log10(input$link_distance) + 20 * log10(input$link_freq) + 92.45
    
    # Calculate received power
    p_rx <- input$link_tx_power + input$link_tx_gain - fspl + input$link_rx_gain
    
    # Calculate noise power
    bw_hz <- input$link_bandwidth * 1e6
    noise_power <- -174 + 10 * log10(bw_hz) + input$link_noise_figure
    
    # Calculate SNR
    snr <- p_rx - noise_power
    
    # Calculate margin
    margin <- snr - input$link_snr_req
    
    list(
      fspl = fspl,
      p_rx = p_rx,
      noise_power = noise_power,
      snr = snr,
      margin = margin,
      status = if(margin > 0) "PASS" else "FAIL"
    )
  })
  
  # Link Budget Canvas
  output$link_budget_canvas <- renderPlotly({
    ld <- link_budget_data()
    
    # Visual representation of link budget stages
    stages <- c("Tx Power", "Tx Gain", "Path Loss", "Rx Gain", "Rx Power", "Noise", "SNR")
    values <- c(
      input$link_tx_power,
      input$link_tx_power + input$link_tx_gain,
      input$link_tx_power + input$link_tx_gain - ld$fspl,
      ld$p_rx,
      ld$p_rx,
      ld$noise_power,
      ld$snr
    )
    
    x_pos <- 1:7
    colors <- c("blue", "green", "red", "green", "orange", "purple", 
                if(ld$margin > 0) "green" else "red")
    
    # Create visual flow diagram
    fig <- plot_ly()
    
    # Add bars showing power levels
    for(i in 1:length(stages)) {
      fig <- fig %>%
        add_trace(
          x = x_pos[i],
          y = values[i],
          type = "bar",
          name = stages[i],
          marker = list(color = colors[i]),
          text = sprintf("%s<br>%.2f dBm", stages[i], values[i]),
          hoverinfo = "text"
        )
    }
    
    # Add connection arrows annotations
    annotations <- list()
    for(i in 1:(length(stages)-1)) {
      annotations[[i]] <- list(
        x = x_pos[i] + 0.5,
        y = max(values) * 0.9,
        text = "→",
        showarrow = FALSE,
        font = list(size = 20)
      )
    }
    
    # Add margin line
    fig <- fig %>%
      add_trace(
        x = x_pos,
        y = rep(input$link_snr_req + ld$noise_power, length(x_pos)),
        type = "scatter",
        mode = "lines",
        name = "Required Power",
        line = list(color = "red", dash = "dash", width = 2)
      )
    
    fig %>%
      layout(
        title = sprintf("Link Budget Canvas - Margin: %.2f dB (%s)", ld$margin, ld$status),
        xaxis = list(title = "Link Budget Stages", tickvals = x_pos, ticktext = stages),
        yaxis = list(title = "Power Level (dBm)"),
        showlegend = TRUE,
        annotations = annotations,
        hovermode = "closest"
      )
  })
  
  # Link Budget Table
  output$link_budget_table <- renderDT({
    ld <- link_budget_data()
    
    data <- data.frame(
      Parameter = c(
        "Tx Power", "Tx Antenna Gain", "EIRP", "Free Space Path Loss",
        "Rx Antenna Gain", "Received Power", "Noise Power", "SNR", 
        "Required SNR", "Link Margin", "Status"
      ),
      Value = c(
        sprintf("%.2f dBm", input$link_tx_power),
        sprintf("%.2f dBi", input$link_tx_gain),
        sprintf("%.2f dBm", input$link_tx_power + input$link_tx_gain),
        sprintf("%.2f dB", ld$fspl),
        sprintf("%.2f dBi", input$link_rx_gain),
        sprintf("%.2f dBm", ld$p_rx),
        sprintf("%.2f dBm", ld$noise_power),
        sprintf("%.2f dB", ld$snr),
        sprintf("%.2f dB", input$link_snr_req),
        sprintf("%.2f dB", ld$margin),
        ld$status
      ),
      Unit = c("dBm", "dBi", "dBm", "dB", "dBi", "dBm", "dBm", "dB", "dB", "dB", "-")
    )
    
    datatable(data, options = list(pageLength = 15, dom = 't'), rownames = FALSE) %>%
      formatStyle('Value', 
        target = 'row',
        backgroundColor = styleEqual(c('FAIL', 'PASS'), c('rgba(255,0,0,0.2)', 'rgba(0,255,0,0.2)'))
      )
  })
  
  # Link Budget Summary
  output$link_budget_summary <- renderUI({
    ld <- link_budget_data()
    
    color <- if(ld$margin > 10) "green" else if(ld$margin > 0) "orange" else "red"
    status_icon <- if(ld$margin > 0) "✓" else "✗"
    
    HTML(paste0(
      "<h4 style='color:", color, ";'>", status_icon, " Link Budget Summary</h4>",
      "<b>Distance:</b> ", input$link_distance, " km<br>",
      "<b>Frequency:</b> ", input$link_freq, " GHz<br>",
      "<b>Path Loss:</b> ", sprintf("%.2f dB", ld$fspl), "<br>",
      "<b>Received Power:</b> ", sprintf("%.2f dBm", ld$p_rx), "<br>",
      "<b>SNR:</b> ", sprintf("%.2f dB", ld$snr), "<br>",
      "<b>Link Margin:</b> <span style='font-size:18px;'><b>", sprintf("%.2f dB", ld$margin), "</b></span><br><br>",
      if(ld$margin > 10) {
        "<p style='color:green;'>✓ Excellent link margin - system is robust against fading</p>"
      } else if(ld$margin > 3) {
        "<p style='color:orange;'>⚠ Adequate margin but consider adding fade margin for reliability</p>"
      } else if(ld$margin > 0) {
        "<p style='color:orange;'>⚠ Marginal - vulnerable to atmospheric effects and multipath</p>"
      } else {
        "<p style='color:red;'>✗ Insufficient margin - link will fail. Increase Tx power, antenna gain, or reduce distance</p>"
      }
    ))
  })
  
  # ============================================================
  # PA Lineup Calculator (Interactive D3.js Canvas Version)
  # ============================================================
  
  # Reactive values for PA lineup state
  lineup_components <- reactiveVal(list())
  lineup_connections <- reactiveVal(list())
  lineup_calc_results <- reactiveVal(NULL)
  
  # Per-canvas storage for multi-canvas comparison
  canvas_data <- reactiveValues(
    canvas_0 = list(components = list(), connections = list(), results = NULL),
    canvas_1 = list(components = list(), connections = list(), results = NULL),
    canvas_2 = list(components = list(), connections = list(), results = NULL),
    canvas_3 = list(components = list(), connections = list(), results = NULL),
    canvas_4 = list(components = list(), connections = list(), results = NULL),
    canvas_5 = list(components = list(), connections = list(), results = NULL),
    canvas_6 = list(components = list(), connections = list(), results = NULL),
    canvas_7 = list(components = list(), connections = list(), results = NULL),
    canvas_8 = list(components = list(), connections = list(), results = NULL)
  )
  
  active_canvas_index <- reactiveVal(0)
  
  # Track active canvas changes
  observeEvent(input$active_canvas, {
    if(!is.null(input$active_canvas)) {
      active_canvas_index(input$active_canvas)
      cat(sprintf("[Active Canvas] Changed to: %d\n", input$active_canvas))
    }
  })
  
  # Update component list when canvas changes
  observeEvent(input$lineup_components, {
    if(!is.null(input$lineup_components)) {
      # Components are sent as a JSON string from JavaScript
      comps_json <- input$lineup_components
      
      cat(sprintf("[Components Update] Received data from JavaScript\n"))
      cat(sprintf("[Components Update] Data class: %s, length: %d\n", class(comps_json), length(comps_json)))
      cat(sprintf("[Components Update] First 200 chars: %s\n", substr(comps_json, 1, 200)))
      
      # Parse JSON string to R list
      comps <- tryCatch({
        parsed <- jsonlite::fromJSON(comps_json, simplifyVector = FALSE)
        cat(sprintf("[Components Update] Successfully parsed %d components\n", length(parsed)))
        
        if(length(parsed) > 0) {
          cat(sprintf("[Components Update] First component - ID: %s, Type: %s\n", 
                      if(!is.null(parsed[[1]]$id)) parsed[[1]]$id else "NULL",
                      if(!is.null(parsed[[1]]$type)) parsed[[1]]$type else "NULL"))
        }
        
        parsed
      }, error = function(e) {
        cat(sprintf("[Components Update] JSON parse error: %s\n", e$message))
        cat(sprintf("[Components Update] Full JSON string length: %d\n", nchar(comps_json)))
        list()
      })
      
      # Store the parsed components (global - backwards compatibility)
      lineup_components(comps)
      
      # Also store per-canvas
      canvas_idx <- active_canvas_index()
      canvas_key <- paste0("canvas_", canvas_idx)
      canvas_data[[canvas_key]]$components <- comps
      cat(sprintf("[Components Update] Stored %d components for canvas %d\n", length(comps), canvas_idx))
    }
  })
  
  # Update connections when canvas changes
  observeEvent(input$lineup_connections, {
    if(!is.null(input$lineup_connections)) {
      # Connections are sent as a JSON string from JavaScript
      conns_json <- input$lineup_connections
      
      cat(sprintf("[Connections Update] Received data from JavaScript\n"))
      
      # Parse JSON string to R list
      conns <- tryCatch({
        parsed <- jsonlite::fromJSON(conns_json, simplifyVector = FALSE)
        cat(sprintf("[Connections Update] Successfully parsed %d connections\n", length(parsed)))
        parsed
      }, error = function(e) {
        cat(sprintf("[Connections Update] JSON parse error: %s\n", e$message))
        list()
      })
      
      # Store the parsed connections (global - backwards compatibility)
      lineup_connections(conns)
      
      # Also store per-canvas
      canvas_idx <- active_canvas_index()
      canvas_key <- paste0("canvas_", canvas_idx)
      canvas_data[[canvas_key]]$connections <- conns
      cat(sprintf("[Connections Update] Stored %d connections for canvas %d\n", length(conns), canvas_idx))
    }
  })
  
  # Observer for canvas layout changes
  observeEvent(input$canvas_layout, {
    if(!is.null(input$canvas_layout)) {
      cat(sprintf("[Canvas Layout] Changed to: %s\n", input$canvas_layout))
      
      # Send layout update to JavaScript
      session$sendCustomMessage("updateCanvasLayout", list(
        layout = input$canvas_layout
      ))
    }
  }, ignoreInit = TRUE)
  
  # Observer for editing canvas names
  observeEvent(input$edit_canvas_names, {
    layout <- input$canvas_layout
    canvas_count <- getCanvasCount(layout)
    
    showModal(modalDialog(
      title = "Edit Canvas Names",
      size = "m",
      footer = tagList(
        modalButton("Cancel"),
        actionButton("save_canvas_names", "Save", class = "btn-primary")
      ),
      div(
        style = "max-height: 500px; overflow-y: auto;",
        lapply(1:canvas_count, function(i) {
          textInput(
            paste0("canvas_name_", i),
            label = sprintf("Canvas %d Name:", i),
            value = rv$canvas_names[i],
            placeholder = sprintf("Canvas %d", i)
          )
        })
      )
    ))
  })
  
  # Observer for saving canvas names
  observeEvent(input$save_canvas_names, {
    layout <- input$canvas_layout
    canvas_count <- getCanvasCount(layout)
    
    # Update canvas names from inputs
    for(i in 1:canvas_count) {
      input_id <- paste0("canvas_name_", i)
      if(!is.null(input[[input_id]]) && nchar(trimws(input[[input_id]])) > 0) {
        rv$canvas_names[i] <- trimws(input[[input_id]])
      } else {
        rv$canvas_names[i] <- sprintf("Canvas %d", i)
      }
    }
    
    # Send updated names to JavaScript
    session$sendCustomMessage("updateCanvasNames", list(
      names = rv$canvas_names[1:canvas_count]
    ))
    
    cat(sprintf("[Canvas Names] Updated: %s\n", paste(rv$canvas_names[1:canvas_count], collapse = ", ")))
    
    removeModal()
  })
  
  # Dynamic Property Editor based on selected component
  output$lineup_property_editor <- renderUI({
    selected <- input$lineup_selected_component
    
    cat(sprintf("[Property Editor] renderUI called, selected = %s\n", 
                if(is.null(selected)) "NULL" else selected))
    
    if(is.null(selected) || length(selected) == 0) {
      return(tags$div(
        style = "padding: 20px; text-align: center; color: #888;",
        tags$p("Select a component on canvas to edit properties")
      ))
    }
    
    components <- lineup_components()
    cat(sprintf("[Property Editor] Components count: %d\n", length(components)))
    
    if(is.null(components) || length(components) == 0) {
      return(tags$div(style = "padding: 20px;", "No components in lineup"))
    }
    
    # Debug: Print component structure
    cat("[Property Editor] Component IDs in list:\n")
    for(i in seq_along(components)) {
      c <- components[[i]]
      comp_id <- if(is.list(c) && !is.null(c$id)) c$id else "NO_ID"
      comp_type <- if(is.list(c) && !is.null(c$type)) c$type else "NO_TYPE"
      cat(sprintf("  [%d] ID=%s, Type=%s\n", i, comp_id, comp_type))
    }
    cat(sprintf("[Property Editor] Looking for component with ID: %s (class: %s)\n", 
                selected, class(selected)))
    
    # Debug: Check component structure
    # print(paste("Selected component ID:", selected))
    # print(paste("Components structure:", str(components)))
    
    # Find the selected component
    comp <- NULL
    tryCatch({
      for(i in seq_along(components)) {
        c <- components[[i]]
        # Handle both list and vector access
        comp_id <- if(is.list(c)) c$id else if(is.vector(c) && "id" %in% names(c)) c["id"] else NULL
        
        cat(sprintf("[Property Editor] Checking component %d: ID=%s (class: %s), selected=%s (class: %s), match=%s\n", 
                    i, comp_id, class(comp_id), selected, class(selected), 
                    if(!is.null(comp_id)) comp_id == selected else "NULL_ID"))
        
        if(!is.null(comp_id) && comp_id == selected) {
          comp <- c
          cat(sprintf("[Property Editor] MATCH FOUND at index %d!\n", i))
          break
        }
      }
    }, error = function(e) {
      cat(sprintf("[Property Editor] ERROR finding component: %s\n", e$message))
      print(e)
    })
    
    if(is.null(comp)) {
      cat(sprintf("[Property Editor] Component %s NOT FOUND!\n", selected))
      return(tags$div(
        style = "padding: 20px; color: #888;",
        "Component not found. ID: ", selected,
        tags$br(),
        tags$small("Try clicking on a component again")
      ))
    }
    
    cat(sprintf("[Property Editor] Component found! Type: %s\n", 
                if(is.list(comp) && !is.null(comp$type)) comp$type else "unknown"))
    
    # Safely extract properties
    tryCatch({
      # Handle both list and vector access
      props <- if(is.list(comp) && !is.null(comp$properties)) {
        comp$properties
      } else if("properties" %in% names(comp)) {
        comp[["properties"]]
      } else {
        list()
      }
      
      comp_type <- if(is.list(comp) && !is.null(comp$type)) {
        comp$type
      } else if("type" %in% names(comp)) {
        comp[["type"]]
      } else {
        "unknown"
      }
      
      # Helper function to safely get property value
      getProp <- function(name, default = "") {
        if(is.list(props) && !is.null(props[[name]])) {
          return(props[[name]])
        } else if(!is.null(names(props)) && name %in% names(props)) {
          return(props[[name]])
        } else {
          return(default)
        }
      }
      
      # Generate property inputs based on component type
      if(comp_type == "transistor") {
        cat(sprintf("[Property Editor] Generating UI for transistor component %s\n", selected))
        tagList(
          h4(paste0("Transistor: ", getProp("label", "Transistor"))),
          textInput(paste0("prop_", selected, "_label"), "Label", 
            value = getProp("label", "Transistor")),
          selectizeInput(paste0("prop_", selected, "_technology"), "Technology", 
            choices = c("GaN", "GaN_Si", "GaN_SiC", "LDMOS", "GaAs", "SiC", "Si-LDMOS", "InP", "GaN-HEMT"),
            selected = getProp("technology", "GaN"),
            options = list(
              create = TRUE,
              placeholder = 'Select or type custom technology'
            )),
          selectInput(paste0("prop_", selected, "_biasClass"), "Biasing Class",
            choices = c("A", "AB", "B", "C", "D", "E", "F"),
            selected = getProp("biasClass", "AB")),
          hr(),
          h5("Performance Parameters"),
          numericInput(paste0("prop_", selected, "_pout"), "Pout (dBm)", 
            value = as.numeric(getProp("pout", 43)), step = 0.5),
          numericInput(paste0("prop_", selected, "_p1db"), "P1dB (dBm)", 
            value = as.numeric(getProp("p1db", 43)), step = 0.5),
          numericInput(paste0("prop_", selected, "_gain"), "Gain (dB)", 
            value = as.numeric(getProp("gain", 15)), step = 0.1),
          numericInput(paste0("prop_", selected, "_pae"), "PAE (%)", 
            value = as.numeric(getProp("pae", 50)), min = 0, max = 100, step = 1),
          hr(),
          h5("Electrical"),
          numericInput(paste0("prop_", selected, "_vdd"), "VDD (V)", 
            value = as.numeric(getProp("vdd", 28)), step = 0.5),
          numericInput(paste0("prop_", selected, "_rth"), "Rth (°C/W)", 
            value = as.numeric(getProp("rth", 2.5)), step = 0.1),
          numericInput(paste0("prop_", selected, "_freq"), "Frequency (GHz)", 
            value = as.numeric(getProp("freq", 2.6)), step = 0.1),
          hr(),
          h5("Display on Canvas"),
          div(style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;",
            checkboxGroupInput(paste0("prop_", selected, "_display"),
              label = NULL,
              choices = c(
                "Label" = "label",
                "Technology" = "technology",
                "Bias Class" = "biasClass",
                "Gain (dB)" = "gain",
                "PAE (%)" = "pae",
                "Pout (dBm)" = "pout",
                "P1dB (dBm)" = "p1db",
                "VDD (V)" = "vdd",
                "Freq (GHz)" = "freq"
              ),
              selected = c("technology", "pout"),
              inline = FALSE
            )
          ),
          hr(),
          actionButton(paste0("apply_props_", selected), "Apply Changes", 
            class = "btn-primary btn-block",
            onclick = paste0("console.log('Apply button clicked: apply_props_", selected, "');"))
        )
      } else if(comp_type == "matching") {
        tagList(
          h4(paste0("Matching Network: ", getProp("label", "Matching"))),
          textInput(paste0("prop_", selected, "_label"), "Label", 
            value = getProp("label", "Matching")),
          selectInput(paste0("prop_", selected, "_type"), "Type", 
            choices = c("L-section", "Pi", "T", "Transformer", "TL-stub"),
            selected = getProp("type", "L-section")),
          numericInput(paste0("prop_", selected, "_loss"), "Loss (dB)", 
            value = as.numeric(getProp("loss", 0.5)), min = 0, step = 0.05),
          numericInput(paste0("prop_", selected, "_z_in"), "Z_in (Ω)", 
            value = as.numeric(getProp("z_in", 50)), step = 0.5),
          numericInput(paste0("prop_", selected, "_z_out"), "Z_out (Ω)", 
            value = as.numeric(getProp("z_out", 50)), step = 0.5),
          numericInput(paste0("prop_", selected, "_bandwidth"), "Bandwidth (%)", 
            value = as.numeric(getProp("bandwidth", 10)), step = 1),
          hr(),
          h5("Display on Canvas"),
          div(style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;",
            checkboxGroupInput(paste0("prop_", selected, "_display"),
              label = NULL,
              choices = c(
                "Label" = "label",
                "Type" = "type",
                "Loss (dB)" = "loss",
                "Z_in (\u03A9)" = "z_in",
                "Z_out (\u03A9)" = "z_out",
                "Bandwidth (%)" = "bandwidth"
              ),
              selected = c("label", "loss"),
              inline = FALSE
            )
          ),
          hr(),
          actionButton(paste0("apply_props_", selected), "Apply Changes", 
            class = "btn-primary btn-block",
            onclick = paste0("console.log('Apply button clicked: apply_props_", selected, "');"))
        )
      } else if(comp_type == "splitter") {
        tagList(
          h4(paste0("Splitter: ", getProp("label", "Splitter"))),
          textInput(paste0("prop_", selected, "_label"), "Label", 
            value = getProp("label", "Splitter")),
          selectInput(paste0("prop_", selected, "_type"), "Type", 
            choices = c("Wilkinson", "Hybrid", "T-junction", "Branchline"),
            selected = getProp("type", "Wilkinson")),
          numericInput(paste0("prop_", selected, "_loss"), "Insertion Loss (dB)", 
            value = as.numeric(getProp("loss", 0.3)), min = 0, step = 0.05),
          numericInput(paste0("prop_", selected, "_isolation"), "Isolation (dB)", 
            value = as.numeric(getProp("isolation", 20)), step = 1),
          numericInput(paste0("prop_", selected, "_split_ratio"), "Split Ratio (dB)", 
            value = as.numeric(getProp("split_ratio", 0)), step = 0.5),
          hr(),
          h5("Display on Canvas"),
          div(style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;",
            checkboxGroupInput(paste0("prop_", selected, "_display"),
              label = NULL,
              choices = c(
                "Label" = "label",
                "Type" = "type",
                "Loss (dB)" = "loss",
                "Isolation (dB)" = "isolation",
                "Split Ratio (dB)" = "split_ratio"
              ),
              selected = c("label", "loss"),
              inline = FALSE
            )
          ),
          hr(),
          actionButton(paste0("apply_props_", selected), "Apply Changes", 
            class = "btn-primary btn-block",
            onclick = paste0("console.log('Apply button clicked: apply_props_", selected, "');"))
        )
      } else if(comp_type == "combiner") {
        tagList(
          h4(paste0("Combiner: ", getProp("label", "Combiner"))),
          textInput(paste0("prop_", selected, "_label"), "Label", 
            value = getProp("label", "Combiner")),
          selectInput(paste0("prop_", selected, "_type"), "Type", 
            choices = c("Wilkinson", "Hybrid", "Doherty", "Chireix", "Outphasing"),
            selected = getProp("type", "Wilkinson")),
          numericInput(paste0("prop_", selected, "_loss"), "Insertion Loss (dB)", 
            value = as.numeric(getProp("loss", 0.3)), min = 0, step = 0.05),
          numericInput(paste0("prop_", selected, "_isolation"), "Isolation (dB)", 
            value = as.numeric(getProp("isolation", 20)), step = 1),
          checkboxInput(paste0("prop_", selected, "_load_modulation"), "Load Modulation", 
            value = isTRUE(getProp("load_modulation", FALSE))),
          conditionalPanel(
            condition = sprintf("input['prop_%s_load_modulation'] == true", selected),
            numericInput(paste0("prop_", selected, "_modulation_factor"), "Modulation Factor", 
              value = as.numeric(getProp("modulation_factor", 2.0)), 
              min = 1, max = 4, step = 0.1)
          ),
          hr(),
          h5("Display on Canvas"),
          div(style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;",
            checkboxGroupInput(paste0("prop_", selected, "_display"),
              label = NULL,
              choices = c(
                "Label" = "label",
                "Type" = "type",
                "Loss (dB)" = "loss",
                "Isolation (dB)" = "isolation",
                "Load Mod" = "load_modulation"
              ),
              selected = c("label", "loss"),
              inline = FALSE
            )
          ),
          hr(),
          actionButton(paste0("apply_props_", selected), "Apply Changes", 
            class = "btn-primary btn-block",
            onclick = paste0("console.log('Apply button clicked: apply_props_", selected, "');"))
        )
      } else if(comp_type == "termination") {
        tagList(
          h4(paste0("Termination: ", getProp("label", "Term"))),
          textInput(paste0("prop_", selected, "_label"), "Label", 
            value = getProp("label", "Term")),
          numericInput(paste0("prop_", selected, "_impedance"), "Impedance (Ω)", 
            value = as.numeric(getProp("impedance", 50)), 
            min = 1, max = 1000, step = 1),
          selectInput(paste0("prop_", selected, "_type"), "Type", 
            choices = c("Matched Load" = "matched", 
                       "Open Circuit" = "open", 
                       "Short Circuit" = "short",
                       "Custom" = "custom"),
            selected = getProp("type", "matched")),
          hr(),
          h5("Display on Canvas"),
          div(style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;",
            checkboxGroupInput(paste0("prop_", selected, "_display"),
              label = NULL,
              choices = c(
                "Label" = "label",
                "Impedance (Ω)" = "impedance"
              ),
              selected = c("label", "impedance"),
              inline = FALSE
            )
          ),
          hr(),
          p(class = "text-muted", style = "font-size: 11px;",
            icon("info-circle"), " Termination loads absorb power. ",
            "Connect signal (positive end) via wire-snap to circuit."
          ),
          actionButton(paste0("apply_props_", selected), "Apply Changes", 
            class = "btn-primary btn-block",
            onclick = paste0("console.log('Apply button clicked: apply_props_", selected, "');"))
        )
      } else if(comp_type == "offset_line") {
        tagList(
          h4(paste0("\u03bb/4 Line: ", getProp("label", "\u03bb/4 Line"))),
          textInput(paste0("prop_", selected, "_label"), "Label",
            value = getProp("label", "\u03bb/4 Line")),
          selectInput(paste0("prop_", selected, "_offset_role"), "Role",
            choices = c(
              "Phase Offset (Input)" = "phase",
              "Impedance Inverter (Output)" = "inverter",
              "Transformer" = "transformer"
            ),
            selected = getProp("offset_role", "phase")),
          numericInput(paste0("prop_", selected, "_phase_shift_deg"), "Phase Shift (\u00b0)",
            value = as.numeric(getProp("phase_shift_deg", 90)),
            min = 0, max = 360, step = 1),
          numericInput(paste0("prop_", selected, "_impedance"), "Z\u2080 (\u03a9)",
            value = as.numeric(getProp("impedance", 50)),
            min = 1, step = 0.5),
          numericInput(paste0("prop_", selected, "_loss"), "Insertion Loss (dB)",
            value = as.numeric(getProp("loss", 0.2)),
            min = 0, step = 0.05),
          hr(),
          h5("Display on Canvas"),
          checkboxGroupInput(paste0("prop_", selected, "_display"), label = NULL,
            choices = c(
              "Label" = "label",
              "Phase (\u00b0)" = "phase",
              "Loss (dB)" = "loss",
              "Z\u2080 (\u03a9)" = "impedance"
            ),
            selected = c("label", "phase"),
            inline = FALSE
          ),
          hr(),
          actionButton(paste0("apply_props_", selected), "Apply Changes",
            class = "btn-primary btn-block",
            onclick = paste0("console.log('Apply button clicked: apply_props_", selected, "');"))
        )
      } else {
        tagList(
          h4("Unknown Component Type"),
          p(paste0("Type: ", comp_type)),
          p("This component type is not yet supported for editing")
        )
      }
    }, error = function(e) {
      tags$div(
        class = "alert alert-danger",
        tags$h4("Error Loading Properties"),
        tags$p("Could not parse component data:"),
        tags$pre(e$message),
        tags$small("This is a data structure issue. Check browser console for details.")
      )
    })
  })
  
  # PA Lineup Calculation Engine with Rationale
  lineup_calculate_engine <- function(components, connections, input_power_dbm = 0, backoff_db = 6) {
    if(is.null(components) || length(components) == 0) {
      return(list(
        success = FALSE,
        message = "No components in lineup",
        rationale = "Cannot perform calculations without components."
      ))
    }
    
    # Helper function to safely extract property values
    safeProp <- function(props, name, default) {
      if(is.null(props)) return(default)
      
      if(is.list(props) && !is.null(props[[name]])) {
        return(props[[name]])
      } else if(!is.null(names(props)) && name %in% names(props)) {
        return(props[[name]])
      } else {
        return(default)
      }
    }
    
    rationale <- c()
    rationale <- c(rationale, "═══════════════════════════════════════")
    rationale <- c(rationale, "  PA LINEUP CALCULATION RATIONALE")
    rationale <- c(rationale, "═══════════════════════════════════════\n")
    rationale <- c(rationale, sprintf("Input Power: %.2f dBm (%.4f W)", 
      input_power_dbm, 10^(input_power_dbm/10)/1000))
    rationale <- c(rationale, sprintf("Backoff Analysis: %.1f dB below full power\n", backoff_db))
    
    # Sort components by x position (left to right flow)
    tryCatch({
      components <- components[order(sapply(components, function(c) {
        if(is.list(c) && !is.null(c$x)) c$x else if("x" %in% names(c)) c[["x"]] else 0
      }))]
    }, error = function(e) {
      # If sorting fails, just use as-is
    })
    
    # Initialize cascade variables
    current_pin <- input_power_dbm
    current_pin_bo <- input_power_dbm - backoff_db  # Backoff input power
    total_gain <- 0
    total_pdc <- 0
    total_pdc_bo <- 0  # Backoff DC power
    stage_results <- list()
    phase_results <- list()
    cumulative_phase <- 0
    warnings <- c()
    
    rationale <- c(rationale, "─── Stage-by-Stage Analysis ───")
    rationale <- c(rationale, "(Full Power | Backoff)\n")
    
    for(i in seq_along(components)) {
      comp <- components[[i]]
      
      # Safe property extraction
      props <- if(is.list(comp) && !is.null(comp$properties)) {
        comp$properties
      } else if("properties" %in% names(comp)) {
        comp[["properties"]]
      } else {
        list()
      }
      
      comp_type <- if(is.list(comp) && !is.null(comp$type)) {
        comp$type
      } else if("type" %in% names(comp)) {
        comp[["type"]]
      } else {
        "unknown"
      }
      
      stage_name <- safeProp(props, "label", paste0("Stage_", i))
      
      rationale <- c(rationale, sprintf("[%d] %s (%s)", i, stage_name, comp_type))
      rationale <- c(rationale, sprintf("    Input Power: %.2f dBm", current_pin))
      
      if(comp_type == "transistor") {
        # Transistor stage calculations
        gain <- as.numeric(safeProp(props, "gain", 15))
        p1db <- as.numeric(safeProp(props, "p1db", 43))
        vdd <- as.numeric(safeProp(props, "vdd", 28))
        rth <- as.numeric(safeProp(props, "rth", 2.5))
        
        # ═══ CHECK IF JAVASCRIPT ALREADY CALCULATED DUAL OPERATING POINTS ═══
        # JavaScript sends: pout_p3db, pin_p3db, pae_p3db, pout_pavg, pin_pavg, pae_pavg
        js_pout_p3db <- safeProp(props, "pout_p3db", NULL)
        js_pout_pavg <- safeProp(props, "pout_pavg", NULL)
        js_pin_p3db <- safeProp(props, "pin_p3db", NULL)
        js_pin_pavg <- safeProp(props, "pin_pavg", NULL)
        js_pae_p3db <- safeProp(props, "pae_p3db", NULL)
        js_pae_pavg <- safeProp(props, "pae_pavg", NULL)
        
        has_dual_op <- !is.null(js_pout_p3db) && !is.null(js_pout_pavg) && 
                       !is.null(js_pin_p3db) && !is.null(js_pin_pavg)
        
        # Debug logging
        cat(sprintf("[%s] Checking dual_op: pout_p3db=%s, pout_pavg=%s, has_dual_op=%s\n", 
          stage_name, 
          if(!is.null(js_pout_p3db)) as.character(js_pout_p3db) else "NULL",
          if(!is.null(js_pout_pavg)) as.character(js_pout_pavg) else "NULL",
          has_dual_op))
        
        if(has_dual_op) {
          # ✓ Use JavaScript-calculated values (from applySpecsToComponents)
          pout_dbm <- as.numeric(js_pout_p3db)
          pout_bo_dbm <- as.numeric(js_pout_pavg)
          
          # Use JavaScript-calculated PAE if available, else default
          pae_full <- if(!is.null(js_pae_p3db)) as.numeric(js_pae_p3db) / 100 else as.numeric(safeProp(props, "pae", 50)) / 100
          pae_bo <- if(!is.null(js_pae_pavg)) as.numeric(js_pae_pavg) / 100 else pae_full * 0.7
          
          rationale <- c(rationale, sprintf("    ✓ Using JavaScript dual operating points"))
          rationale <- c(rationale, sprintf("    Full (P3dB): Pin=%.2f, Pout=%.2f dBm, PAE=%.1f%%", 
            as.numeric(js_pin_p3db), pout_dbm, pae_full * 100))
          rationale <- c(rationale, sprintf("    Backoff (Pavg): Pin=%.2f, Pout=%.2f dBm, PAE=%.1f%%", 
            as.numeric(js_pin_pavg), pout_bo_dbm, pae_bo * 100))
        } else {
          # ═══ FALLBACK: Calculate using power cascade (NOT component p3db!) ═══
          # Both Full and Backoff use CASCADE positions, not component capabilities
          pout_dbm <- current_pin + gain
          pout_bo_dbm <- current_pin_bo + gain  # ← FIX: Use cascade, not component p3db!
          
          # Get default PAE
          pae_full <- as.numeric(safeProp(props, "pae", 50)) / 100
          
          # Estimate PAE at backoff (power-law degradation model)
          # PAE degrades as power reduces: PAE_bo = PAE_full * (Pout_bo/Pout_full)^0.8
          pout_ratio <- 10^((pout_bo_dbm - pout_dbm)/10)  # Power ratio (linear)
          pae_bo <- pae_full * (pout_ratio ^ 0.8)
          pae_bo <- max(pae_bo, 0.05)  # Minimum 5% efficiency
          
          rationale <- c(rationale, sprintf("    [Calculating from power cascade]"))
          rationale <- c(rationale, sprintf("    Full: Pin=%.2f + Gain=%.1f → Pout=%.2f dBm", 
            current_pin, gain, pout_dbm))
          rationale <- c(rationale, sprintf("    Backoff: Pin=%.2f + Gain=%.1f → Pout=%.2f dBm", 
            current_pin_bo, gain, pout_bo_dbm))
        }
        
        # Power calculations
        pout_w <- 10^(pout_dbm/10) / 1000
        pout_bo_w <- 10^(pout_bo_dbm/10) / 1000
        
        # Check compression at full power
        compressed <- pout_dbm > p1db
        if(compressed) {
          compression_amount <- pout_dbm - p1db
          warnings <- c(warnings, sprintf("%s: Compressed by %.1f dB", stage_name, compression_amount))
          rationale <- c(rationale, sprintf("    ⚠ WARNING: Output %.2f dBm exceeds P1dB %.2f dBm (compression: %.2f dB)", 
            pout_dbm, p1db, compression_amount))
          # Limit output to P1dB
          pout_dbm <- p1db
          pout_w <- 10^(pout_dbm/10) / 1000
        }
        
        # Check compression at backoff (should not compress!)
        compressed_bo <- pout_bo_dbm > p1db
        if(compressed_bo) {
          warnings <- c(warnings, sprintf("%s: Compressed at backoff (%.1f dB over P1dB)", 
            stage_name, pout_bo_dbm - p1db))
          rationale <- c(rationale, sprintf("    ⚠ WARNING: Backoff output %.2f dBm exceeds P1dB %.2f dBm!", 
            pout_bo_dbm, p1db))
          pout_bo_dbm <- p1db
          pout_bo_w <- 10^(pout_bo_dbm/10) / 1000
        }
        
        # Full power DC calculations
        pdc_w <- pout_w / pae_full
        pdiss_w <- pdc_w - pout_w
        idc_a <- pdc_w / vdd
        
        # Thermal calculation: Tj = Ta + Pdiss * Rth (assume Ta = 25°C)
        ta_c <- 25
        tj_c <- ta_c + pdiss_w * rth
        
        # === BACKOFF DC CALCULATIONS ===
        
        # Backoff DC power calculations
        pdc_bo_w <- pout_bo_w / pae_bo
        pdiss_bo_w <- pdc_bo_w - pout_bo_w
        tj_bo_c <- ta_c + pdiss_bo_w * rth
        
        rationale <- c(rationale, sprintf("    Full Power: Gain %.2f dB → Pout %.2f dBm (%.4f W)", 
          gain, pout_dbm, pout_w))
        rationale <- c(rationale, sprintf("    Full Power: PAE %.1f%% → PDC = %.3f W, PDiss = %.3f W",
          pae_full * 100, pdc_w, pdiss_w))
        rationale <- c(rationale, sprintf("    Backoff (%.1f dB): Pout %.2f dBm (%.4f W)", 
          backoff_db, pout_bo_dbm, pout_bo_w))
        rationale <- c(rationale, sprintf("    Backoff: PAE %.1f%% → PDC = %.3f W, PDiss = %.3f W",
          pae_bo * 100, pdc_bo_w, pdiss_bo_w))
        rationale <- c(rationale, sprintf("    Junction Temp: Full %.1f°C | Backoff %.1f°C",
          tj_c, tj_bo_c))
        
        if(tj_c > 150) {
          warnings <- c(warnings, sprintf("%s: High junction temp %.0f°C", stage_name, tj_c))
          rationale <- c(rationale, sprintf("    ⚠ WARNING: Junction temperature %.0f°C exceeds typical limit (150°C)", tj_c))
        }
        
        stage_results[[length(stage_results) + 1]] <- list(
          stage = stage_name,
          type = "transistor",
          pin_dbm = current_pin,
          pout_dbm = pout_dbm,
          gain_db = gain,
          pae_pct = pae_full * 100,  # ← FIX: Use calculated PAE, not component property!
          pdc_w = pdc_w,
          pdiss_w = pdiss_w,
          idc_a = idc_a,
          tj_c = tj_c,
          compressed = compressed,
          technology = safeProp(props, "technology", "GaN"),
          # Backoff metrics
          pin_bo_dbm = current_pin_bo,
          pout_bo_dbm = pout_bo_dbm,
          pae_bo_pct = pae_bo * 100,
          pdc_bo_w = pdc_bo_w,
          pdiss_bo_w = pdiss_bo_w,
          tj_bo_c = tj_bo_c,
          compressed_bo = compressed_bo
        )
        
        current_pin <- pout_dbm
        current_pin_bo <- pout_bo_dbm
        total_gain <- total_gain + gain
        total_pdc <- total_pdc + pdc_w
        total_pdc_bo <- total_pdc_bo + pdc_bo_w
        
      } else if(comp_type == "matching") {
        # Matching network: just loss, no DC power
        loss_db <- as.numeric(safeProp(props, "loss", 0.5))
        pout_dbm <- current_pin - loss_db
        pout_bo_dbm <- current_pin_bo - loss_db  # Backoff output
        
        rationale <- c(rationale, sprintf("    Loss: %.2f dB → Full: %.2f dBm | Backoff: %.2f dBm", 
          loss_db, pout_dbm, pout_bo_dbm))
        rationale <- c(rationale, sprintf("    Impedance transformation: %.1f Ω → %.1f Ω", 
          as.numeric(safeProp(props, "z_in", 50)), as.numeric(safeProp(props, "z_out", 50))))
        
        stage_results[[length(stage_results) + 1]] <- list(
          stage = stage_name,
          type = "matching",
          pin_dbm = current_pin,
          pout_dbm = pout_dbm,
          loss_db = loss_db,
          pin_bo_dbm = current_pin_bo,
          pout_bo_dbm = pout_bo_dbm
        )
        
        current_pin <- pout_dbm
        current_pin_bo <- pout_bo_dbm
        total_gain <- total_gain - loss_db
        
      } else if(comp_type == "splitter") {
        # Splitter: loss + split
        loss_db <- as.numeric(safeProp(props, "loss", 0.3))
        split_ratio_db <- as.numeric(safeProp(props, "split_ratio", 0))
        pout_dbm <- current_pin - loss_db
        pout_bo_dbm <- current_pin_bo - loss_db  # Backoff output
        
        rationale <- c(rationale, sprintf("    Insertion Loss: %.2f dB, Split Ratio: %.2f dB", 
          loss_db, split_ratio_db))
        rationale <- c(rationale, sprintf("    Output per path: Full %.2f dBm | Backoff %.2f dBm", 
          pout_dbm, pout_bo_dbm))
        
        stage_results[[length(stage_results) + 1]] <- list(
          stage = stage_name,
          type = "splitter",
          pin_dbm = current_pin,
          pout_dbm = pout_dbm,
          loss_db = loss_db,
          split_ratio = split_ratio_db,
          pin_bo_dbm = current_pin_bo,
          pout_bo_dbm = pout_bo_dbm
        )
        
        current_pin <- pout_dbm
        current_pin_bo <- pout_bo_dbm
        total_gain <- total_gain - loss_db
        
      } else if(comp_type == "combiner") {
        # Combiner: linear power addition of all N inputs minus combiner loss
        # For Doherty / Wilkinson: P_out(W) = sum(P_in_n(W)) × 10^(-loss_dB/10)
        loss_db      <- as.numeric(safeProp(props, "loss", 0.3))
        combiner_ways <- as.integer(safeProp(props, "ways", 2))
        
        # Convert current cascade power (per-path) to linear, scale by number of paths
        pin_per_path_w    <- 10^(current_pin / 10) / 1000
        pin_per_path_bo_w <- 10^(current_pin_bo / 10) / 1000
        
        # At P3dB all N paths contribute equally; at backoff Doherty main only (~0.5 paths)
        is_doherty <- grepl("doherty", tolower(safeProp(props, "type", "")), fixed = FALSE)
        if (is_doherty) {
          # At backoff, Aux PA is off: effective paths = 1; at peak: N paths
          paths_peak   <- combiner_ways
          paths_backoff <- 1L  # Only main PA active at backoff in Doherty
        } else {
          paths_peak    <- combiner_ways
          paths_backoff <- combiner_ways
        }
        
        pout_w    <- pin_per_path_w    * paths_peak    * 10^(-loss_db / 10)
        pout_bo_w <- pin_per_path_bo_w * paths_backoff * 10^(-loss_db / 10)
        
        pout_dbm    <- 10 * log10(pout_w    * 1000)
        pout_bo_dbm <- 10 * log10(pout_bo_w * 1000)
        
        combining_gain_db    <- 10 * log10(paths_peak)
        combining_gain_bo_db <- 10 * log10(paths_backoff)
        
        rationale <- c(rationale, sprintf("    %s Combiner (%d-way), Loss: %.2f dB",
          if(is_doherty) "Doherty" else "Wilkinson", combiner_ways, loss_db))
        rationale <- c(rationale, sprintf("    Full: +%.1f dB combine − %.2f dB loss → Pout %.2f dBm",
          combining_gain_db, loss_db, pout_dbm))
        rationale <- c(rationale, sprintf("    Backoff: +%.1f dB combine (main PA only) → Pout %.2f dBm",
          combining_gain_bo_db, pout_bo_dbm))
        
        stage_results[[length(stage_results) + 1]] <- list(
          stage      = stage_name,
          type       = "combiner",
          pin_dbm    = current_pin,
          pout_dbm   = pout_dbm,
          loss_db    = loss_db,
          combining_gain = combining_gain_db,
          pin_bo_dbm = current_pin_bo,
          pout_bo_dbm = pout_bo_dbm
        )
        
        current_pin    <- pout_dbm
        current_pin_bo <- pout_bo_dbm
        total_gain     <- total_gain + combining_gain_db - loss_db
      } else if(comp_type == "offset_line") {
        loss_db   <- as.numeric(safeProp(props, "loss", 0.2))
        phase_deg <- as.numeric(safeProp(props, "phase_shift_deg", 90))
        role      <- safeProp(props, "offset_role", "phase")
        imp_ohm   <- as.numeric(safeProp(props, "impedance", 50))
        pout_dbm    <- current_pin    - loss_db
        pout_bo_dbm <- current_pin_bo - loss_db
        rationale <- c(rationale, sprintf("    \u03bb/4 Line (%s): Z\u2080=%.1f\u03a9, loss=%.2f dB, \u03c6=%d\u00b0",
          role, imp_ohm, loss_db, as.integer(phase_deg)))
        rationale <- c(rationale, sprintf("    Full: %.2f dBm \u2192 %.2f dBm | Backoff: %.2f dBm \u2192 %.2f dBm",
          current_pin, pout_dbm, current_pin_bo, pout_bo_dbm))
        stage_results[[length(stage_results) + 1]] <- list(
          stage      = stage_name, type = "offset_line", id = comp$id,
          pin_dbm    = current_pin, pout_dbm = pout_dbm, loss_db = loss_db,
          phase_deg  = phase_deg, impedance = imp_ohm, role = role,
          pin_bo_dbm = current_pin_bo, pout_bo_dbm = pout_bo_dbm
        )
        current_pin    <- pout_dbm
        current_pin_bo <- pout_bo_dbm
        total_gain     <- total_gain - loss_db
      }
      
      # Universal phase tracking (every stage — contributes 0 unless it's an offset_line)
      phase_contrib    <- if(comp_type == "offset_line") as.numeric(safeProp(props, "phase_shift_deg", 90)) else 0
      cumulative_phase <- cumulative_phase + phase_contrib
      phase_results[[length(phase_results) + 1]] <- list(
        stage            = stage_name,
        type             = comp_type,
        phase_contrib    = phase_contrib,
        cumulative_phase = cumulative_phase,
        notes = if(comp_type == "offset_line")
          paste0(safeProp(props, "offset_role", "phase"), " \u03bb/4 (Z\u2080=",
                 safeProp(props, "impedance", 50), "\u03a9)")
        else ""
      )

      rationale <- c(rationale, "")
    }
    
    # System totals - Full Power
    final_pout_dbm  <- current_pin
    final_pout_w    <- 10^(final_pout_dbm / 10) / 1000
    
    # True system PAE = (Pout - Pin) / PDC_total   — Pin is back-calculated
    input_power_w    <- 10^(input_power_dbm / 10) / 1000
    system_pae <- if(total_pdc > 0 && final_pout_w > input_power_w)
      ((final_pout_w - input_power_w) / total_pdc) * 100 else 0
    
    # System totals - Backoff
    final_pout_bo_dbm <- current_pin_bo
    final_pout_bo_w   <- 10^(final_pout_bo_dbm / 10) / 1000
    input_power_bo_w  <- 10^((input_power_dbm - backoff_db) / 10) / 1000
    system_pae_bo <- if(total_pdc_bo > 0 && final_pout_bo_w > input_power_bo_w)
      ((final_pout_bo_w - input_power_bo_w) / total_pdc_bo) * 100 else 0
    
    rationale <- c(rationale, "─── System Summary ───")
    rationale <- c(rationale, sprintf("Total Gain: %.2f dB", total_gain))
    rationale <- c(rationale, sprintf("Input Power (back-calc.): %.2f dBm", input_power_dbm))
    rationale <- c(rationale, "\n[FULL POWER]")
    rationale <- c(rationale, sprintf("  Output Power: %.2f dBm (%.3f W)", final_pout_dbm, final_pout_w))
    rationale <- c(rationale, sprintf("  Total DC Power: %.3f W", total_pdc))
    rationale <- c(rationale, sprintf("  System PAE: %.1f%%", system_pae))
    rationale <- c(rationale, sprintf("  Heat Dissipation: %.3f W", total_pdc - final_pout_w))
    rationale <- c(rationale, sprintf("\n[BACKOFF (%.1f dB)]", backoff_db))
    rationale <- c(rationale, sprintf("  Output Power: %.2f dBm (%.3f W)", final_pout_bo_dbm, final_pout_bo_w))
    rationale <- c(rationale, sprintf("  Total DC Power: %.3f W", total_pdc_bo))
    rationale <- c(rationale, sprintf("  System PAE: %.1f%%", system_pae_bo))
    rationale <- c(rationale, sprintf("  Heat Dissipation: %.3f W", total_pdc_bo - final_pout_bo_w))
    
    if(length(warnings) > 0) {
      rationale <- c(rationale, "\n─── Warnings ───")
      for(w in warnings) {
        rationale <- c(rationale, paste0("⚠ ", w))
      }
    } else {
      rationale <- c(rationale, "\n✓ All stages operating within specifications")
    }
    
    rationale <- c(rationale, "\n═══════════════════════════════════════")
    
    list(
      success = TRUE,
      backoff_db = backoff_db,
      input_power_dbm = input_power_dbm,
      final_pout_dbm = final_pout_dbm,
      final_pout_w = final_pout_w,
      total_gain = total_gain,
      total_pdc = total_pdc,
      system_pae = system_pae,
      total_pdiss = total_pdc - final_pout_w,
      # Backoff system metrics
      final_pout_bo_dbm = final_pout_bo_dbm,
      final_pout_bo_w = final_pout_bo_w,
      total_pdc_bo = total_pdc_bo,
      system_pae_bo = system_pae_bo,
      total_pdiss_bo = total_pdc_bo - final_pout_bo_w,
      stage_results = stage_results,
      phase_results = phase_results,
      warnings = warnings,
      rationale = paste(rationale, collapse = "\n")
    )
  }
  
  # Calculate button observer
  observeEvent(input$lineup_calculate, {
    components <- lineup_components()
    
    if(is.null(components) || length(components) == 0) {
      showNotification("No components to calculate", type = "warning")
      return()
    }
    
    # Validate connections via JavaScript (client-side validation)
    session$sendCustomMessage("validateAndCalculate", list(
      components = components,
      connections = lineup_connections()
    ))
    
    # ═══ CRITICAL FIX: Calculate required input power from specifications ═══
    # If specs available: Pin_required = P3dB - Total_Gain
    # This ensures the cascade reaches the target P3dB output power
    if(!is.null(input$spec_p3db) && !is.null(input$spec_gain)) {
      input_power <- input$spec_p3db - input$spec_gain
      cat(sprintf("[Calculate] Using specs: P3dB=%.1f dBm, Gain=%.1f dB → Pin=%.2f dBm\n", 
        input$spec_p3db, input$spec_gain, input_power))
    } else {
      # Fallback: use default input power
      input_power <- 0  # dBm
      cat("[Calculate] Warning: No specs available, using default Pin=0 dBm\n")
    }
    
    # ═══ CRITICAL FIX: Use PAR from specs if available, else backoff_db ═══
    # Priority: 1) spec_par (correct), 2) backoff_db (legacy)
    if(!is.null(input$spec_par) && !is.null(input$spec_p3db)) {
      # Use PAR from specifications (P3dB-based approach)
      backoff_value <- input$spec_par
      showNotification(sprintf("Calculating with PAR = %.1f dB from specifications", backoff_value), 
        type = "message", duration = 3)
    } else {
      # Fall back to generic backoff_db input
      backoff_value <- if(!is.null(input$backoff_db)) input$backoff_db else 6
      showNotification(sprintf("Calculating with generic backoff = %.1f dB", backoff_value), 
        type = "warning", duration = 3)
    }
    
    result <- lineup_calculate_engine(components, lineup_connections(), input_power, backoff_value)
    
    # Store results globally (backwards compatibility)
    lineup_calc_results(result)
    
    # Store results per-canvas
    canvas_idx <- active_canvas_index()
    canvas_key <- paste0("canvas_", canvas_idx)
    canvas_data[[canvas_key]]$results <- result
    cat(sprintf("[Calculate] Stored results for canvas %d\n", canvas_idx))
    
    showNotification(
      if(result$success) "Calculation complete" else "Calculation failed",
      type = if(result$success) "message" else "error"
    )
  })
  
  # Calculate ALL canvases button observer
  observeEvent(input$lineup_calculate_all, {
    layout <- input$canvas_layout
    if(is.null(layout)) layout <- "1x1"
    
    canvas_count <- getCanvasCount(layout)
    
    cat(sprintf("[Calculate All] Layout: %s, Canvas Count: %d\n", layout, canvas_count))
    
    if(canvas_count == 1) {
      showNotification("Multi-canvas mode required for comparison", type = "warning")
      return()
    }
    
    # First, request fresh data from all canvases in JavaScript
    session$sendCustomMessage("requestAllCanvasData", list())
    
    # Give JavaScript time to send the data
    Sys.sleep(0.5)
    
    # Get backoff value from input (with fallback)
    backoff_value <- if(!is.null(input$backoff_db)) input$backoff_db else 6
    input_power <- 0  # Default 0 dBm
    
    calculated_count <- 0
    failed_count <- 0
    empty_count <- 0
    
    for(i in 0:(canvas_count-1)) {
      canvas_key <- paste0("canvas_", i)
      components <- canvas_data[[canvas_key]]$components
      connections <- canvas_data[[canvas_key]]$connections
      
      cat(sprintf("[Calculate All] Canvas %d: %d components, %d connections\n", 
                  i, length(components), length(connections)))
      
      if(!is.null(components) && length(components) > 0) {
        result <- lineup_calculate_engine(components, connections, input_power, backoff_value)
        canvas_data[[canvas_key]]$results <- result
        
        if(result$success) {
          calculated_count <- calculated_count + 1
          cat(sprintf("[Calculate All] Canvas %d: Success - Pout=%.2f dBm, PAE=%.1f%%\n", 
                      i, result$final_pout_dbm, result$system_pae))
        } else {
          failed_count <- failed_count + 1
          cat(sprintf("[Calculate All] Canvas %d: Failed - %s\n", i, result$message))
        }
      } else {
        empty_count <- empty_count + 1
        cat(sprintf("[Calculate All] Canvas %d: Empty (skipped)\n", i))
      }
    }
    
    msg <- sprintf("Calculated %d canvas(es).", calculated_count)
    if(empty_count > 0) msg <- paste0(msg, sprintf(" %d empty.", empty_count))
    if(failed_count > 0) msg <- paste0(msg, sprintf(" %d failed.", failed_count))
    
    showNotification(
      msg,
      type = if(failed_count == 0 && calculated_count > 0) "message" else "warning",
      duration = 5
    )
    
    cat(sprintf("[Calculate All] Complete: %d success, %d empty, %d failed\n", 
                calculated_count, empty_count, failed_count))
  })
  
  # ============================================================
  # SPECIFICATION-DRIVEN DESIGN
  # ============================================================
  
  # Apply Specs to Global Parameters Only
  observeEvent(input$apply_specs_to_global, {
    req(input$spec_frequency, input$spec_p3db, input$spec_gain)
    
    # Convert MHz to GHz for global frequency
    freq_ghz <- input$spec_frequency / 1000
    
    # Update global parameters
    updateNumericInput(session, "global_frequency", value = freq_ghz)
    
    cat(sprintf("[Spec→Global] Updated frequency: %.3f GHz\n", freq_ghz))
    
    showNotification(
      sprintf("Global parameters updated: %.2f GHz", freq_ghz),
      type = "message",
      duration = 3
    )
  })
  
  # Apply Specs to Lineup (Full adaptation)
  observeEvent(input$apply_specs_to_lineup, {
    req(input$spec_frequency, input$spec_p3db, input$spec_gain)
    
    # Collect all specification data
    specs <- list(
      # Primary specifications
      frequency_mhz = input$spec_frequency,
      frequency_ghz = input$spec_frequency / 1000,
      p3db = input$spec_p3db,
      p5db = if(!is.null(input$spec_p5db)) input$spec_p5db else (input$spec_p3db + 2),
      par = if(!is.null(input$spec_par)) input$spec_par else 8.0,  # Peak-to-Average Ratio
      pavg = input$spec_p3db - (if(!is.null(input$spec_par)) input$spec_par else 8.0),  # Average/backoff power
      gain = input$spec_gain,
      
      # Secondary specifications
      supply_voltage = input$spec_supply_voltage,
      efficiency_target = if(!is.null(input$spec_pae)) input$spec_pae else 47,
      am_pm_p3db = input$spec_am_pm_p3db,
      am_pm_dispersion = input$spec_am_pm_dispersion,
      group_delay = input$spec_group_delay,
      acp = input$spec_acp,
      gain_ripple_inband = input$spec_gain_ripple_inband,
      gain_ripple_3xband = input$spec_gain_ripple_3xband,
      input_return_loss = input$spec_input_return_loss,
      vbw = input$spec_vbw,
      test_conditions = input$spec_test_conditions,
      
      # Calculate derived values
      p1db = input$spec_p3db - 2,  # Typical for solid state
      pin_required = input$spec_p3db - input$spec_gain
    )
    
    cat("[Spec→Lineup] Applying specifications:\n")
    cat(sprintf("  Frequency: %.3f GHz (%.0f MHz)\n", specs$frequency_ghz, specs$frequency_mhz))
    cat(sprintf("  P3dB (Peak): %.1f dBm\n", specs$p3db))
    cat(sprintf("  PAR/BO: %.1f dB\n", specs$par))
    cat(sprintf("  Pavg (Backoff): %.1f dBm\n", specs$pavg))
    cat(sprintf("  Gain: %.1f dB\n", specs$gain))
    cat(sprintf("  Pin required: %.1f dBm\n", specs$pin_required))
    cat(sprintf("  Efficiency target: %.0f%%\n", specs$efficiency_target))
    cat(sprintf("  Supply voltage: %.0f V\n", specs$supply_voltage))
    
    # Update global parameters
    updateNumericInput(session, "global_frequency", value = specs$frequency_ghz)
    updateNumericInput(session, "global_pout_p3db", value = specs$p3db)
    
    # Send specifications to JavaScript for component adaptation
    session$sendCustomMessage("applySpecsToLineup", specs)
    
    showNotification(
      sprintf("Applying specs: %.2f GHz, %.1f dBm, %.1f dB gain",
              specs$frequency_ghz, specs$p3db, specs$gain),
      type = "message",
      duration = 5
    )
  })
  
  # ============================================================
  # FILE OPERATIONS: Save, Load, Export, Report
  # ============================================================
  
  # Save Configuration
  observeEvent(input$lineup_save_config, {
    components <- lineup_components()
    connections <- lineup_connections()
    
    if(is.null(components) || length(components) == 0) {
      showNotification("No lineup to save", type = "warning")
      return()
    }
    
    config <- list(
      components = components,
      connections = connections,
      metadata = list(
        timestamp = Sys.time(),
        version = "1.0",
        app = "PA Lineup Designer"
      )
    )
    
    # Create filename with timestamp
    filename <- sprintf("pa_lineup_%s.json", format(Sys.time(), "%Y%m%d_%H%M%S"))
    filepath <- file.path(tempdir(), filename)
    
    tryCatch({
      jsonlite::write_json(config, filepath, auto_unbox = TRUE, pretty = TRUE)
      showNotification(
        sprintf("Configuration saved to: %s", filename),
        type = "message",
        duration = 5
      )
      cat(sprintf("[Save] Configuration saved to: %s\n", filepath))
    }, error = function(e) {
      showNotification(
        sprintf("Save failed: %s", e$message),
        type = "error"
      )
    })
  })
  
  # Load Configuration
  observeEvent(input$lineup_load_config, {
    showModal(modalDialog(
      title = "Load Configuration",
      footer = tagList(
        modalButton("Cancel"),
        actionButton("lineup_load_confirm", "Load", class = "btn-success")
      ),
      fileInput("lineup_config_file", "Select Configuration File (.json)",
                accept = c(".json", "application/json")),
      helpText(icon("info-circle"), " Saved configurations are in your Downloads folder or the directory where you saved them.",
               style = "color: #888; font-size: 12px; margin-top: -10px;")
    ))
  })
  
  observeEvent(input$lineup_load_confirm, {
    req(input$lineup_config_file)
    
    file_info <- input$lineup_config_file
    
    tryCatch({
      config <- jsonlite::read_json(file_info$datapath, simplifyVector = TRUE)
      
      # Validate config structure
      if(!is.list(config) || is.null(config$components)) {
        stop("Invalid configuration file format")
      }
      
      # Send to JavaScript
      session$sendCustomMessage("loadConfiguration", config)
      
      showNotification("Configuration loaded successfully", type = "message")
      removeModal()
      
      cat(sprintf("[Load] Configuration loaded from: %s\n", file_info$name))
      cat(sprintf("[Load] Components: %d, Connections: %d\n", 
                  length(config$components), 
                  length(config$connections)))
      
    }, error = function(e) {
      showNotification(
        sprintf("Load failed: %s", e$message),
        type = "error"
      )
    })
  })
  
  # Export Diagram (SVG)
  observeEvent(input$lineup_export_diagram, {
    components <- lineup_components()
  
  # Save as User Template
  observeEvent(input$save_template_data, {
    req(input$save_template_data)
    
    template_data <- input$save_template_data
    template_name <- template_data$name
    
    if(is.null(template_name) || template_name == "") {
      showNotification("Template name is required", type = "error")
      return()
    }
    
    # Create user_templates directory if it doesn't exist
    templates_dir <- file.path("R", "user_templates")
    if(!dir.exists(templates_dir)) {
      dir.create(templates_dir, recursive = TRUE)
      cat(sprintf("[Template] Created directory: %s\n", templates_dir))
    }
    
    # Sanitize filename (remove special characters)
    safe_name <- gsub("[^a-zA-Z0-9_-]", "_", template_name)
    filename <- sprintf("%s.json", safe_name)
    filepath <- file.path(templates_dir, filename)
    
    # Add metadata
    template_data$metadata <- list(
      created = as.character(Sys.time()),
      version = "1.0",
      type = "user_template"
    )
    
    tryCatch({
      jsonlite::write_json(template_data, filepath, auto_unbox = TRUE, pretty = TRUE)
      showNotification(
        sprintf("Template '%s' saved successfully!", template_name),
        type = "message",
        duration = 3
      )
      cat(sprintf("[Template] Saved: %s (%d components, %d wires)\n", 
                  template_name, 
                  length(template_data$components), 
                  length(template_data$wires)))
      
      # Reload and send updated user templates list
      updated_templates <- getUserTemplates()
      if(length(updated_templates) > 0) {
        template_info <- lapply(updated_templates, function(t) {
          list(id = t$id, name = t$name, components_count = t$components_count)
        })
        session$sendCustomMessage("updateUserTemplates", template_info)
      }
      
    }, error = function(e) {
      showNotification(
        sprintf("Failed to save template: %s", e$message),
        type = "error"
      )
      cat(sprintf("[Template Error] %s\n", e$message))
    })
  })
  
  # Load User Template
  observeEvent(input$load_user_template, {
    req(input$load_user_template)
    
    template_id <- input$load_user_template
    
    # Remove "user_" prefix to get filename
    filename <- sub("^user_", "", template_id)
    filepath <- file.path("R", "user_templates", paste0(filename, ".json"))
    
    if(!file.exists(filepath)) {
      showNotification(
        "Template file not found",
        type = "error"
      )
      cat(sprintf("[Template Error] File not found: %s\n", filepath))
      return()
    }
    
    tryCatch({
      template_data <- jsonlite::read_json(filepath, simplifyVector = TRUE)
      
      # Send to JavaScript to load
      session$sendCustomMessage("loadUserTemplateData", template_data)
      
      cat(sprintf("[Template] Loaded: %s (%d components, %d wires)\n",
                  template_data$name,
                  length(template_data$components),
                  length(template_data$wires)))
      
    }, error = function(e) {
      showNotification(
        sprintf("Failed to load template: %s", e$message),
        type = "error"
      )
      cat(sprintf("[Template Error] %s\n", e$message))
    })
  })
  
  # Render user templates manager UI
  output$user_templates_manager <- renderUI({
    templates <- getUserTemplates()
    
    if(length(templates) == 0) {
      return(tags$p(
        style = "text-align: center; color: #999; font-size: 11px; padding: 10px;",
        "No saved templates"
      ))
    }
    
    lapply(templates, function(tmpl) {
      template_id <- tmpl$id
      template_name <- tmpl$name
      filename <- sub("^user_", "", template_id)
      
      tags$div(
        style = "margin-bottom: 8px; padding: 8px; background: rgba(255,255,255,0.05); border-radius: 4px;",
        tags$div(
          style = "display: flex; justify-content: space-between; align-items: center;",
          tags$div(
            style = "flex: 1;",
            tags$strong(style = "color: #fff; font-size: 11px;", template_name),
            tags$br(),
            tags$small(style = "color: #999;", sprintf("%d components", tmpl$components_count))
          ),
          tags$div(
            style = "display: flex; gap: 4px;",
            actionButton(
              paste0("edit_template_", filename),
              icon("edit"),
              class = "btn btn-warning btn-xs",
              style = "padding: 2px 6px;",
              title = "Edit template name",
              onclick = sprintf("console.log('Edit clicked: %s'); if(typeof editTemplate === 'function') { editTemplate('%s', '%s'); } else { alert('editTemplate function not found!'); }", filename, filename, template_name)
            ),
            actionButton(
              paste0("delete_template_", filename),
              icon("trash"),
              class = "btn btn-danger btn-xs",
              style = "padding: 2px 6px;",
              title = "Delete template"
            )
          )
        )
      )
    })
  })
  
  # Render user templates in top sidebar (Architecture Templates section)
  output$user_templates_top_display <- renderUI({
    templates <- getUserTemplates()
    
    if(length(templates) == 0) {
      return(tags$div(
        style = "text-align: center; color: #777; font-size: 11px; padding: 10px; font-style: italic;",
        "No saved templates yet"
      ))
    }
    
    lapply(templates, function(tmpl) {
      template_filename <- sub("^user_", "", tmpl$id)
      
      tags$div(
        class = "preset-template user-template",
        `data-preset` = paste0("user_", template_filename),
        `data-user-template` = "true",
        onclick = sprintf("loadUserTemplate('%s');", template_filename),
        tags$h5(style = "margin: 0; color: #FF7F11;", icon("star"), " ", tmpl$name),
        tags$p(style = "margin: 2px 0 0 0; font-size: 10px;", sprintf("%d components", tmpl$components_count))
      )
    })
  })
  
  # Observe changes that require updating both template displays
  observe({
    # Trigger re-render of both template UIs when files change
    list.files(file.path("R", "user_templates"), pattern = "\\.json$")
  }) %>% debounce(500)  # Debounce to avoid too frequent updates
  
  # Template delete/edit observers remain the same
  observe({
    templates <- getUserTemplates()
    
    lapply(templates, function(tmpl) {
      filename <- sub("^user_", "", tmpl$id)
      btn_id <- paste0("delete_template_", filename)
      
      observeEvent(input[[btn_id]], {
        filepath <- file.path("R", "user_templates", paste0(filename, ".json"))
        
        if(file.exists(filepath)) {
          tryCatch({
            file.remove(filepath)
            showNotification(
              sprintf("Template '%s' deleted", tmpl$name),
              type = "message",
              duration = 3
            )
            cat(sprintf("[Template] Deleted: %s\n", tmpl$name))
            
            # Reload templates
            updated_templates <- getUserTemplates()
            if(length(updated_templates) > 0) {
              template_info <- lapply(updated_templates, function(t) {
                list(id = t$id, name = t$name, components_count = t$components_count)
              })
              session$sendCustomMessage("updateUserTemplates", template_info)
            } else {
              session$sendCustomMessage("updateUserTemplates", list())
            }
            
          }, error = function(e) {
            showNotification(
              sprintf("Failed to delete template: %s", e$message),
              type = "error"
            )
          })
        }
      }, ignoreNULL = TRUE, ignoreInit = TRUE)
    })
  })
  
  # Edit template (rename) observer
  observeEvent(input$edit_template_submit, {
    req(input$edit_template_filename, input$edit_template_newname)
    
    filename <- input$edit_template_filename
    new_name <- trimws(input$edit_template_newname)
    
    if(new_name == "") {
      showNotification("Template name cannot be empty", type = "error")
      return()
    }
    
    filepath <- file.path("R", "user_templates", paste0(filename, ".json"))
    
    if(!file.exists(filepath)) {
      showNotification("Template file not found", type = "error")
      return()
    }
    
    tryCatch({
      # Read existing template
      template_data <- jsonlite::read_json(filepath, simplifyVector = FALSE)
      
      # Update name
      old_name <- template_data$name
      template_data$name <- new_name
      
      # If user wants to rename file too, create new file and delete old
      safe_new_name <- gsub("[^a-zA-Z0-9_-]", "_", new_name)
      new_filepath <- file.path("R", "user_templates", paste0(safe_new_name, ".json"))
      
      # Write to new file
      jsonlite::write_json(template_data, new_filepath, auto_unbox = TRUE, pretty = TRUE)
      
      # Delete old file if different
      if(filepath != new_filepath && file.exists(filepath)) {
        file.remove(filepath)
      }
      
      showNotification(
        sprintf("Template renamed from '%s' to '%s'", old_name, new_name),
        type = "message",
        duration = 3
      )
      cat(sprintf("[Template] Renamed: %s -> %s\n", old_name, new_name))
      
      # Reload templates
      updated_templates <- getUserTemplates()
      if(length(updated_templates) > 0) {
        template_info <- lapply(updated_templates, function(t) {
          list(id = t$id, name = t$name, components_count = t$components_count)
        })
        session$sendCustomMessage("updateUserTemplates", template_info)
      }
      
    }, error = function(e) {
      showNotification(
        sprintf("Failed to edit template: %s", e$message),
        type = "error"
      )
      cat(sprintf("[Template Error] %s\n", e$message))
    })
  })
  
  # Load user template observer (from top sidebar Architecture Templates)
  observeEvent(input$load_user_template_filename, {
    req(input$load_user_template_filename)
    
    filename <- input$load_user_template_filename
    filepath <- file.path("R", "user_templates", paste0(filename, ".json"))
    
    if(!file.exists(filepath)) {
      showNotification("Template file not found", type = "error")
      return()
    }
    
    tryCatch({
      template_data <- jsonlite::read_json(filepath, simplifyVector = TRUE)
      
      # Send template data to JavaScript  
      session$sendCustomMessage("loadTemplateData", template_data)
      
      showNotification(
        sprintf("Loaded template: %s", template_data$name),
        type = "message",
        duration = 3
      )
      
      cat(sprintf("[Template] Loaded: %s\n", template_data$name))
      
    }, error = function(e) {
      showNotification(
        sprintf("Failed to load template: %s", e$message),
        type = "error"
      )
      cat(sprintf("[Template Error] Failed to load %s: %s\n", filename, e$message))
    })
  })
  
    
    if(is.null(components) || length(components) == 0) {
      showNotification("No lineup to export", type = "warning")
      return()
    }
    
    showNotification(
      "Export feature: Right-click on canvas → 'Save Image As...' to export SVG",
      type = "message",
      duration = 8
    )
    
    # Future enhancement: Trigger JavaScript to export SVG
    # session$sendCustomMessage("exportSVG", list())
  })
  
  # Generate Report (PDF)
  observeEvent(input$lineup_generate_report, {
    components <- lineup_components()
    results <- lineup_calc_results()
    
    if(is.null(components) || length(components) == 0) {
      showNotification("No lineup to report", type = "warning")
      return()
    }
    
    if(is.null(results) || !results$success) {
      showNotification("Please calculate lineup before generating report", type = "warning")
      return()
    }
    
    showModal(modalDialog(
      title = "Generate Report",
      footer = tagList(
        modalButton("Cancel"),
        actionButton("lineup_report_confirm", "Generate", class = "btn-success")
      ),
      textInput("lineup_report_title", "Report Title", value = "PA Lineup Design Report"),
      textInput("lineup_report_author", "Author", value = ""),
      textAreaInput("lineup_report_notes", "Additional Notes", rows = 3)
    ))
  })
  
  observeEvent(input$lineup_report_confirm, {
    tryCatch({
      # Generate simple text report (PDF generation would require rmarkdown/reportlab)
      report_lines <- c(
        "================================",
        input$lineup_report_title,
        "================================",
        "",
        sprintf("Generated: %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
        if(nchar(input$lineup_report_author) > 0) sprintf("Author: %s", input$lineup_report_author) else NULL,
        "",
        "LINEUP CONFIGURATION",
        "--------------------",
        sprintf("Components: %d", length(lineup_components())),
        sprintf("Total Gain: %.2f dB", lineup_calc_results()$total_gain),
        sprintf("Output Power: %.2f dBm (%.3f W)", 
                lineup_calc_results()$final_pout_dbm,
                lineup_calc_results()$final_pout_w),
        sprintf("System PAE: %.1f%%", lineup_calc_results()$system_pae),
        sprintf("DC Power: %.3f W", lineup_calc_results()$total_pdc),
        "",
        "CALCULATION RATIONALE",
        "--------------------",
        lineup_calc_results()$rationale,
        "",
        if(nchar(input$lineup_report_notes) > 0) c("ADDITIONAL NOTES", "----------------", input$lineup_report_notes) else NULL
      )
      
      # Save to temp file
      filename <- sprintf("pa_lineup_report_%s.txt", format(Sys.time(), "%Y%m%d_%H%M%S"))
      filepath <- file.path(tempdir(), filename)
      writeLines(report_lines, filepath)
      
      showNotification(
        sprintf("Report saved to: %s", filename),
        type = "message",
        duration = 5
      )
      removeModal()
      
      cat(sprintf("[Report] Generated: %s\n", filepath))
      
    }, error = function(e) {
      showNotification(
        sprintf("Report generation failed: %s", e$message),
        type = "error"
      )
    })
  })
  
  # ============================================================
  # END FILE OPERATIONS
  # ============================================================
  
  # Property apply button observer - uses reactive approach for dynamic buttons
  observeEvent(input$lineup_selected_component, {
    selected <- input$lineup_selected_component
    
    if(is.null(selected) || length(selected) == 0) return()
    
    btn_id <- paste0("apply_props_", selected)
    
    cat(sprintf("[Property Observer] Component %s selected, setting up observer for button: %s\n", 
                selected, btn_id))
    
    # Create a NEW observer for this specific button
    observeEvent(input[[btn_id]], {
      cat(sprintf("[Property Observer] Button %s clicked! Value: %s\n", 
                  btn_id, input[[btn_id]]))
      
      components <- lineup_components()
      
      # Find the component
      comp_idx <- which(sapply(components, function(c) {
        if(is.list(c) && !is.null(c$id)) c$id == selected else FALSE
      }))
      
      if(length(comp_idx) == 0) {
        showNotification("Component not found", type = "error")
        return()
      }
      
      comp <- components[[comp_idx]]
      comp_type <- if(is.list(comp) && !is.null(comp$type)) comp$type else "transistor"
      
      cat(sprintf("[Property Observer] Component type: %s\n", comp_type))
      
      # Collect properties based on component type (NOTE: IDs are prop_{id}_{field})
      properties <- list()
      
      if(comp_type == "transistor") {
        properties$label <- input[[paste0("prop_", selected, "_label")]]
        properties$technology <- input[[paste0("prop_", selected, "_technology")]]
        properties$biasClass <- input[[paste0("prop_", selected, "_biasClass")]]
        properties$gain <- input[[paste0("prop_", selected, "_gain")]]
        properties$pout <- input[[paste0("prop_", selected, "_pout")]]
        properties$p1db <- input[[paste0("prop_", selected, "_p1db")]]
        properties$pae <- input[[paste0("prop_", selected, "_pae")]]
        properties$vdd <- input[[paste0("prop_", selected, "_vdd")]]
        properties$rth <- input[[paste0("prop_", selected, "_rth")]]
        properties$freq <- input[[paste0("prop_", selected, "_freq")]]
        properties$display <- input[[paste0("prop_", selected, "_display")]]
      } else if(comp_type == "matching") {
        properties$label <- input[[paste0("prop_", selected, "_label")]]
        properties$type <- input[[paste0("prop_", selected, "_type")]]
        properties$loss <- input[[paste0("prop_", selected, "_loss")]]
        properties$z_in <- input[[paste0("prop_", selected, "_z_in")]]
        properties$z_out <- input[[paste0("prop_", selected, "_z_out")]]
        properties$bandwidth <- input[[paste0("prop_", selected, "_bandwidth")]]
        properties$display <- input[[paste0("prop_", selected, "_display")]]
      } else if(comp_type == "splitter") {
        properties$label <- input[[paste0("prop_", selected, "_label")]]
        properties$type <- input[[paste0("prop_", selected, "_type")]]
        properties$split_ratio <- input[[paste0("prop_", selected, "_split_ratio")]]
        properties$isolation <- input[[paste0("prop_", selected, "_isolation")]]
        properties$loss <- input[[paste0("prop_", selected, "_loss")]]
        properties$display <- input[[paste0("prop_", selected, "_display")]]
      } else if(comp_type == "combiner") {
        properties$label <- input[[paste0("prop_", selected, "_label")]]
        properties$type <- input[[paste0("prop_", selected, "_type")]]
        properties$isolation <- input[[paste0("prop_", selected, "_isolation")]]
        properties$loss <- input[[paste0("prop_", selected, "_loss")]]
        properties$load_modulation <- input[[paste0("prop_", selected, "_load_modulation")]]
        properties$modulation_factor <- input[[paste0("prop_", selected, "_modulation_factor")]]
        properties$display <- input[[paste0("prop_", selected, "_display")]]
      } else if(comp_type == "termination") {
        properties$label <- input[[paste0("prop_", selected, "_label")]]
        properties$impedance <- input[[paste0("prop_", selected, "_impedance")]]
        properties$type <- input[[paste0("prop_", selected, "_type")]]
        properties$display <- input[[paste0("prop_", selected, "_display")]]
      } else if(comp_type == "offset_line") {
        properties$label <- input[[paste0("prop_", selected, "_label")]]
        properties$offset_role <- input[[paste0("prop_", selected, "_offset_role")]]
        properties$phase_shift_deg <- input[[paste0("prop_", selected, "_phase_shift_deg")]]
        properties$impedance <- input[[paste0("prop_", selected, "_impedance")]]
        properties$loss <- input[[paste0("prop_", selected, "_loss")]]
        properties$display <- input[[paste0("prop_", selected, "_display")]]
      }
      
      cat(sprintf("[Property Observer] Collected %d properties\n", length(properties)))
      cat(sprintf("[Property Observer] Sending updateComponent message to JavaScript...\n"))
      
      # Send to JavaScript
      session$sendCustomMessage("updateComponent", list(
        id = selected,
        properties = properties
      ))
      
      showNotification("Component properties updated", type = "message")
    }, ignoreNULL = TRUE, ignoreInit = TRUE)
  }, ignoreNULL = TRUE, ignoreInit = FALSE)
  
  # Calculation results output
  # Current canvas calculation results (fix: this was lineup_results before)
  output$lineup_calc_results <- renderUI({
    results <- lineup_calc_results()
    
    if(is.null(results)) {
      return(tags$div(
        style = "padding: 20px; text-align: center; color: #888;",
        "Click Calculate to see results"
      ))
    }
    
    if(!results$success) {
      return(tags$div(
        class = "alert alert-warning",
        tags$h4("Calculation Error"),
        tags$p(results$message)
      ))
    }
    
    backoff_value <- if(!is.null(results$backoff_db)) results$backoff_db else 6
    
    tagList(
      tags$h4("Full Power Performance", style = "color: #2196F3; margin-bottom: 10px;"),
      tags$div(class = "calc-summary", style = "background-color: #f0f8ff; padding: 10px; border-radius: 5px; margin-bottom: 15px;",
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Output Power"),
          tags$span(class = "metric-value", sprintf("%.2f dBm", results$final_pout_dbm)),
          tags$span(class = "metric-unit", sprintf("(%.3f W)", results$final_pout_w))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "System PAE"),
          tags$span(class = "metric-value success", sprintf("%.1f%%", results$system_pae))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "DC Power"),
          tags$span(class = "metric-value", sprintf("%.3f W", results$total_pdc))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Heat Dissipation"),
          tags$span(class = "metric-value warning", sprintf("%.3f W", results$total_pdiss))
        )
      ),
      tags$h4(sprintf("Backoff Performance (%.1f dB)", backoff_value), style = "color: #FF9800; margin-bottom: 10px;"),
      tags$div(class = "calc-summary", style = "background-color: #fff8f0; padding: 10px; border-radius: 5px; margin-bottom: 15px;",
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Output Power"),
          tags$span(class = "metric-value", sprintf("%.2f dBm", results$final_pout_bo_dbm)),
          tags$span(class = "metric-unit", sprintf("(%.3f W)", results$final_pout_bo_w))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "System PAE"),
          tags$span(class = "metric-value success", sprintf("%.1f%%", results$system_pae_bo))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "DC Power"),
          tags$span(class = "metric-value", sprintf("%.3f W", results$total_pdc_bo))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Heat Dissipation"),
          tags$span(class = "metric-value warning", sprintf("%.3f W", results$total_pdiss_bo))
        )
      ),
      tags$div(class = "calc-summary", style = "background-color: #f5f5f5; padding: 10px; border-radius: 5px;",
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Total Gain"),
          tags$span(class = "metric-value", sprintf("%.2f dB", results$total_gain))
        )
      ),
      if(length(results$warnings) > 0) {
        tags$div(class = "alert alert-warning",
          tags$strong("⚠ Warnings:"),
          tags$ul(
            lapply(results$warnings, function(w) tags$li(w))
          )
        )
      }
    )
  })
  
  # Legacy output name (keep for backwards compatibility)
  output$lineup_results <- renderUI({
    results <- lineup_calc_results()
    
    if(is.null(results)) {
      return(tags$div(
        style = "padding: 20px; text-align: center; color: #888;",
        "Click Calculate to see results"
      ))
    }
    
    if(!results$success) {
      return(tags$div(
        class = "alert alert-warning",
        tags$h4("Calculation Error"),
        tags$p(results$message)
      ))
    }
    
    backoff_value <- if(!is.null(results$backoff_db)) results$backoff_db else 6
    
    tagList(
      tags$h4("Full Power Performance", style = "color: #2196F3; margin-bottom: 10px;"),
      tags$div(class = "calc-summary", style = "background-color: #f0f8ff; padding: 10px; border-radius: 5px; margin-bottom: 15px;",
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Output Power"),
          tags$span(class = "metric-value", sprintf("%.2f dBm", results$final_pout_dbm)),
          tags$span(class = "metric-unit", sprintf("(%.3f W)", results$final_pout_w))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "System PAE"),
          tags$span(class = "metric-value success", sprintf("%.1f%%", results$system_pae))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "DC Power"),
          tags$span(class = "metric-value", sprintf("%.3f W", results$total_pdc))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Heat Dissipation"),
          tags$span(class = "metric-value warning", sprintf("%.3f W", results$total_pdiss))
        )
      ),
      tags$h4(sprintf("Backoff Performance (%.1f dB)", backoff_value), style = "color: #FF9800; margin-bottom: 10px;"),
      tags$div(class = "calc-summary", style = "background-color: #fff8f0; padding: 10px; border-radius: 5px; margin-bottom: 15px;",
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Output Power"),
          tags$span(class = "metric-value", sprintf("%.2f dBm", results$final_pout_bo_dbm)),
          tags$span(class = "metric-unit", sprintf("(%.3f W)", results$final_pout_bo_w))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "System PAE"),
          tags$span(class = "metric-value success", sprintf("%.1f%%", results$system_pae_bo))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "DC Power"),
          tags$span(class = "metric-value", sprintf("%.3f W", results$total_pdc_bo))
        ),
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Heat Dissipation"),
          tags$span(class = "metric-value warning", sprintf("%.3f W", results$total_pdiss_bo))
        )
      ),
      tags$div(class = "calc-summary", style = "background-color: #f5f5f5; padding: 10px; border-radius: 5px;",
        tags$div(class = "calc-metric",
          tags$span(class = "metric-label", "Total Gain"),
          tags$span(class = "metric-value", sprintf("%.2f dB", results$total_gain))
        )
      ),
      if(length(results$warnings) > 0) {
        tags$div(class = "alert alert-warning",
          tags$strong("⚠ Warnings:"),
          tags$ul(
            lapply(results$warnings, function(w) tags$li(w))
          )
        )
      }
    )
  })
  
  # Rationale output
  output$lineup_rationale <- renderText({
    results <- lineup_calc_results()
    if(is.null(results) || !results$success) {
      return("No calculation results available. Click Calculate to generate rationale.")
    }
    results$rationale
  })
  
  # Multi-canvas comparison output
  output$lineup_comparison_results <- renderUI({
    layout <- input$canvas_layout
    if(is.null(layout)) layout <- "1x1"
    
    canvas_count <- getCanvasCount(layout)
    
    cat(sprintf("[Comparison View] Layout: %s, Canvas Count: %d\n", layout, canvas_count))
    
    if(canvas_count == 1) {
      return(tags$div(
        style = "padding: 20px; text-align: center; color: #888;",
        icon("info-circle", style = "font-size: 36px; margin-bottom: 10px;"),
        tags$h4("Multi-Canvas Comparison Unavailable"),
        tags$p("Switch to any multi-canvas layout (2x1, 1x2, 2x2, 2x3, etc.) to compare multiple canvases")
      ))
    }
    
    # Collect results from all canvases
    comparison_data <- list()
    has_results <- FALSE
    
    for(i in 0:(canvas_count-1)) {
      canvas_key <- paste0("canvas_", i)
      canvas_name <- if(!is.null(rv$canvas_names) && length(rv$canvas_names) > i) {
        rv$canvas_names[i+1]
      } else {
        paste("Canvas", i+1)
      }
      
      result <- canvas_data[[canvas_key]]$results
      if(!is.null(result) && result$success) {
        has_results <- TRUE
        comparison_data[[as.character(i)]] <- list(
          name = canvas_name,
          result = result
        )
      }
    }
    
    if(!has_results) {
      return(tags$div(
        style = "padding: 20px; text-align: center; color: #888;",
        icon("info-circle", style = "font-size: 36px; margin-bottom: 10px;"),
        tags$p("No calculation results available"),
        tags$p(style = "font-size: 14px;", "Click 'Calculate All Canvases' to generate comparison data")
      ))
    }
    
    # Create comparison table
    tagList(
      tags$h4("Canvas Comparison", style = "color: #2196F3; margin-bottom: 15px;"),
      tags$div(
        style = "overflow-x: auto;",
        tags$table(
          class = "table table-striped table-hover",
          style = "margin-bottom: 20px;",
          tags$thead(
            tags$tr(
              tags$th("Canvas", style = "background-color: #34495e; color: white; font-weight: bold;"),
              tags$th("Output Power", style = "background-color: #34495e; color: white;"),
              tags$th("PAE (%)", style = "background-color: #34495e; color: white;"),
              tags$th("DC Power (W)", style = "background-color: #34495e; color: white;"),
              tags$th("Total Gain (dB)", style = "background-color: #34495e; color: white;"),
              tags$th("Components", style = "background-color: #34495e; color: white;")
            )
          ),
          tags$tbody(
            lapply(names(comparison_data), function(idx) {
              data <- comparison_data[[idx]]
              result <- data$result
              
              # Determine best performers for highlighting
              pae_style <- ""
              pout_style <- ""
              
              tags$tr(
                tags$td(tags$strong(data$name)),
                tags$td(
                  sprintf("%.2f dBm (%.3f W)", result$final_pout_dbm, result$final_pout_w),
                  style = pout_style
                ),
                tags$td(
                  sprintf("%.1f%%", result$system_pae),
                  style = pae_style
                ),
                tags$td(sprintf("%.3f", result$total_pdc)),
                tags$td(sprintf("%.2f", result$total_gain)),
                tags$td(sprintf("%d", length(canvas_data[[paste0("canvas_", idx)]]$components)))
              )
            })
          )
        )
      ),
      
      # Backoff comparison
      if(all(sapply(comparison_data, function(d) !is.null(d$result$final_pout_bo_dbm)))) {
        backoff_value <- comparison_data[[1]]$result$backoff_db
        if(is.null(backoff_value)) backoff_value <- 6
        
        tagList(
          tags$h4(sprintf("Backoff Comparison (%.1f dB)", backoff_value), 
                  style = "color: #FF9800; margin-bottom: 15px; margin-top: 25px;"),
          tags$div(
            style = "overflow-x: auto;",
            tags$table(
              class = "table table-striped table-hover",
              tags$thead(
                tags$tr(
                  tags$th("Canvas", style = "background-color: #FF9800; color: white; font-weight: bold;"),
                  tags$th("Output Power", style = "background-color: #FF9800; color: white;"),
                  tags$th("PAE (%)", style = "background-color: #FF9800; color: white;"),
                  tags$th("DC Power (W)", style = "background-color: #FF9800; color: white;"),
                  tags$th("Heat Dissipation (W)", style = "background-color: #FF9800; color: white;")
                )
              ),
              tags$tbody(
                lapply(names(comparison_data), function(idx) {
                  data <- comparison_data[[idx]]
                  result <- data$result
                  
                  tags$tr(
                    tags$td(tags$strong(data$name)),
                    tags$td(sprintf("%.2f dBm (%.3f W)", result$final_pout_bo_dbm, result$final_pout_bo_w)),
                    tags$td(sprintf("%.1f%%", result$system_pae_bo)),
                    tags$td(sprintf("%.3f", result$total_pdc_bo)),
                    tags$td(sprintf("%.3f", result$total_pdiss_bo))
                  )
                })
              )
            )
          )
        )
      },
      
      # Summary statistics
      tags$div(
        class = "alert alert-info",
        style = "margin-top: 20px;",
        tags$strong(icon("chart-bar"), " Summary Statistics:"),
        tags$ul(
          style = "margin-top: 10px; margin-bottom: 0;",
          tags$li(sprintf("Canvases with results: %d / %d", length(comparison_data), canvas_count)),
          tags$li(sprintf("Avg Output Power: %.2f dBm", 
                         mean(sapply(comparison_data, function(d) d$result$final_pout_dbm)))),
          tags$li(sprintf("Avg PAE: %.1f%%", 
                         mean(sapply(comparison_data, function(d) d$result$system_pae)))),
          tags$li(sprintf("Total DC Power (all canvases): %.3f W", 
                         sum(sapply(comparison_data, function(d) d$result$total_pdc))))
        )
      )
    )
  })
  
  # PA Lineup Table
  output$pa_lineup_table <- renderDT({
    results <- lineup_calc_results()
    
    if(is.null(results) || !results$success || length(results$stage_results) == 0) {
      return(datatable(data.frame(Message = "No calculation data available")))
    }
    
    backoff_value <- if(!is.null(results$backoff_db)) results$backoff_db else 6
    
    # Build table from stage results with backoff columns
    rows <- lapply(results$stage_results, function(stage) {
      if(stage$type == "transistor") {
        data.frame(
          Stage = stage$stage,
          Type = "Transistor",
          # Full power columns
          Pin_Full = sprintf("%.2f", stage$pin_dbm),
          Pout_Full = sprintf("%.2f", stage$pout_dbm),
          PAE_Full = sprintf("%.1f", stage$pae_pct),
          PDC_Full = sprintf("%.3f", stage$pdc_w),
          # Backoff columns
          Pin_BO = sprintf("%.2f", stage$pin_bo_dbm),
          Pout_BO = sprintf("%.2f", stage$pout_bo_dbm),
          PAE_BO = sprintf("%.1f", stage$pae_bo_pct),
          PDC_BO = sprintf("%.3f", stage$pdc_bo_w),
          # Common columns
          Gain_dB = sprintf("%.2f", stage$gain_db),
          Status = if(stage$compressed) "⚠ Compressed" else "✓ Linear",
          stringsAsFactors = FALSE
        )
      } else if(stage$type == "matching") {
        data.frame(
          Stage = stage$stage,
          Type = "Matching",
          # Full power columns
          Pin_Full = sprintf("%.2f", stage$pin_dbm),
          Pout_Full = sprintf("%.2f", stage$pout_dbm),
          PAE_Full = "—",
          PDC_Full = "—",
          # Backoff columns
          Pin_BO = sprintf("%.2f", stage$pout_bo_dbm - stage$loss_db),
          Pout_BO = sprintf("%.2f", stage$pout_bo_dbm),
          PAE_BO = "—",
          PDC_BO = "—",
          # Common columns
          Gain_dB = sprintf("%.2f", -stage$loss_db),
          Status = "Passive",
          stringsAsFactors = FALSE
        )
      } else if(stage$type == "offset_line") {
        loss_val <- if(!is.null(stage$loss_db)) stage$loss_db else 0.2
        phase_label <- if(!is.null(stage$phase_deg))
          sprintf("\u03bb/4 (%d\u00b0)", as.integer(stage$phase_deg))
        else "\u03bb/4 (90\u00b0)"
        data.frame(
          Stage = stage$stage,
          Type = phase_label,
          Pin_Full = sprintf("%.2f", stage$pin_dbm),
          Pout_Full = sprintf("%.2f", stage$pout_dbm),
          PAE_Full = "—",
          PDC_Full = "—",
          Pin_BO = if(!is.null(stage$pin_bo_dbm)) sprintf("%.2f", stage$pin_bo_dbm) else "—",
          Pout_BO = if(!is.null(stage$pout_bo_dbm)) sprintf("%.2f", stage$pout_bo_dbm) else "—",
          PAE_BO = "—",
          PDC_BO = "—",
          Gain_dB = sprintf("%.2f", -loss_val),
          Status = "Passive",
          stringsAsFactors = FALSE
        )
      } else {
        # Splitters and combiners
        loss_val <- if(!is.null(stage$loss_db)) stage$loss_db else 0.3
        gain_val <- if(stage$type == "combiner") 3 - loss_val else -loss_val
        
        data.frame(
          Stage = stage$stage,
          Type = tools::toTitleCase(stage$type),
          # Full power columns
          Pin_Full = sprintf("%.2f", stage$pin_dbm),
          Pout_Full = sprintf("%.2f", stage$pout_dbm),
          PAE_Full = "—",
          PDC_Full = "—",
          # Backoff columns
          Pin_BO = if(!is.null(stage$pin_bo_dbm)) sprintf("%.2f", stage$pin_bo_dbm) else "—",
          Pout_BO = if(!is.null(stage$pout_bo_dbm)) sprintf("%.2f", stage$pout_bo_dbm) else "—",
          PAE_BO = "—",
          PDC_BO = "—",
          # Common columns
          Gain_dB = sprintf("%.2f", gain_val),
          Status = "Passive",
          stringsAsFactors = FALSE
        )
      }
    })
    
    data <- do.call(rbind, rows)
    
    # Calculate totals for summary row
    total_loss <- sum(sapply(results$stage_results, function(stage) {
      if(stage$type == "matching" && !is.null(stage$loss_db)) {
        stage$loss_db
      } else if(stage$type %in% c("splitter", "combiner") && !is.null(stage$loss_db)) {
        stage$loss_db
      } else if(stage$type %in% c("splitter", "combiner")) {
        0.3
      } else {
        0
      }
    }))
    
    # Summary row with backoff data
    summary_row <- data.frame(
      Stage = "SYSTEM TOTAL",
      Type = "—",
      # Full power totals
      Pin_Full = sprintf("%.2f", results$input_power_dbm),
      Pout_Full = sprintf("%.2f", results$final_pout_dbm),
      PAE_Full = sprintf("%.1f", results$system_pae),
      PDC_Full = sprintf("%.3f", results$total_pdc),
      # Backoff totals
      Pin_BO = sprintf("%.2f", results$input_power_dbm - backoff_value),
      Pout_BO = sprintf("%.2f", results$final_pout_bo_dbm),
      PAE_BO = sprintf("%.1f", results$system_pae_bo),
      PDC_BO = sprintf("%.3f", results$total_pdc_bo),
      # Common
      Gain_dB = sprintf("%.2f", results$total_gain),
      Status = if(length(results$warnings) > 0) "⚠ Check" else "✓ OK",
      stringsAsFactors = FALSE
    )
    
    data <- rbind(data, summary_row)
    
    # Create column names with grouped headers
    colnames(data) <- c(
      "Stage", "Type",
      "Pin (dBm)", "Pout (dBm)", "PAE (%)", "PDC (W)",
      "Pin (dBm) ", "Pout (dBm) ", "PAE (%) ", "PDC (W) ",
      "Gain (dB)", "Status"
    )
    
    datatable(data, 
      options = list(
        pageLength = 20, 
        dom = 't',
        columnDefs = list(
          list(className = 'dt-center', targets = 2:11)
        )
      ), 
      rownames = FALSE,
      container = htmltools::withTags(table(
        class = 'display',
        thead(
          tr(
            th(rowspan = 2, 'Stage'),
            th(rowspan = 2, 'Type'),
            th(colspan = 4, style = 'text-align:center; background-color:#e8f4f8; border-bottom: 2px solid #2196F3;', 'Full Power'),
            th(colspan = 4, style = 'text-align:center; background-color:#fff3e0; border-bottom: 2px solid #FF9800;', sprintf('Backoff (%.1f dB)', backoff_value)),
            th(rowspan = 2, 'Gain (dB)'),
            th(rowspan = 2, 'Status')
          ),
          tr(
            th('Pin (dBm)'), th('Pout (dBm)'), th('PAE (%)'), th('PDC (W)'),
            th('Pin (dBm)'), th('Pout (dBm)'), th('PAE (%)'), th('PDC (W)')
          )
        )
      ))
    ) %>%
      formatStyle('Status',
        backgroundColor = styleEqual(
          c('✓ Linear', '⚠ Compressed', '✓ OK', '⚠ Check', 'Passive'),
          c('rgba(0,255,0,0.2)', 'rgba(255,165,0,0.3)', 'rgba(0,255,0,0.2)', 
            'rgba(255,165,0,0.3)', 'rgba(200,200,200,0.2)')
        )
      ) %>%
      formatStyle(3:6, backgroundColor = '#f0f8ff') %>%  # Light blue for full power
      formatStyle(7:10, backgroundColor = '#fff8f0')     # Light orange for backoff
  })

  # Ensure the table renders even when the Table View tab is not visible
  outputOptions(output, "pa_lineup_table", suspendWhenHidden = FALSE)

  # Phase Analysis output
  output$pa_lineup_phase <- renderUI({
    results <- lineup_calc_results()

    if(is.null(results) || !results$success) {
      return(tags$div(style = "padding: 20px; text-align: center; color: #888;",
        "Click Calculate to see phase analysis."))
    }

    phase_data <- if(!is.null(results$phase_results)) results$phase_results else list()

    if(length(phase_data) == 0) {
      return(tags$div(style = "padding: 20px; text-align: center; color: #888;",
        "No phase data available."))
    }

    # Build HTML table rows
    has_phase <- any(sapply(phase_data, function(p) p$phase_contrib != 0))

    table_rows <- lapply(phase_data, function(p) {
      is_active <- p$phase_contrib != 0
      row_style <- if(is_active) "background-color: #e8f5e9; font-weight: bold;" else ""
      tags$tr(style = row_style,
        tags$td(p$stage),
        tags$td(tools::toTitleCase(gsub("_", " ", p$type))),
        tags$td(style = "text-align:center;",
          if(is_active)
            tags$span(style = "color: #2e7d32;", sprintf("+%.1f\u00b0", p$phase_contrib))
          else
            tags$span(style = "color: #aaa;", "0\u00b0")
        ),
        tags$td(style = "text-align:center; font-weight: bold;",
          sprintf("%.1f\u00b0", p$cumulative_phase)),
        tags$td(p$notes)
      )
    })

    tags$div(
      if(!has_phase) tags$div(class = "alert alert-info",
        tags$strong("\u2139 No \u03bb/4 offset lines in this lineup."),
        " Add an offset line component to see phase contributions."
      ),
      tags$p(style = "color: #555; font-size: 12px; margin-bottom: 8px;",
        "Phase contributions from \u03bb/4 offset lines (inverters and transformers). ",
        "Other components are treated as zero-phase-shift in this model."
      ),
      tags$table(class = "table table-bordered table-condensed",
        style = "font-size: 13px;",
        tags$thead(
          tags$tr(style = "background-color: #455a64; color: white;",
            tags$th("Stage"),
            tags$th("Type"),
            tags$th(style = "text-align:center;", "Phase Contribution"),
            tags$th(style = "text-align:center;", "Cumulative Phase"),
            tags$th("Notes")
          )
        ),
        tags$tbody(table_rows),
        tags$tfoot(
          tags$tr(style = "background-color: #eceff1; font-weight: bold;",
            tags$td("TOTAL"),
            tags$td("—"),
            tags$td(style = "text-align:center;",
              sprintf("%.1f\u00b0", sum(sapply(phase_data, function(p) p$phase_contrib)))),
            tags$td(style = "text-align:center;",
              if(length(phase_data) > 0) sprintf("%.1f\u00b0", phase_data[[length(phase_data)]]$cumulative_phase) else "0\u00b0"),
            tags$td("\u03a3 phase from offset lines")
          )
        )
      )
    )
  })

  outputOptions(output, "pa_lineup_phase", suspendWhenHidden = FALSE)
  
  # Dynamic Tables UI - renders tabs for multi-canvas layouts
  output$pa_lineup_tables_dynamic <- renderUI({
    layout <- input$canvas_layout
    
    if(is.null(layout) || layout == "1x1") {
      # Single canvas mode - show single table
      return(DTOutput("pa_lineup_table"))
    }
    
    # Multi-canvas mode - create tabs
    canvas_count <- getCanvasCount(layout)
    
    tab_panels <- lapply(1:canvas_count, function(i) {
      tabPanel(
        title = rv$canvas_names[i],
        DTOutput(paste0("pa_lineup_table_", i))
      )
    })
    
    do.call(tabsetPanel, c(list(id = "table_tabs"), tab_panels))
  })
  
  # Dynamic Equations UI - renders tabs for multi-canvas layouts  
  output$pa_lineup_equations_dynamic <- renderUI({
    layout <- input$canvas_layout
    
    if(is.null(layout) || layout == "1x1") {
      # Single canvas mode - show single equations view
      return(tagList(
        wellPanel(
          h4("PA Lineup Equations"),
          HTML("
            <h5>Power Cascade:</h5>
            <p><b>P<sub>out,i</sub> (dBm)</b> = P<sub>in,i</sub> + G<sub>i</sub></p>
            <p><b>P<sub>in,i+1</sub></b> = P<sub>out,i</sub></p>
            
            <h5>Total Gain:</h5>
            <p><b>G<sub>total</sub> (dB)</b> = Σ G<sub>i</sub></p>
            
            <h5>Power Dissipation (per stage):</h5>
            <p><b>P<sub>diss,i</sub> (W)</b> = P<sub>out,i</sub>(W) · (1/PAE<sub>i</sub> - 1)</p>
            
            <h5>DC Power (per stage):</h5>
            <p><b>P<sub>DC,i</sub> (W)</b> = P<sub>out,i</sub>(W) / PAE<sub>i</sub></p>
            
            <h5>Total System PAE:</h5>
            <p><b>PAE<sub>total</sub></b> = P<sub>out,final</sub> / Σ P<sub>DC,i</sub></p>
            
            <h5>Compression Check:</h5>
            <p>For each stage: <b>P<sub>out,i</sub> ≤ P1dB<sub>i</sub></b></p>
            <p>If P<sub>out,i</sub> > P1dB<sub>i</sub>: <span style='color:red;'>⚠ Compression Warning</span></p>
            
            <h5>For Doherty Architecture:</h5>
            <p><b>Load Modulation:</b> Main PA operates at higher impedance at backoff</p>
            <p><b>Auxiliary Turn-on:</b> Typically at 6dB backoff from P1dB</p>
            <p><b>Combining Efficiency:</b> Accounts for impedance transformation losses</p>
            
            <h5>Thermal Calculations:</h5>
            <p><b>Junction Temp:</b> T<sub>j</sub> = T<sub>a</sub> + P<sub>diss</sub> · R<sub>θja</sub></p>
          ")
        ),
        hr(),
        h4("Calculation Rationale:"),
        verbatimTextOutput("lineup_rationale"),
        hr(),
        textAreaInput("lineup_custom_notes", "Design Notes:", 
          placeholder = "Add your notes, justifications, or remarks here...",
          rows = 4)
      ))
    }
    
    # Multi-canvas mode - create tabs
    canvas_count <- getCanvasCount(layout)
    
    tab_panels <- lapply(1:canvas_count, function(i) {
      tabPanel(
        title = rv$canvas_names[i],
        wellPanel(
          h4(sprintf("%s - PA Lineup Equations", rv$canvas_names[i])),
          HTML("
            <h5>Power Cascade:</h5>
            <p><b>P<sub>out,i</sub> (dBm)</b> = P<sub>in,i</sub> + G<sub>i</sub></p>
            <p><b>P<sub>in,i+1</sub></b> = P<sub>out,i</sub></p>
            
            <h5>Total Gain:</h5>
            <p><b>G<sub>total</sub> (dB)</b> = Σ G<sub>i</sub></p>
            
            <h5>DC Power (per stage):</h5>
            <p><b>P<sub>DC,i</sub> (W)</b> = P<sub>out,i</sub>(W) / PAE<sub>i</sub></p>
            
            <h5>Total System PAE:</h5>
            <p><b>PAE<sub>total</sub></b> = P<sub>out,final</sub> / Σ P<sub>DC,i</sub></p>
          ")
        ),
        hr(),
        h4("Calculation Rationale:"),
        verbatimTextOutput(paste0("lineup_rationale_", i))
      )
    })
    
    do.call(tabsetPanel, c(list(id = "equations_tabs"), tab_panels))
  })
  
  # Dynamic render outputs for multi-canvas tables and rationale
  observe({
    layout <- input$canvas_layout
    
    if(!is.null(layout) && layout != "1x1") {
      canvas_count <- getCanvasCount(layout)
      
      # Create render functions for each canvas
      lapply(1:canvas_count, function(i) {
        local({
          canvas_index <- i
          
          # Table output
          output_name_table <- paste0("pa_lineup_table_", canvas_index)
          output[[output_name_table]] <- renderDT({
            # Get results from per-canvas storage
            canvas_key <- paste0("canvas_", canvas_index - 1)
            results <- canvas_data[[canvas_key]]$results
            
            if(is.null(results) || !results$success || length(results$stage_results) == 0) {
              return(datatable(data.frame(Message = sprintf("No calculation data for Canvas %d. Click 'Calculate All Canvases'.", canvas_index))))
            }
            
            backoff_value <- if(!is.null(results$backoff_db)) results$backoff_db else 6
            
            # Build table from stage results with backoff columns
            rows <- lapply(results$stage_results, function(stage) {
              if(stage$type == "transistor") {
                data.frame(
                  Stage = stage$stage,
                  Type = "Transistor",
                  Pin_Full = sprintf("%.2f", stage$pin_dbm),
                  Pout_Full = sprintf("%.2f", stage$pout_dbm),
                  PAE_Full = sprintf("%.1f", stage$pae_pct),
                  PDC_Full = sprintf("%.3f", stage$pdc_w),
                  Pin_BO = sprintf("%.2f", stage$pin_bo_dbm),
                  Pout_BO = sprintf("%.2f", stage$pout_bo_dbm),
                  PAE_BO = sprintf("%.1f", stage$pae_bo_pct),
                  PDC_BO = sprintf("%.3f", stage$pdc_bo_w),
                  Gain_dB = sprintf("%.2f", stage$gain_db),
                  Status = if(stage$compressed) "⚠ Compressed" else "✓ Linear",
                  stringsAsFactors = FALSE
                )
              } else if(stage$type == "matching") {
                data.frame(
                  Stage = stage$stage,
                  Type = "Matching",
                  Pin_Full = sprintf("%.2f", stage$pin_dbm),
                  Pout_Full = sprintf("%.2f", stage$pout_dbm),
                  PAE_Full = "—",
                  PDC_Full = "—",
                  Pin_BO = sprintf("%.2f", stage$pout_bo_dbm - stage$loss_db),
                  Pout_BO = sprintf("%.2f", stage$pout_bo_dbm),
                  PAE_BO = "—",
                  PDC_BO = "—",
                  Gain_dB = sprintf("%.2f", -stage$loss_db),
                  Status = "Passive",
                  stringsAsFactors = FALSE
                )
              } else {
                loss_val <- if(!is.null(stage$loss_db)) stage$loss_db else 0.3
                gain_val <- if(stage$type == "combiner") 3 - loss_val else -loss_val
                
                data.frame(
                  Stage = stage$stage,
                  Type = tools::toTitleCase(stage$type),
                  Pin_Full = sprintf("%.2f", stage$pin_dbm),
                  Pout_Full = sprintf("%.2f", stage$pout_dbm),
                  PAE_Full = "—",
                  PDC_Full = "—",
                  Pin_BO = if(!is.null(stage$pin_bo_dbm)) sprintf("%.2f", stage$pin_bo_dbm) else "—",
                  Pout_BO = if(!is.null(stage$pout_bo_dbm)) sprintf("%.2f", stage$pout_bo_dbm) else "—",
                  PAE_BO = "—",
                  PDC_BO = "—",
                  Gain_dB = sprintf("%.2f", gain_val),
                  Status = "Passive",
                  stringsAsFactors = FALSE
                )
              }
            })
            
            data <- do.call(rbind, rows)
            
            # Summary row
            summary_row <- data.frame(
              Stage = "SYSTEM TOTAL",
              Type = "—",
              Pin_Full = sprintf("%.2f", results$input_power_dbm),
              Pout_Full = sprintf("%.2f", results$final_pout_dbm),
              PAE_Full = sprintf("%.1f", results$system_pae),
              PDC_Full = sprintf("%.3f", results$total_pdc),
              Pin_BO = sprintf("%.2f", results$input_power_dbm - backoff_value),
              Pout_BO = sprintf("%.2f", results$final_pout_bo_dbm),
              PAE_BO = sprintf("%.1f", results$system_pae_bo),
              PDC_BO = sprintf("%.3f", results$total_pdc_bo),
              Gain_dB = sprintf("%.2f", results$total_gain),
              Status = if(length(results$warnings) > 0) "⚠ Check" else "✓ OK",
              stringsAsFactors = FALSE
            )
            
            data <- rbind(data, summary_row)
            
            colnames(data) <- c(
              "Stage", "Type",
              "Pin (dBm)", "Pout (dBm)", "PAE (%)", "PDC (W)",
              "Pin (dBm) ", "Pout (dBm) ", "PAE (%) ", "PDC (W) ",
              "Gain (dB)", "Status"
            )
            
            datatable(data, 
              options = list(pageLength = 20, dom = 't', columnDefs = list(list(className = 'dt-center', targets = 2:11))), 
              rownames = FALSE,
              container = htmltools::withTags(table(
                class = 'display',
                thead(
                  tr(
                    th(rowspan = 2, 'Stage'),
                    th(rowspan = 2, 'Type'),
                    th(colspan = 4, style = 'text-align:center; background-color:#e8f4f8; border-bottom: 2px solid #2196F3;', 'Full Power'),
                    th(colspan = 4, style = 'text-align:center; background-color:#fff3e0; border-bottom: 2px solid #FF9800;', sprintf('Backoff (%.1f dB)', backoff_value)),
                    th(rowspan = 2, 'Gain (dB)'),
                    th(rowspan = 2, 'Status')
                  ),
                  tr(
                    lapply(c('Pin (dBm)', 'Pout (dBm)', 'PAE (%)', 'PDC (W)'), th),
                    lapply(c('Pin (dBm)', 'Pout (dBm)', 'PAE (%)', 'PDC (W)'), th)
                  )
                )
              ))
            ) %>%
              formatStyle('Status',
                backgroundColor = styleEqual(
                  c('✓ Linear', '⚠ Compressed', '✓ OK', '⚠ Check', 'Passive'),
                  c('rgba(0,255,0,0.2)', 'rgba(255,165,0,0.3)', 'rgba(0,255,0,0.2)', 
                    'rgba(255,165,0,0.3)', 'rgba(200,200,200,0.2)')
                )
              ) %>%
              formatStyle(3:6, backgroundColor = '#f0f8ff') %>%
              formatStyle(7:10, backgroundColor = '#fff8f0')
          })
          
          # Rationale output
          output_name_rationale <- paste0("lineup_rationale_", canvas_index)
          output[[output_name_rationale]] <- renderText({
            # Get results from per-canvas storage
            canvas_key <- paste0("canvas_", canvas_index - 1)
            results <- canvas_data[[canvas_key]]$results
            if(is.null(results) || !results$success) {
              return(sprintf("No calculation results for Canvas %d. Click 'Calculate All Canvases'.", canvas_index))
            }
            results$rationale
          })
        })
      })
    }
  })
  
  # ============================================================
  # RF Tools: Converters (Placeholder Implementation)
  # ============================================================
  
  output$conv_power_results <- renderPrint({
    watt <- input$conv_power_watt
    dbm <- 10 * log10(watt * 1000)
    dbw <- 10 * log10(watt)
    cat("Power Conversions:\n")
    cat("================\n")
    cat(sprintf("%.4f W = %.2f dBm = %.2f dBW\n", watt, dbm, dbw))
  })
  
  output$conv_dbm_results <- renderPrint({
    dbm <- input$conv_power_dbm
    watt <- 10^(dbm/10) / 1000
    dbw <- dbm - 30
    cat("Power Conversions:\n")
    cat("================\n")
    cat(sprintf("%.2f dBm = %.6f W = %.2f dBW\n", dbm, watt, dbw))
  })
  
  output$conv_voltage_results <- renderPrint({
    v <- input$conv_voltage
    z <- input$conv_impedance
    power_w <- v^2 / z
    power_dbm <- 10 * log10(power_w * 1000)
    current_a <- v / z
    cat("Voltage/Power Conversions:\n")
    cat("=========================\n")
    cat(sprintf("Voltage: %.4f V\n", v))
    cat(sprintf("Impedance: %.2f Ω\n", z))
    cat(sprintf("Power: %.4f W (%.2f dBm)\n", power_w, power_dbm))
    cat(sprintf("Current: %.4f A\n", current_a))
  })
  
  output$conv_freq_results <- renderPrint({
    freq_ghz <- input$conv_freq
    freq_hz <- freq_ghz * 1e9
    
    er <- if(input$conv_medium == "0") input$conv_er_custom else as.numeric(input$conv_medium)
    
    lambda_m <- 3e8 / freq_hz
    lambda_eff_m <- lambda_m / sqrt(er)
    lambda_mm <- lambda_m * 1000
    lambda_eff_mm <- lambda_eff_m * 1000
    
    cat("Frequency/Wavelength Conversions:\n")
    cat("=================================\n")
    cat(sprintf("Frequency: %.4f GHz = %.2f MHz\n", freq_ghz, freq_ghz * 1000))
    cat(sprintf("Free Space Wavelength: %.2f mm\n", lambda_mm))
    cat(sprintf("Effective Wavelength (εr=%.2f): %.2f mm\n", er, lambda_eff_mm))
    cat(sprintf("Quarter-wave: %.2f mm\n", lambda_eff_mm / 4))
    cat(sprintf("Half-wave: %.2f mm\n", lambda_eff_mm / 2))
  })
  
  output$conv_sparams_results <- renderPrint({
    s11_mag <- input$conv_s11_mag
    s11_phase <- input$conv_s11_phase
    
    # Convert to reflection coefficient
    gamma_real <- s11_mag * cos(s11_phase * pi/180)
    gamma_imag <- s11_mag * sin(s11_phase * pi/180)
    
    # Calculate return loss and VSWR
    return_loss_db <- -20 * log10(s11_mag)
    vswr <- (1 + s11_mag) / (1 - s11_mag)
    
    cat("S-Parameter Conversions:\n")
    cat("=======================\n")
    cat(sprintf("S11: %.4f ∠ %.2f°\n", s11_mag, s11_phase))
    cat(sprintf("Γ: %.4f %+.4fj\n", gamma_real, gamma_imag))
    cat(sprintf("Return Loss: %.2f dB\n", return_loss_db))
    cat(sprintf("VSWR: %.2f:1\n", vswr))
  })
  
  # ============================================================
  # RF Tools: Smith Chart (Placeholder)
  # ============================================================
  
  output$smith_chart_plot <- renderPlotly({
    plot_ly() %>%
      add_trace(
        type = "scatter",
        mode = "lines",
        x = cos(seq(0, 2*pi, length.out = 100)),
        y = sin(seq(0, 2*pi, length.out = 100)),
        line = list(color = "white"),
        showlegend = FALSE
      ) %>%
      layout(
        xaxis = list(range = c(-1.2, 1.2), title = "Real(Γ)"),
        yaxis = list(range = c(-1.2, 1.2), title = "Imag(Γ)"),
        title = "Smith Chart (Placeholder - Full implementation pending)"
      )
  })
  
  output$smith_components <- renderPrint({
    cat("Smith Chart matching network synthesis:\n")
    cat("========================================\n")
    cat("Placeholder - Full implementation pending\n\n")
    cat("Will support:\n")
    cat("- Single/double stub matching\n")
    cat("- L/Pi/T network synthesis\n")
    cat("- Interactive impedance plotting\n")
    cat("- S-parameter trajectory visualization\n")
  })
  
  # ============================================================
  # RF Tools: MTTF Calculator (Placeholder)
  # ============================================================
  
  observeEvent(input$mttf_calculate, {
    output$mttf_results <- renderPrint({
      tj <- input$mttf_tj
      ta <- input$mttf_ta
      pdiss <- input$mttf_power_diss
      rth <- input$mttf_rth
      
      # Simplified Arrhenius model
      Ea <- 0.7  # Activation energy (eV)
      k <- 8.617e-5  # Boltzmann constant (eV/K)
      T_ref <- 398  # Reference temp (125°C in Kelvin)
      T_op <- tj + 273  # Operating temp in Kelvin
      
      # Acceleration factor
      AF <- exp((Ea/k) * (1/T_ref - 1/T_op))
      
      # Base MTTF at reference conditions (hours)
      MTTF_base <- 1e6
      
      # Adjusted MTTF
      voltage_factor <- input$mttf_voltage_stress^2
      current_factor <- input$mttf_current_stress^2
      MTTF_adj <- MTTF_base * AF / (voltage_factor * current_factor)
      
      MTTF_years <- MTTF_adj / 8760
      
      cat("MTTF Analysis Results:\n")
      cat("=====================\n\n")
      cat(sprintf("Device Type: %s\n", input$mttf_device_type))
      cat(sprintf("Junction Temperature: %.1f°C\n", tj))
      cat(sprintf("Ambient Temperature: %.1f°C\n", ta))
      cat(sprintf("Power Dissipation: %.2f W\n", pdiss))
      cat(sprintf("Temperature Rise: %.1f°C\n", pdiss * rth))
      cat("\n")
      cat(sprintf("Acceleration Factor: %.2f\n", AF))
      cat(sprintf("Voltage Stress Factor: %.2f\n", voltage_factor))
      cat(sprintf("Current Stress Factor: %.2f\n", current_factor))
      cat("\n")
      cat(sprintf("MTTF: %.0f hours (%.1f years)\n", MTTF_adj, MTTF_years))
      cat(sprintf("Failure Rate (λ): %.2e failures/hour\n", 1/MTTF_adj))
    })
    
    output$mttf_plot <- renderPlotly({
      # Placeholder reliability curve
      time <- seq(0, 200000, length.out = 100)
      reliability <- exp(-time / 1e6)
      
      plot_ly(x = time, y = reliability * 100, type = "scatter", mode = "lines",
              line = list(color = "green", width = 2)) %>%
        layout(
          title = "Reliability vs Time",
          xaxis = list(title = "Time (hours)"),
          yaxis = list(title = "Reliability (%)")
        )
    })
    
    output$mttf_recommendations <- renderUI({
      HTML(paste0(
        "<ul>",
        "<li>Reduce junction temperature by improving thermal management</li>",
        "<li>Operate at lower voltage/current for extended lifetime</li>",
        "<li>Consider derating factors for mission-critical applications</li>",
        "<li>Implement temperature monitoring and protection</li>",
        "</ul>"
      ))
    })
  })
  
  # ============================================================
  # RF Tools: Thermal Analysis (Placeholder)
  # ============================================================
  
  output$therm_pdiss <- renderPrint({
    pout <- input$therm_pout
    pae <- input$therm_efficiency / 100
    pdc <- pout / pae
    pdiss <- pdc - pout
    
    cat(sprintf("DC Power: %.2f W\n", pdc))
    cat(sprintf("Output Power: %.2f W\n", pout))
    cat(sprintf("Dissipated Power: %.2f W\n", pdiss))
  })
  
  observeEvent(input$therm_calculate, {
    output$therm_results <- renderPrint({
      pout <- input$therm_pout
      pae <- input$therm_efficiency / 100
      pdc <- pout / pae
      pdiss <- pdc - pout
      
      rth_jc <- input$therm_rth_jc
      rth_cs <- input$therm_rth_cs
      rth_sa <- input$therm_rth_sa
      rth_total <- rth_jc + rth_cs + rth_sa
      
      ta <- input$therm_ta
      tj_max <- input$therm_tj_max
      
      tj <- ta + pdiss * rth_total
      tc <- ta + pdiss * (rth_cs + rth_sa)
      ts <- ta + pdiss * rth_sa
      
      margin <- tj_max - tj
      
      cat("Thermal Analysis Results:\n")
      cat("========================\n\n")
      cat(sprintf("Power Dissipation: %.2f W\n\n", pdiss))
      cat("Thermal Resistances:\n")
      cat(sprintf("  Rθjc: %.2f °C/W\n", rth_jc))
      cat(sprintf("  Rθcs: %.2f °C/W\n", rth_cs))
      cat(sprintf("  Rθsa: %.2f °C/W\n", rth_sa))
      cat(sprintf("  Rθja (total): %.2f °C/W\n\n", rth_total))
      cat("Temperature Profile:\n")
      cat(sprintf("  Ambient (Ta): %.1f °C\n", ta))
      cat(sprintf("  Heatsink (Ts): %.1f °C\n", ts))
      cat(sprintf("  Case (Tc): %.1f °C\n", tc))
      cat(sprintf("  Junction (Tj): %.1f °C\n", tj))
      cat(sprintf("  Max Junction: %.1f °C\n\n", tj_max))
      
      if (margin > 0) {
        cat(sprintf("✓ Thermal margin: %.1f °C (SAFE)\n", margin))
      } else {
        cat(sprintf("✗ THERMAL VIOLATION: %.1f °C over limit!\n", -margin))
      }
    })
    
    output$therm_plot <- renderPlotly({
      pout <- input$therm_pout
      pae <- input$therm_efficiency / 100
      pdiss <- (pout / pae) - pout
      
      rth_jc <- input$therm_rth_jc
      rth_cs <- input$therm_rth_cs
      rth_sa <- input$therm_rth_sa
      
      ta <- input$therm_ta
      
      ts <- ta + pdiss * rth_sa
      tc <- ta + pdiss * (rth_cs + rth_sa)
      tj <- ta + pdiss * (rth_jc + rth_cs + rth_sa)
      
      nodes <- c("Ambient", "Heatsink", "Case", "Junction")
      temps <- c(ta, ts, tc, tj)
      colors <- c("blue", "green", "orange", "red")
      
      plot_ly(x = nodes, y = temps, type = "bar",
              marker = list(color = colors)) %>%
        layout(
          title = "Thermal Profile",
          xaxis = list(title = "Location"),
          yaxis = list(title = "Temperature (°C)")
        ) %>%
        add_trace(
          x = nodes,
          y = rep(input$therm_tj_max, length(nodes)),
          type = "scatter",
          mode = "lines",
          line = list(color = "red", dash = "dash"),
          name = "Max Tj Limit"
        )
    })
    
    output$therm_recommendations <- renderUI({
      pout <- input$therm_pout
      pae <- input$therm_efficiency / 100
      pdiss <- (pout / pae) - pout
      
      rth_total <- input$therm_rth_jc + input$therm_rth_cs + input$therm_rth_sa
      tj <- input$therm_ta + pdiss * rth_total
      margin <- input$therm_tj_max - tj
      
      if (margin > 20) {
        HTML("<p style='color:green;'><b>✓ Thermal design is adequate</b></p>
             <ul>
             <li>Current heatsink solution is sufficient</li>
             <li>Consider monitoring for reliability</li>
             </ul>")
      } else if (margin > 0) {
        HTML("<p style='color:orange;'><b>⚠ Marginal thermal design</b></p>
             <ul>
             <li>Improve heatsink or add forced air cooling</li>
             <li>Reduce thermal interface resistance (better TIM)</li>
             <li>Consider active cooling solutions</li>
             </ul>")
      } else {
        HTML("<p style='color:red;'><b>✗ Thermal violation - MUST ADDRESS</b></p>
             <ul>
             <li><b>Critical:</b> Reduce Rθsa or increase heatsink area</li>
             <li>Add forced air or liquid cooling</li>
             <li>Reduce power dissipation (improve PAE or lower output power)</li>
             <li>Split power across multiple devices</li>
             </ul>")
      }
    })
  })
  
  # Cleanup on session end
  onStop(function() {
    if (!is.null(db_pool)) {
      poolClose(db_pool)
    }
  })
}

# Run the application
shinyApp(ui = ui, server = server)
} # end if(FALSE) — legacy code block
